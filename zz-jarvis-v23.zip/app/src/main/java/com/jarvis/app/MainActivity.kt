package com.jarvis.app

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.speech.tts.TextToSpeech
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private var previewTts: TextToSpeech? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("jarvis", MODE_PRIVATE)
        val pad = (24 * resources.displayMetrics.density).toInt()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }
        val wrap = ViewGroup.LayoutParams.MATCH_PARENT

        root.addView(TextView(this).apply {
            text = "Jarvis"
            textSize = 30f
        })
        root.addView(TextView(this).apply {
            text = "1) Dar permisos  2) Pegar tu clave de Gemini  3) Activar"
            setPadding(0, pad / 2, 0, pad / 2)
        })

        root.addView(Button(this).apply {
            text = "1. Dar permisos"
            setOnClickListener {
                val perms = mutableListOf(
                    Manifest.permission.RECORD_AUDIO,
                    Manifest.permission.READ_CONTACTS,
                    Manifest.permission.READ_CALENDAR,
                    Manifest.permission.CALL_PHONE
                )
                if (Build.VERSION.SDK_INT >= 33) perms.add("android.permission.POST_NOTIFICATIONS")
                requestPermissions(perms.toTypedArray(), 1)
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    startActivity(
                        Intent(
                            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                            Uri.parse("package:$packageName")
                        )
                    )
                }
            }
        }, LinearLayout.LayoutParams(wrap, ViewGroup.LayoutParams.WRAP_CONTENT))

        root.addView(Button(this).apply {
            text = "Permiso de No molestar (opcional)"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
            }
        }, LinearLayout.LayoutParams(wrap, ViewGroup.LayoutParams.WRAP_CONTENT))

        root.addView(Button(this).apply {
            text = "Acceso a notificaciones (WhatsApp)"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
            }
        }, LinearLayout.LayoutParams(wrap, ViewGroup.LayoutParams.WRAP_CONTENT))

        root.addView(Button(this).apply {
            text = "Elegir voz de Jarvis"
            setOnClickListener { this@MainActivity.pickVoice() }
        }, LinearLayout.LayoutParams(wrap, ViewGroup.LayoutParams.WRAP_CONTENT))

        root.addView(Button(this).apply {
            text = "Descargar más voces (ajustes de Android)"
            setOnClickListener {
                try {
                    startActivity(Intent("com.android.settings.TTS_SETTINGS"))
                } catch (e: Exception) {
                    Toast.makeText(this@MainActivity, "Buscá 'Salida de texto a voz' en Ajustes", Toast.LENGTH_LONG).show()
                }
            }
        }, LinearLayout.LayoutParams(wrap, ViewGroup.LayoutParams.WRAP_CONTENT))

        root.addView(Button(this).apply {
            text = "Permiso para audios de WhatsApp"
            setOnClickListener {
                startActivity(
                    Intent(
                        Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                        Uri.parse("package:$packageName")
                    )
                )
            }
        }, LinearLayout.LayoutParams(wrap, ViewGroup.LayoutParams.WRAP_CONTENT))

        root.addView(Button(this).apply {
            text = "Activar envío de WhatsApp (accesibilidad)"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
        }, LinearLayout.LayoutParams(wrap, ViewGroup.LayoutParams.WRAP_CONTENT))

        root.addView(Button(this).apply {
            text = "Voz realista (nube)"
            setOnClickListener { this@MainActivity.pickCloudVoice() }
        }, LinearLayout.LayoutParams(wrap, ViewGroup.LayoutParams.WRAP_CONTENT))

        val keyField = EditText(this).apply {
            hint = "Clave de Gemini (AIza...)"
            setSingleLine()
            setText(prefs.getString("key", ""))
        }
        root.addView(keyField)

        root.addView(Button(this).apply {
            text = "2. Guardar clave y activar"
            setOnClickListener {
                prefs.edit().putString("key", keyField.text.toString().trim()).apply()
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    Toast.makeText(this@MainActivity, "Falta el permiso de mostrar sobre otras apps", Toast.LENGTH_LONG).show()
                } else {
                    startForegroundService(Intent(this@MainActivity, OverlayService::class.java))
                    Toast.makeText(this@MainActivity, "Jarvis activo. Tocá la burbuja.", Toast.LENGTH_LONG).show()
                }
            }
        }, LinearLayout.LayoutParams(wrap, ViewGroup.LayoutParams.WRAP_CONTENT))

        root.addView(Button(this).apply {
            text = "Pausar Jarvis"
            setOnClickListener {
                stopService(Intent(this@MainActivity, OverlayService::class.java))
            }
        }, LinearLayout.LayoutParams(wrap, ViewGroup.LayoutParams.WRAP_CONTENT))

        setContentView(root)
    }

    private fun pickCloudVoice() {
        val names = arrayOf("Charon", "Orus", "Algenib", "Alnilam", "Algieba", "Iapetus", "Schedar", "Puck", "Sulafat", "Enceladus", "Kore", "")
        val labels = arrayOf(
            "Charon (grave, informativa)", "Orus (firme)", "Algenib (rasposa)", "Alnilam (firme)",
            "Algieba (suave)", "Iapetus (clara)", "Schedar (pareja)", "Puck (animada)", "Sulafat (cálida)", "Enceladus (suave, con aire)", "Kore (firme)",
            "Apagar voz en la nube"
        )
        AlertDialog.Builder(this)
            .setTitle("Voz realista (nube)")
            .setItems(labels) { _, i ->
                val v = names[i]
                getSharedPreferences("jarvis", MODE_PRIVATE).edit().putString("cloud_voice", v).apply()
                Toast.makeText(
                    this,
                    if (v.isEmpty()) "Voz en la nube apagada" else "Voz: $v. Ya la usa Jarvis.",
                    Toast.LENGTH_LONG
                ).show()
            }
            .setNegativeButton("Cerrar", null)
            .show()
    }

    private fun pickVoice() {
        previewTts?.shutdown()
        previewTts = TextToSpeech(this) { status ->
            val e = previewTts
            if (status != TextToSpeech.SUCCESS || e == null) {
                Toast.makeText(this, "No pude abrir el motor de voz", Toast.LENGTH_LONG).show()
            } else {
                val voices = (e.voices ?: emptySet<android.speech.tts.Voice>())
                    .filter { it.locale.language == "es" }
                    .sortedBy { it.name }
                if (voices.isEmpty()) {
                    Toast.makeText(this, "No encontré voces en español. Probá 'Descargar más voces'.", Toast.LENGTH_LONG).show()
                } else {
                    val labels = voices.mapIndexed { i, v ->
                        val pais = if (v.locale.country.isEmpty()) "es" else v.locale.country
                        val red = if (v.isNetworkConnectionRequired) "online" else "sin internet"
                        "Voz ${i + 1} · $pais · $red"
                    }.toTypedArray()
                    AlertDialog.Builder(this)
                        .setTitle("Tocá una voz para probarla")
                        .setItems(labels) { _, i ->
                            val v = voices[i]
                            getSharedPreferences("jarvis", MODE_PRIVATE).edit().putString("voice", v.name).apply()
                            e.voice = v
                            e.setPitch(0.85f)
                            e.setSpeechRate(0.95f)
                            e.speak("Hola, soy Jarvis. ¿En qué puedo ayudarlo?", TextToSpeech.QUEUE_FLUSH, null, "preview")
                            Toast.makeText(this, "Guardada: Voz ${i + 1}. Pausá y activá Jarvis para usarla.", Toast.LENGTH_LONG).show()
                        }
                        .setNegativeButton("Cerrar", null)
                        .show()
                }
            }
        }
    }
}
