package com.jarvis.app

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.net.Uri
import android.provider.AlarmClock
import android.provider.CalendarContract
import android.provider.ContactsContract
import android.provider.Settings
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.TextView
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.concurrent.thread
import kotlin.math.abs

class OverlayService : Service(), TextToSpeech.OnInitListener {

    companion object {
        // Modelos de Gemini, en orden. Si uno no existe (404) o se acabó su cupo gratis (429),
        // se prueba el siguiente. Los "lite" son mucho más rápidos y tienen más cupo gratis.
        @Volatile var instance: OverlayService? = null
        @Volatile var ttsAttempt = 0
        @Volatile var ttsModelIdx = 0
        @Volatile var textModelIdx = 0
        @Volatile var thinkingOk = true
        val TTS_MODELS = listOf("gemini-3.8-flash-lite-tts", "gemini-3.8-flash-tts")
        val MODELS = listOf("gemini-3.5-flash-lite", "gemini-3.1-flash-lite", "gemini-4-hydrogen")
        const val COLOR_IDLE = "#E6007AFF"
        const val COLOR_LISTENING = "#E6FF3B30"
        const val COLOR_THINKING = "#E6FF9500"
    }

    private lateinit var wm: WindowManager
    private var bubble: TextView? = null
    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private val main = Handler(Looper.getMainLooper())
    private val history = java.util.concurrent.CopyOnWriteArrayList<Pair<String, String>>()
    @Volatile private var heard = ""
    private var player: android.media.MediaPlayer? = null
    private var voicePlayer: android.media.MediaPlayer? = null
    private val speakId = java.util.concurrent.atomic.AtomicInteger(0)
    private val waitId = java.util.concurrent.atomic.AtomicInteger(0)
    private var wakeActive = false
    @Volatile private var commandBusy = false
    @Volatile private var cloudPending = false
    private var listenSilent = false
    private var batteryPct = 100
    private var charging = false
    private var lowBattery = false
    private var wakeErrors = 0
    private var batteryReceiver: android.content.BroadcastReceiver? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        instance = this
        startAsForeground()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        tts = TextToSpeech(this, this)
        addBubble()
        registerBattery()
        main.postDelayed({ startWake() }, 2500)
        main.postDelayed({ startupCheck() }, 7000)
    }

    override fun onInit(status: Int) {
        tts?.language = Locale("es")
        val saved = getSharedPreferences("jarvis", MODE_PRIVATE).getString("voice", null)
        if (saved != null) {
            tts?.voices?.firstOrNull { it.name == saved }?.let { tts?.voice = it }
        }
        tts?.setPitch(0.85f)
        tts?.setSpeechRate(0.95f)
    }

    private fun startAsForeground() {
        val channelId = "jarvis"
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(channelId, "Jarvis", NotificationManager.IMPORTANCE_MIN)
        )
        val n = Notification.Builder(this, channelId)
            .setContentTitle("Jarvis activo")
            .setContentText(notifText())
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } else {
            startForeground(1, n)
        }
    }

    private fun setBubble(letter: String, color: String) {
        bubble?.text = letter
        (bubble?.background as? GradientDrawable)?.setColor(Color.parseColor(color))
    }

    private fun addBubble() {
        val size = (56 * resources.displayMetrics.density).toInt()
        val tv = TextView(this).apply {
            text = "J"
            textSize = 22f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.parseColor(COLOR_IDLE))
            }
        }
        val lp = WindowManager.LayoutParams(
            size, size,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.END
            x = 16
            y = 300
        }

        var startX = 0
        var startY = 0
        var touchX = 0f
        var touchY = 0f
        var moved = false

        tv.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = lp.x; startY = lp.y
                    touchX = e.rawX; touchY = e.rawY
                    moved = false
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - touchX).toInt()
                    val dy = (e.rawY - touchY).toInt()
                    if (abs(dx) > 10 || abs(dy) > 10) moved = true
                    if (moved) {
                        lp.x = startX - dx
                        lp.y = startY + dy
                        wm.updateViewLayout(tv, lp)
                    }
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) {
                        if (e.eventTime - e.downTime > 800) stopSelf() else listen()
                    }
                }
            }
            true
        }
        bubble = tv
        wm.addView(tv, lp)
    }

    private fun say(text: String) {
        setBubble("J", COLOR_IDLE)
        speak(text)
    }

    private fun localSpeak(text: String) {
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis")
    }

    private fun stopSpeaking() {
        speakId.incrementAndGet()
        tts?.stop()
        try { voicePlayer?.release() } catch (e: Exception) { }
        voicePlayer = null
    }

    private fun speak(text: String) {
        if (wakeActive) stopWake()
        resumeAfterSpeech(text.trimEnd().endsWith("?"))
        stopSpeaking()
        val id = speakId.get()
        val prefs = getSharedPreferences("jarvis", MODE_PRIVATE)
        val voice = prefs.getString("cloud_voice", "Charon") ?: ""
        val key = prefs.getString("key", "") ?: ""
        if (voice.isEmpty() || key.isEmpty() || text.length > 700) {
            localSpeak(text)
            return
        }
        cloudPending = true
        thread {
            val f = try { cloudTts(key, voice, text) } catch (e: Exception) { null }
            main.post {
                cloudPending = false
                if (id != speakId.get()) {
                    f?.delete()
                } else if (f == null) {
                    localSpeak(text)
                } else {
                    playSpeechFile(f, text)
                }
            }
        }
    }

    private fun playSpeechFile(f: java.io.File, text: String) {
        try {
            val mp = android.media.MediaPlayer()
            voicePlayer = mp
            mp.setDataSource(f.absolutePath)
            mp.setOnCompletionListener { it.release(); f.delete() }
            mp.prepare()
            mp.start()
        } catch (e: Exception) {
            f.delete()
            localSpeak(text)
        }
    }

    private fun addWavHeader(pcm: ByteArray, rate: Int): ByteArray {
        val bb = java.nio.ByteBuffer.allocate(44 + pcm.size).order(java.nio.ByteOrder.LITTLE_ENDIAN)
        bb.put("RIFF".toByteArray()); bb.putInt(36 + pcm.size); bb.put("WAVE".toByteArray())
        bb.put("fmt ".toByteArray()); bb.putInt(16); bb.putShort(1); bb.putShort(1)
        bb.putInt(rate); bb.putInt(rate * 2); bb.putShort(2); bb.putShort(16)
        bb.put("data".toByteArray()); bb.putInt(pcm.size); bb.put(pcm)
        return bb.array()
    }

    private fun cloudTts(key: String, voice: String, text: String): java.io.File? {
        val style = "calm, deep, refined and precise, like a sophisticated English butler, warm, natural and unhurried"
        val oldPrompt = "Say calmly, with the deep, refined and precise voice of a sophisticated English butler, speaking Spanish: $text"
        // Intentos en orden: (formato de voz, ¿estilo aparte del texto?)
        val attempts = listOf(Pair(0, true), Pair(0, false), Pair(1, false))
        for (mi in ttsModelIdx until TTS_MODELS.size) {
            val model = TTS_MODELS[mi]
            for (ai in (if (mi == ttsModelIdx) ttsAttempt else 0) until attempts.size) {
                val (shape, useMeta) = attempts[ai]
                val voiceCfg = if (shape == 0) JSONObject().put("voice", voice)
                else JSONObject().put("prebuiltVoiceConfig", JSONObject().put("voiceName", voice))
                val part = if (useMeta) JSONObject().put("text", text).put("speech_metadata", JSONObject().put("style", style))
                else JSONObject().put("text", oldPrompt)
                val body = JSONObject()
                    .put("contents", JSONArray().put(JSONObject().put("parts", JSONArray().put(part))))
                    .put(
                        "generationConfig",
                        JSONObject()
                            .put("responseModalities", JSONArray().put("AUDIO"))
                            .put("speechConfig", JSONObject().put("voiceConfig", voiceCfg))
                    )
                val r = post(key, model, body)
                if (r.first == 400) continue
                if (r.first !in 200..299) break
                val parts = JSONObject(r.second).optJSONArray("candidates")?.optJSONObject(0)
                    ?.optJSONObject("content")?.optJSONArray("parts") ?: break
                for (i in 0 until parts.length()) {
                    val pt = parts.getJSONObject(i)
                    val inline = pt.optJSONObject("inlineData") ?: pt.optJSONObject("inline_data") ?: continue
                    val b64 = inline.optString("data", "")
                    if (b64.isEmpty()) continue
                    val mime = inline.optString("mimeType", inline.optString("mime_type", ""))
                    val bytes = android.util.Base64.decode(b64, android.util.Base64.DEFAULT)
                    val isWav = bytes.size > 4 && bytes[0] == 'R'.code.toByte() && bytes[1] == 'I'.code.toByte()
                    val rate = Regex("rate=(\\d+)").find(mime)?.groupValues?.get(1)?.toIntOrNull() ?: 24000
                    val file = java.io.File(cacheDir, "tts_${System.currentTimeMillis()}.wav")
                    file.writeBytes(if (isWav) bytes else addWavHeader(bytes, rate))
                    ttsModelIdx = mi
                    ttsAttempt = ai
                    return file
                }
                break
            }
        }
        ttsModelIdx = 0
        ttsAttempt = 0
        return null
    }

    // ---------- Notas, dictado, correos y agenda ----------

    private var dictating = false
    private val dictBuf = StringBuilder()
    private var dictSilence = 0

    private fun notesLoad(): JSONArray = try {
        JSONArray(getSharedPreferences("jarvis_notes", MODE_PRIVATE).getString("items", "[]") ?: "[]")
    } catch (e: Exception) {
        JSONArray()
    }

    private fun notesSave(a: JSONArray) {
        getSharedPreferences("jarvis_notes", MODE_PRIVATE).edit().putString("items", a.toString()).apply()
    }

    private fun noteToFile(text: String) {
        try {
            if (Build.VERSION.SDK_INT >= 30 && !android.os.Environment.isExternalStorageManager()) return
            val dir = java.io.File(
                android.os.Environment.getExternalStoragePublicDirectory(android.os.Environment.DIRECTORY_DOCUMENTS),
                "Jarvis"
            )
            dir.mkdirs()
            val stamp = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(java.util.Date())
            java.io.File(dir, "notas.txt").appendText("[$stamp] $text\n")
        } catch (e: Exception) {
        }
    }

    private fun noteAdd(text: String): String? {
        val t = text.trim()
        if (t.isEmpty()) return "No entendí qué anotar."
        val a = notesLoad()
        a.put(JSONObject().put("t", System.currentTimeMillis()).put("x", t))
        notesSave(a)
        noteToFile(t)
        return null
    }

    private fun noteRead(which: String): String? {
        val a = notesLoad()
        val n = a.length()
        if (n == 0) return "No tenés notas guardadas."
        val fmt = SimpleDateFormat("d 'de' MMMM, HH:mm", Locale("es", "AR"))
        if (which == "last") {
            val o = a.getJSONObject(n - 1)
            return "Tu última nota, del ${fmt.format(java.util.Date(o.optLong("t")))}: ${o.optString("x")}."
        }
        val sb = StringBuilder("Tenés $n ${if (n == 1) "nota" else "notas"}. ")
        val take = minOf(n, 5)
        for (i in 0 until take) {
            sb.append("${i + 1}, ${a.getJSONObject(n - 1 - i).optString("x")}. ")
        }
        return sb.toString()
    }

    private fun noteDelete(which: String, kw: String): String? {
        val a = notesLoad()
        if (a.length() == 0) return "No tenés notas guardadas."
        when {
            which == "all" -> {
                notesSave(JSONArray())
                return "Listo, borré todas las notas."
            }
            kw.isNotBlank() -> {
                val keep = JSONArray()
                var removed = 0
                for (i in 0 until a.length()) {
                    val o = a.getJSONObject(i)
                    if (norm(o.optString("x")).contains(norm(kw))) removed++ else keep.put(o)
                }
                notesSave(keep)
                return if (removed == 0) "No encontré esa nota." else "Listo, borré $removed."
            }
            else -> {
                val keep = JSONArray()
                for (i in 0 until a.length() - 1) keep.put(a.getJSONObject(i))
                notesSave(keep)
                return "Listo, borré la última nota."
            }
        }
    }

    private fun startDictation(): String? {
        dictating = true
        dictBuf.setLength(0)
        dictSilence = 0
        return "Te escucho, jefe. Decí listo cuando termines. ¿Empiezo?"
    }

    private fun finishDictation() {
        dictating = false
        val t = dictBuf.toString().trim()
        dictBuf.setLength(0)
        if (t.isEmpty()) say("No alcancé a anotar nada.")
        else {
            noteAdd(t)
            say("Nota guardada.")
        }
    }

    private fun dictationSilence() {
        dictSilence++
        if (dictSilence >= 3) finishDictation()
        else main.postDelayed({ if (dictating) listen(true) }, 200)
    }

    private fun handleDictation(text: String) {
        val t = norm(text).trim().trimEnd('.', ' ')
        if (Regex("^(listo|fin|termine|terminar|guardar|guarda|fin de la nota|eso es todo|ya esta)$").containsMatchIn(t)) {
            finishDictation()
            return
        }
        if (Regex("^(cancela\\w*|descarta\\w*)$").containsMatchIn(t)) {
            dictating = false
            dictBuf.setLength(0)
            say("Dictado cancelado.")
            return
        }
        if (dictBuf.isNotEmpty()) dictBuf.append(' ')
        dictBuf.append(text.trim())
        dictSilence = 0
        main.postDelayed({ if (dictating) listen(true) }, 300)
    }

    private fun readMail(): String? {
        val mails = NotifStore.all(this).filter {
            val a = it.app.lowercase()
            a == "gm" || a.contains("mail") || a.contains("outlook") || a.contains("yahoo")
        }.sortedBy { it.time }.takeLast(5)
        if (mails.isEmpty()) return "No tengo mails nuevos registrados. Solo veo los que te llegan como notificación."
        val sb = StringBuilder("Tenés ${mails.size} ${if (mails.size == 1) "mail" else "mails"} reciente${if (mails.size == 1) "" else "s"}. ")
        mails.reversed().forEach { sb.append("De ${it.sender}: ${it.text}. ") }
        return sb.toString()
    }

    private fun agenda(day: String): String? {
        if (checkSelfPermission(Manifest.permission.READ_CALENDAR) != PackageManager.PERMISSION_GRANTED) {
            return startGuide("calendario")
        }
        val start = java.util.Calendar.getInstance().apply {
            set(java.util.Calendar.HOUR_OF_DAY, 0)
            set(java.util.Calendar.MINUTE, 0)
            set(java.util.Calendar.SECOND, 0)
            set(java.util.Calendar.MILLISECOND, 0)
            if (day == "tomorrow") add(java.util.Calendar.DAY_OF_YEAR, 1)
        }
        val end = start.clone() as java.util.Calendar
        end.add(java.util.Calendar.DAY_OF_YEAR, if (day == "week") 7 else 1)
        val b = android.provider.CalendarContract.Instances.CONTENT_URI.buildUpon()
        android.content.ContentUris.appendId(b, start.timeInMillis)
        android.content.ContentUris.appendId(b, end.timeInMillis)
        val items = ArrayList<String>()
        val hh = SimpleDateFormat("HH:mm", Locale.US)
        val dd = SimpleDateFormat("EEEE", Locale("es", "AR"))
        try {
            contentResolver.query(
                b.build(),
                arrayOf(
                    android.provider.CalendarContract.Instances.TITLE,
                    android.provider.CalendarContract.Instances.BEGIN,
                    android.provider.CalendarContract.Instances.ALL_DAY
                ),
                null, null, "begin ASC"
            )?.use { c ->
                while (c.moveToNext()) {
                    val title = c.getString(0) ?: "Sin título"
                    val begin = c.getLong(1)
                    val allDay = c.getInt(2) == 1
                    val whenTxt = if (allDay) "todo el día" else "a las " + hh.format(java.util.Date(begin))
                    items.add(if (day == "week") dd.format(java.util.Date(begin)) + " " + whenTxt + ", " + title else "$whenTxt, $title")
                }
            }
        } catch (e: Exception) {
            return "No pude leer el calendario."
        }
        val label = when (day) {
            "tomorrow" -> "Mañana"
            "week" -> "Esta semana"
            else -> "Hoy"
        }
        if (items.isEmpty()) return "$label no tenés nada en la agenda."
        return "$label tenés ${items.size} ${if (items.size == 1) "evento" else "eventos"}: " + items.take(8).joinToString(". ") + "."
    }

    // ---------- Autodiagnóstico de permisos y guía paso a paso ----------

    private class PermItem(
        val key: String,
        val label: String,
        val ok: Boolean,
        val critical: Boolean,
        val steps: List<String>,
        val opener: () -> Intent?
    )

    private var guideKey = ""
    private var guideSteps: List<String> = emptyList()
    private var guideIdx = -1

    private fun appDetails(): Intent =
        Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))

    private fun permItems(): List<PermItem> {
        val out = ArrayList<PermItem>()
        val nm = getSystemService(NotificationManager::class.java)
        val pw = getSystemService(android.os.PowerManager::class.java)
        out.add(
            PermItem(
                "accesibilidad", "accesibilidad", SendAccessibilityService.running, true,
                listOf(
                    "Abrí Ajustes y entrá a Accesibilidad.",
                    "Tocá Jarvis en la lista de apps descargadas. Puede aparecer como Administrador de redes.",
                    "Activá el interruptor y aceptá el aviso.",
                    "Si aparece en gris, andá a Ajustes, Apps, Jarvis, tocá los tres puntitos de arriba y elegí Permitir configuración restringida. Después repetí los pasos anteriores."
                )
            ) { Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS) }
        )
        val listeners = Settings.Secure.getString(contentResolver, "enabled_notification_listeners") ?: ""
        out.add(
            PermItem(
                "notificaciones", "acceso a notificaciones", listeners.contains(packageName), true,
                listOf(
                    "Abrí Ajustes, Notificaciones, y buscá Acceso a notificaciones.",
                    "Tocá Jarvis y activá el interruptor.",
                    "Aceptá el aviso que aparece."
                )
            ) { Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS) }
        )
        out.add(
            PermItem(
                "microfono", "micrófono",
                checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED, true,
                listOf(
                    "Abrí Ajustes, Apps, Jarvis, y entrá a Permisos.",
                    "Tocá Micrófono y elegí Permitir."
                )
            ) { appDetails() }
        )
        out.add(
            PermItem(
                "contactos", "contactos",
                checkSelfPermission(Manifest.permission.READ_CONTACTS) == PackageManager.PERMISSION_GRANTED, false,
                listOf(
                    "Abrí Ajustes, Apps, Jarvis, y entrá a Permisos.",
                    "Tocá Contactos y elegí Permitir."
                )
            ) { appDetails() }
        )
        out.add(
            PermItem(
                "calendario", "calendario",
                checkSelfPermission(Manifest.permission.READ_CALENDAR) == PackageManager.PERMISSION_GRANTED &&
                    checkSelfPermission(Manifest.permission.WRITE_CALENDAR) == PackageManager.PERMISSION_GRANTED, false,
                listOf(
                    "Abrí Ajustes, Apps, Jarvis, y entrá a Permisos.",
                    "Tocá Calendario y elegí Permitir."
                )
            ) { appDetails() }
        )
        out.add(
            PermItem(
                "brillo", "cambiar el brillo", Settings.System.canWrite(this), false,
                listOf(
                    "Se abre la pantalla Modificar los ajustes del sistema.",
                    "Activá el interruptor de Jarvis."
                )
            ) { Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:$packageName")) }
        )
        out.add(
            PermItem(
                "archivos", "acceso a archivos",
                Build.VERSION.SDK_INT < 30 || android.os.Environment.isExternalStorageManager(), false,
                listOf(
                    "Se abre la pantalla Acceso a todos los archivos.",
                    "Activá el interruptor de Jarvis."
                )
            ) { Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:$packageName")) }
        )
        out.add(
            PermItem(
                "no molestar", "acceso a No molestar", nm.isNotificationPolicyAccessGranted, false,
                listOf(
                    "Se abre la pantalla Acceso a No molestar.",
                    "Tocá Jarvis y activá el permiso."
                )
            ) { Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS) }
        )
        out.add(
            PermItem(
                "bateria", "batería sin restricciones", pw.isIgnoringBatteryOptimizations(packageName), false,
                listOf(
                    "Abrí Ajustes, Apps, Jarvis, y entrá a Batería, o Uso de batería de la app.",
                    "Elegí Sin restricciones."
                )
            ) { appDetails() }
        )
        out.add(
            PermItem(
                "superposicion", "mostrarse sobre otras apps", Settings.canDrawOverlays(this), false,
                listOf(
                    "Se abre la pantalla Mostrar sobre otras apps.",
                    "Activá el interruptor de Jarvis."
                )
            ) { Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")) }
        )
        if (Build.VERSION.SDK_INT >= 33) {
            out.add(
                PermItem(
                    "avisos", "avisos de notificación",
                    checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED, false,
                    listOf(
                        "Abrí Ajustes, Apps, Jarvis, Notificaciones.",
                        "Activá Mostrar notificaciones."
                    )
                ) { appDetails() }
            )
        }
        return out
    }

    private fun topicKey(t: String): String? = when {
        Regex("captura|cerrar|accesib|gesto|pantallazo").containsMatchIn(t) -> "accesibilidad"
        Regex("notificacion|mensaje|whatsapp").containsMatchIn(t) -> "notificaciones"
        Regex("microfono|voz|escuch").containsMatchIn(t) -> "microfono"
        t.contains("contacto") -> "contactos"
        Regex("calendario|agenda|evento").containsMatchIn(t) -> "calendario"
        Regex("brillo|ajustes del sistema").containsMatchIn(t) -> "brillo"
        Regex("archivo|proyecto").containsMatchIn(t) -> "archivos"
        t.contains("molestar") -> "no molestar"
        Regex("bateria|segundo plano|manos libres").containsMatchIn(t) -> "bateria"
        Regex("burbuja|superpon|sobre otras").containsMatchIn(t) -> "superposicion"
        else -> null
    }

    private fun clearGuide() {
        guideKey = ""
        guideSteps = emptyList()
        guideIdx = -1
    }

    private fun diagnose(): String? {
        val missing = permItems().filter { !it.ok }
        if (missing.isEmpty()) {
            clearGuide()
            return "Jefe, tengo todos los permisos activados."
        }
        guideKey = missing.first().key
        guideSteps = emptyList()
        guideIdx = -1
        return "Jefe, me falta: " + missing.joinToString(", ") { it.label } +
            ". ¿Empezamos con " + missing.first().label + "?"
    }

    private fun stepText(): String {
        val last = guideIdx == guideSteps.size - 1
        return "Paso ${guideIdx + 1} de ${guideSteps.size}. ${guideSteps[guideIdx]} " + if (last) "¿Listo?" else "¿Seguimos?"
    }

    private fun startGuide(topic: String): String? {
        val items = permItems()
        val t = norm(topic)
        val byTopic = if (t.isBlank()) null else topicKey(t)?.let { k -> items.firstOrNull { it.key == k } }
        val item = byTopic ?: items.firstOrNull { !it.ok }
            ?: return "Jefe, tengo todo activado, no hay nada que configurar."
        if (item.ok) {
            clearGuide()
            return "Ya tenés activado ${item.label}."
        }
        guideKey = item.key
        guideSteps = item.steps
        guideIdx = 0
        try {
            item.opener()?.let { startActivity(newTask(it)) }
        } catch (e: Exception) {
        }
        return stepText()
    }

    private fun guideNext(dir: String): String? {
        if (guideKey.isEmpty()) return "No estamos en ninguna guía. Decime guiame y empezamos."
        if (dir == "stop") {
            clearGuide()
            return "Listo, dejamos la guía."
        }
        if (guideIdx < 0) return startGuide(guideKey)
        if (dir == "repeat") return stepText()
        guideIdx++
        if (guideIdx >= guideSteps.size) {
            val key = guideKey
            clearGuide()
            val item = permItems().firstOrNull { it.key == key }
            return if (item != null && item.ok) "Perfecto, ya está activado ${item.label}."
            else "Todavía lo veo apagado. Revisá el último paso o decime guiame para repetirlo."
        }
        return stepText()
    }

    private fun helpText(): String =
        "Puedo poner alarmas, temporizadores y recordatorios; manejar linterna, volumen y brillo; abrir y cerrar apps; " +
            "sacar capturas; llevar listas y notas, también por dictado; escribir y llamar por WhatsApp; leer tus mensajes y mails; " +
            "leerte la agenda; poner música; " +
            "y con internet, buscar y charlar. Decime revisá tus permisos para ver qué me falta."

    private fun mediaKey(cmd: String): String? {
        val code = when (cmd) {
            "next" -> android.view.KeyEvent.KEYCODE_MEDIA_NEXT
            "previous" -> android.view.KeyEvent.KEYCODE_MEDIA_PREVIOUS
            "stop" -> android.view.KeyEvent.KEYCODE_MEDIA_STOP
            "pause" -> android.view.KeyEvent.KEYCODE_MEDIA_PAUSE
            "play" -> android.view.KeyEvent.KEYCODE_MEDIA_PLAY
            else -> android.view.KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE
        }
        val am = getSystemService(android.media.AudioManager::class.java)
        am.dispatchMediaKeyEvent(android.view.KeyEvent(android.view.KeyEvent.ACTION_DOWN, code))
        am.dispatchMediaKeyEvent(android.view.KeyEvent(android.view.KeyEvent.ACTION_UP, code))
        return null
    }

    private fun startupCheck() {
        val missing = permItems().filter { it.critical && !it.ok }
        if (missing.isEmpty()) return
        say("Jefe, me faltan permisos importantes: " + missing.joinToString(", ") { it.label } +
            ". Decime revisá tus permisos y te guío paso a paso.")
    }

    // ---------- Manos libres (palabra "Jarvis") y batería ----------

    private val wakeStarter = Runnable { startWake() }
    private val wakeRegex = Regex("(?i)\\b(jarvis|yarvis|jarbis|jarvi|jarvez|garvis|charvis|yarvi|jarviz)\\b")

    private fun handsFreeEnabled(): Boolean = getSharedPreferences("jarvis", MODE_PRIVATE).getBoolean("handsfree", true)

    private fun handsFreeNow(): Boolean = handsFreeEnabled() && !lowBattery

    private fun notifText(): String =
        if (handsFreeNow()) "Manos libres: decí \"Jarvis\" y tu pedido. También podés tocar la burbuja."
        else "Tocá la burbuja para hablar. Mantenela apretada para pausar."

    private fun updateNotification() {
        val nm = getSystemService(NotificationManager::class.java)
        val n = Notification.Builder(this, "jarvis")
            .setContentTitle("Jarvis activo")
            .setContentText(notifText())
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .build()
        nm.notify(1, n)
    }

    private fun registerBattery() {
        val r = object : android.content.BroadcastReceiver() {
            override fun onReceive(c: android.content.Context?, i: Intent?) {
                if (i != null) onBattery(i)
            }
        }
        batteryReceiver = r
        val sticky = registerReceiver(r, android.content.IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        if (sticky != null) onBattery(sticky)
    }

    private fun onBattery(i: Intent) {
        val level = i.getIntExtra(android.os.BatteryManager.EXTRA_LEVEL, -1)
        val scale = i.getIntExtra(android.os.BatteryManager.EXTRA_SCALE, 100)
        if (level < 0 || scale <= 0) return
        batteryPct = level * 100 / scale
        val st = i.getIntExtra(android.os.BatteryManager.EXTRA_STATUS, -1)
        charging = st == android.os.BatteryManager.BATTERY_STATUS_CHARGING ||
            st == android.os.BatteryManager.BATTERY_STATUS_FULL
        val wasLow = lowBattery
        // Con histéresis para que no prenda y apague en 10-12 %.
        lowBattery = if (wasLow) !(batteryPct >= 13 || charging) else (batteryPct <= 10 && !charging)
        if (wasLow == lowBattery) return
        updateNotification()
        if (lowBattery) {
            stopWake()
            say("Batería baja. Pauso el manos libres. Tocá la burbuja para hablarme.")
        } else {
            android.widget.Toast.makeText(this, "Manos libres activado.", android.widget.Toast.LENGTH_SHORT).show()
            if (!commandBusy) startWake()
        }
    }

    private fun stopWake() {
        wakeActive = false
        main.removeCallbacks(wakeStarter)
        try { recognizer?.destroy() } catch (e: Exception) { }
        recognizer = null
    }

    private fun startWake() {
        main.removeCallbacks(wakeStarter)
        if (!handsFreeNow() || commandBusy || wakeActive) return
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) return
        if (!SpeechRecognizer.isRecognitionAvailable(this)) return
        try { recognizer?.destroy() } catch (e: Exception) { }
        wakeActive = true
        setBubble("J", COLOR_IDLE)
        recognizer = SpeechRecognizer.createSpeechRecognizer(this).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onPartialResults(partialResults: Bundle?) {}
                override fun onEvent(eventType: Int, params: Bundle?) {}
                override fun onError(error: Int) {
                    wakeActive = false
                    wakeRestart(error)
                }
                override fun onResults(results: Bundle?) {
                    wakeActive = false
                    wakeErrors = 0
                    val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull() ?: ""
                    onWakeText(text)
                }
            })
            startListening(
                Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE, "es-US")
                    putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
                    putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 1200L)
                    putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 900L)
                }
            )
        }
    }

    private fun wakeRestart(error: Int) {
        val benign = error == SpeechRecognizer.ERROR_NO_MATCH || error == SpeechRecognizer.ERROR_SPEECH_TIMEOUT
        val net = error == SpeechRecognizer.ERROR_NETWORK || error == SpeechRecognizer.ERROR_NETWORK_TIMEOUT ||
            error == SpeechRecognizer.ERROR_SERVER
        if (net) {
            // Sin internet y sin voz offline descargada: reintenta despacio, sin gastar batería.
            main.postDelayed(wakeStarter, 15000L)
            return
        }
        if (benign) wakeErrors = 0 else wakeErrors++
        if (wakeErrors > 6) {
            setBubble("J", "#E6808080")
            android.widget.Toast.makeText(this, "No puedo escuchar ahora. Tocá la burbuja para hablarme.", android.widget.Toast.LENGTH_LONG).show()
            return
        }
        val delay = when {
            benign -> 250L
            error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> 1500L
            else -> 4000L
        }
        main.postDelayed(wakeStarter, delay)
    }

    /** Busca "Jarvis" aunque el reconocimiento lo escriba parecido (Yarvis, Harvis, Jarbis...). */
    private fun findWake(text: String): IntRange? {
        // "Jarvis" tiene que estar al principio de la frase (primeras 3 palabras): así no se activa con videos o charlas.
        val toks = Regex("\\p{L}+").findAll(text).toList()
        for ((i, t) in toks.withIndex()) {
            if (i > 2) break
            val w = norm(t.value)
            if (wakeRegex.matches(t.value)) return t.range
            if (w.length in 5..7 && w.firstOrNull() in listOf('j', 'y', 'h', 'g') && lev(w, "jarvis") <= 1) return t.range
        }
        return null
    }

    private fun onWakeText(text: String) {
        val m = findWake(text)
        if (m == null) {
            main.postDelayed(wakeStarter, 150)
            return
        }
        val cmd = text.substring(m.last + 1).trim().trimStart(',', '.', ':', ';', '!', '¡', ' ')
        commandBusy = true
        if (cmd.length < 2) {
            try {
                android.media.ToneGenerator(android.media.AudioManager.STREAM_MUSIC, 60)
                    .startTone(android.media.ToneGenerator.TONE_PROP_ACK, 120)
            } catch (e: Exception) { }
            listen()
        } else {
            heard = cmd
            ask(cmd)
        }
    }

    private fun resumeAfterSpeech(followUp: Boolean) {
        main.removeCallbacks(wakeStarter)
        val id = waitId.incrementAndGet()
        main.postDelayed({ waitSpeechDone(id, followUp, 0) }, 700)
    }

    private fun waitSpeechDone(id: Int, followUp: Boolean, n: Int) {
        if (id != waitId.get()) return
        val speaking = (tts?.isSpeaking == true) || cloudPending ||
            (try { voicePlayer?.isPlaying == true } catch (e: Exception) { false })
        if (speaking && n < 120) {
            main.postDelayed({ waitSpeechDone(id, followUp, n + 1) }, 500)
            return
        }
        commandBusy = false
        if (!handsFreeNow() && !dictating) return
        if (followUp) listen(true) else startWake()
    }

    private fun listen(silent: Boolean = false) {
        listenSilent = silent
        commandBusy = true
        wakeErrors = 0
        stopWake()
        stopSpeaking()
        try { player?.release() } catch (e: Exception) { }
        player = null
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            say("Falta el permiso del micrófono.")
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            say("Este teléfono no tiene reconocimiento de voz.")
            return
        }
        recognizer?.destroy()
        setBubble("●", COLOR_LISTENING)
        recognizer = SpeechRecognizer.createSpeechRecognizer(this).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onPartialResults(partialResults: Bundle?) {}
                override fun onEvent(eventType: Int, params: Bundle?) {}
                override fun onError(error: Int) {
                    if (dictating) {
                        dictationSilence()
                    } else if (listenSilent) {
                        setBubble("J", COLOR_IDLE)
                        resumeAfterSpeech(false)
                    } else say("No te escuché, probá de nuevo.")
                }
                override fun onResults(results: Bundle?) {
                    val text = results
                        ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        ?.firstOrNull()
                    if (text.isNullOrBlank()) {
                        if (dictating) {
                            dictationSilence()
                        } else if (listenSilent) {
                            setBubble("J", COLOR_IDLE)
                            resumeAfterSpeech(false)
                        } else say("No te escuché.")
                    } else {
                        heard = text
                        ask(text)
                    }
                }
            })
            startListening(
                Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE, "es-US")
                    putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
                    putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 900L)
                    putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 700L)
                }
            )
        }
    }

    private fun ask(question: String) {
        if (dictating) {
            handleDictation(question)
            return
        }
        setBubble("…", COLOR_THINKING)
        val key = getSharedPreferences("jarvis", MODE_PRIVATE).getString("key", "") ?: ""
        thread {
            val prefsA = getSharedPreferences("jarvis", MODE_PRIVATE)
            val choiceCount = (prefsA.getString("choice_names", "") ?: "").let { if (it.isEmpty()) 0 else it.split("\u0001").size }
            val ctx = LocalBrain.Ctx(batteryPct, charging, prefsA.getString("send_number", null) != null, choiceCount, guideKey.isNotEmpty())
            val local = try {
                LocalBrain.parse(question, ctx)?.takeIf { localValid(it) }
            } catch (e: Exception) {
                null
            }
            val answer = if (local != null) local.toString() else try {
                callGemini(key, question)
            } catch (e: java.io.IOException) {
offlineHint(question)
            } catch (e: Exception) {
                "Error inesperado: ${e.javaClass.simpleName} ${e.message}"
            }
            val isError = answer.startsWith("No pude") || answer.startsWith("Error") || answer.startsWith("Gemini")
            history.add(Pair("user", question))
            history.add(
                Pair(
                    "model",
                    if (isError) JSONObject().put("say", answer).put("action", "none").toString() else answer
                )
            )
            while (history.size > 8) history.removeAt(0)
            main.post { handleReply(answer) }
        }
    }

    /** Sin internet y sin entender el pedido: sugiere cómo decirlo según las palabras clave. */
    private fun offlineHint(q: String): String {
        val n = norm(q)
        val hint = when {
            Regex("anot|nota|apunt|dicta").containsMatchIn(n) -> "Para anotar decime: nota, y lo que quieras guardar. O modo dictado."
            Regex("agend|calendario|evento|cita|reunion").containsMatchIn(n) ->
                "Para ver tu agenda decime: qué tengo hoy. Para agendar decime: agendá reunión mañana a las 5."
            Regex("alarma").containsMatchIn(n) && Regex("borr|elimin|cancel|sac|quit|apag|desactiv|anul").containsMatchIn(n) ->
                "Para borrar una alarma decime: borrá la alarma de las 8. O decime: abrime las alarmas."
            Regex("alarma|despert").containsMatchIn(n) -> "Para una alarma decime: alarma a las 7 de la mañana."
            Regex("temporizador|timer|cronometro").containsMatchIn(n) -> "Para un temporizador decime: temporizador de 10 minutos."
            Regex("recorda|recuerda|avisa").containsMatchIn(n) -> "Para un recordatorio decime: recordame en 10 minutos sacar la pizza."
            Regex("mensaje|escrib|whatsapp|wasap").containsMatchIn(n) -> "Para escribir por WhatsApp decime: escribile a Alicia diciendo hola."
            Regex("llam").containsMatchIn(n) -> "Para llamar decime: llamá a Alicia."
            Regex("nota|anota|apunta|dicta").containsMatchIn(n) -> "Para anotar decime: nota, y lo que quieras guardar. O modo dictado."
            Regex("lista|compra").containsMatchIn(n) -> "Para listas decime: agregá leche a la lista de compras."
            Regex("music|cancion|tema").containsMatchIn(n) -> "Para música decime: poné música de Soda Stereo."
            Regex("mail|correo").containsMatchIn(n) -> "Para tus correos decime: leeme los mails."
            else -> "No entendí ese pedido sin internet. Decime qué podés hacer y te cuento lo que sé hacer."
        }
        return "Sin internet no puedo con eso, jefe. $hint"
    }

    /** Si el pedido local es abrir una app que no existe, mejor que decida Gemini. */
    private fun localValid(j: JSONObject): Boolean {
        if (j.optString("action") != "open_app") return true
        val pm = packageManager
        val apps = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
        val rows = apps.map { Pair(it.loadLabel(pm).toString(), it.activityInfo.packageName) }
        return matchContact(rows, j.optString("app", "")) != null
    }

    private fun handleReply(raw: String) {
        if (raw.startsWith("No pude") || raw.startsWith("Error") || raw.startsWith("Gemini")) {
            android.widget.Toast.makeText(this, raw, android.widget.Toast.LENGTH_LONG).show()
            say(raw)
            return
        }
        val json = try {
            JSONObject(raw.substring(raw.indexOf('{'), raw.lastIndexOf('}') + 1))
        } catch (e: Exception) {
            null
        }
        if (json == null) {
            say(raw)
            return
        }
        val speech = json.optString("say", "")
        val msg = try {
            runAction(json)
        } catch (e: Exception) {
            "No pude hacer eso: ${e.message}"
        }
        if (msg != null) android.widget.Toast.makeText(this, msg, android.widget.Toast.LENGTH_LONG).show()
        say(msg ?: speech.ifEmpty { "Listo." })
    }

    private fun newTask(i: Intent): Intent = i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)

    private fun runAction(j: JSONObject): String? {
        when (j.optString("action", "none")) {
            "alarm" -> startActivity(
                newTask(
                    Intent(AlarmClock.ACTION_SET_ALARM)
                        .putExtra(AlarmClock.EXTRA_HOUR, j.getInt("hour"))
                        .putExtra(AlarmClock.EXTRA_MINUTES, j.optInt("minute", 0))
                        .putExtra(AlarmClock.EXTRA_MESSAGE, j.optString("label", "Jarvis"))
                        .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
                )
            )
            "timer" -> startActivity(
                newTask(
                    Intent(AlarmClock.ACTION_SET_TIMER)
                        .putExtra(AlarmClock.EXTRA_LENGTH, j.getInt("seconds"))
                        .putExtra(AlarmClock.EXTRA_MESSAGE, j.optString("label", "Jarvis"))
                        .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
                )
            )
            "alarm_off" -> return deleteAlarm(j)
            "alarm_list" -> return alarmList()
            "read_messages" -> return readMessages(j.optString("contact", ""))
            "play_voice_note" -> return playVoiceNote()
            "send_whatsapp" -> return prepareSend(j.optString("contact", ""), j.optString("text", ""))
            "confirm_send" -> return confirmSend()
            "cancel_send" -> return cancelSend()
            "read_notifications" -> return readNotifications()
            "flashlight" -> setTorch(j.optBoolean("on", true))
            "dnd" -> return setDnd(j.optBoolean("on", true))
            "call" -> return callContact(j.optString("contact", ""))
            "calendar" -> return addEvent(j)
            "image_search" -> return openSearch(j.optString("query", ""), true)
            "web_search" -> return openSearch(j.optString("query", ""), false)
            "choose_contact" -> return chooseContact(j.optInt("option", 0))
            "reminder" -> return reminder(j)
            "list_add" -> return listAdd(j)
            "list_read" -> return listRead(j)
            "list_remove" -> return listRemove(j)
            "volume" -> return volume(j)
            "brightness" -> return brightness(j)
            "connectivity" -> return connectivity(j.optString("what", "wifi"))
            "system" -> return systemAction(j.optString("which", ""))
            "camera" -> startActivity(newTask(Intent(android.provider.MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA)))
            "play_music" -> return playMusic(j.optString("query", ""))
            "scan_chats" -> return scanChats()
            "handsfree" -> {
                val on = j.optBoolean("on", true)
                getSharedPreferences("jarvis", MODE_PRIVATE).edit().putBoolean("handsfree", on).apply()
                if (!on) stopWake()
                updateNotification()
                return if (on && lowBattery) "Lo activé, pero con la batería baja queda en pausa hasta que cargues." else null
            }
            "close_app" -> {
                if (!SendAccessibilityService.running) return "Necesito el permiso de accesibilidad para cerrar apps. Activalo desde la app de Jarvis."
                SendAccessibilityService.closeCurrentApp()
                return null
            }
            "diagnose" -> return diagnose()
            "guide" -> return startGuide(j.optString("topic", ""))
            "guide_next" -> return guideNext(j.optString("dir", "next"))
            "help" -> return helpText()
            "media" -> return mediaKey(j.optString("cmd", "play_pause"))
            "note_add" -> return noteAdd(j.optString("text", ""))
            "note_read" -> return noteRead(j.optString("which", "all"))
            "note_delete" -> return noteDelete(j.optString("which", "last"), j.optString("text", ""))
            "dictation" -> return startDictation()
            "read_mail" -> return readMail()
            "agenda" -> return agenda(j.optString("day", "today"))
            "open_app" -> return openApp(j.optString("app", ""), j.optString("query", ""))
            "remember" -> return remember(j.optString("text", ""))
            "forget" -> return forget(j.optString("text", ""))
            "create_file" -> return createFile(j.optString("name", ""), j.optString("content", ""))
        }
        return null
    }

    private fun openSearch(query: String, images: Boolean): String? {
        if (query.isBlank()) return "No entendí qué buscar."
        val url = "https://www.google.com/search?" + (if (images) "tbm=isch&" else "") + "q=" + Uri.encode(query)
        try {
            startActivity(newTask(Intent(Intent.ACTION_VIEW, Uri.parse(url)).setPackage("com.android.chrome")))
        } catch (e: Exception) {
            startActivity(newTask(Intent(Intent.ACTION_VIEW, Uri.parse(url))))
        }
        return null
    }

    private fun setTorch(on: Boolean) {
        val cm = getSystemService(CameraManager::class.java)
        val id = cm.cameraIdList.firstOrNull {
            cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
        } ?: return
        cm.setTorchMode(id, on)
    }

    private fun setDnd(on: Boolean): String? {
        val nm = getSystemService(NotificationManager::class.java)
        if (!nm.isNotificationPolicyAccessGranted) {
            startActivity(newTask(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)))
            return "Necesito permiso para No molestar. Activalo para Jarvis en la pantalla que se abrió."
        }
        nm.setInterruptionFilter(
            if (on) NotificationManager.INTERRUPTION_FILTER_PRIORITY
            else NotificationManager.INTERRUPTION_FILTER_ALL
        )
        return null
    }

    private fun norm(t: String): String =
        java.text.Normalizer.normalize(t, java.text.Normalizer.Form.NFD)
            .replace(Regex("\\p{InCombiningDiacriticalMarks}+"), "")
            .lowercase(Locale.ROOT)
            .trim()

    private fun alarmList(): String? {
        return try {
            startActivity(newTask(Intent(AlarmClock.ACTION_SHOW_ALARMS)))
            "Te abrí tus alarmas."
        } catch (e: Exception) {
            "No pude abrir la app de reloj."
        }
    }

    private fun deleteAlarm(j: JSONObject): String? {
        return try {
            val action = if (Build.VERSION.SDK_INT >= 36) "android.intent.action.DELETE_ALARM"
            else AlarmClock.ACTION_DISMISS_ALARM
            val i = Intent(action).putExtra(AlarmClock.EXTRA_SKIP_UI, true)
            if (j.has("hour")) {
                i.putExtra(AlarmClock.EXTRA_ALARM_SEARCH_MODE, AlarmClock.ALARM_SEARCH_MODE_TIME)
                    .putExtra(AlarmClock.EXTRA_HOUR, j.optInt("hour"))
                    .putExtra(AlarmClock.EXTRA_MINUTES, j.optInt("minute"))
            } else {
                i.putExtra(AlarmClock.EXTRA_ALARM_SEARCH_MODE, AlarmClock.ALARM_SEARCH_MODE_NEXT)
            }
            startActivity(newTask(i))
            "Listo, lo pedí. Si la alarma sigue en el reloj, decime: abrime las alarmas."
        } catch (e: android.content.ActivityNotFoundException) {
            alarmList()
        }
    }

    private fun key(t: String): String =
        norm(t).replace(Regex("\\b(numeral|almohadilla|hashtag)\\b"), "").replace(Regex("[^a-z0-9]"), "")

    private fun wordKeys(t: String): List<String> =
        norm(t).replace(Regex("\\b(numeral|almohadilla|hashtag)\\b"), " ")
            .split(Regex("\\s+"))
            .map { key(it) }
            .filter { it.isNotEmpty() && (it.length > 2 || it.all { c -> c.isDigit() }) }

    private fun lastSender(): String? =
        NotifStore.all(this).lastOrNull { it.app == "WhatsApp" }?.sender

    /** Busca el contacto que mejor coincida. rows = lista de (nombre, número). */
    private fun phon(t: String): String {
        var s = norm(t).replace(Regex("[^a-z0-9 ]"), " ")
        s = s.replace("ch", "x").replace("qu", "k").replace("ce", "se").replace("ci", "si")
            .replace("c", "k").replace("ll", "y").replace("z", "s").replace("v", "b")
            .replace("w", "b").replace("ph", "f").replace("h", "")
        return s.replace(Regex("(.)\\1+"), "\$1")
    }

    private fun lev(a: String, b: String): Int {
        val d = IntArray(b.length + 1) { it }
        for (i in 1..a.length) {
            var prev = d[0]
            d[0] = i
            for (j in 1..b.length) {
                val tmp = d[j]
                d[j] = minOf(d[j] + 1, d[j - 1] + 1, prev + if (a[i - 1] == b[j - 1]) 0 else 1)
                prev = tmp
            }
        }
        return d[b.length]
    }

    /** Qué tan parecido es un nombre a lo que dijo el usuario (menor = más parecido, null = no se parece). */
    private fun nameScore(words: List<String>, name: String, loose: Boolean): Int? {
        val tokens = phon(name).split(" ").filter { it.isNotEmpty() }
        if (tokens.isEmpty()) return null
        var total = 0
        for (w in words) {
            var best = Int.MAX_VALUE
            for (t in tokens) {
                val d = if (w.length >= 3 && t.startsWith(w)) 0 else lev(w, t)
                if (d < best) best = d
            }
            val limit = if (loose) maxOf(2, w.length / 2) else maxOf(1, w.length / 4)
            if (best > limit) return null
            total += best
        }
        return total
    }

    private fun fuzzyContact(rows: List<Pair<String, String>>, spoken: String): Pair<String, String>? {
        val words = phon(spoken).split(" ").filter { it.length >= 2 }
        if (words.isEmpty()) return null
        var best: Pair<String, String>? = null
        var bestScore = Int.MAX_VALUE
        for (r in rows) {
            val sc = nameScore(words, r.first, false) ?: continue
            if (sc < bestScore) { bestScore = sc; best = r }
        }
        return best
    }

    private fun closestNames(rows: List<Pair<String, String>>, spoken: String): List<String> {
        val words = phon(spoken).split(" ").filter { it.length >= 2 }
        if (words.isEmpty()) return emptyList()
        return rows.mapNotNull { r -> nameScore(words, r.first, true)?.let { Pair(r.first, it) } }
            .sortedBy { it.second }.map { it.first }.distinct().take(3)
    }

    private fun matchContact(rows: List<Pair<String, String>>, spoken: String, fuzzy: Boolean = true): Pair<String, String>? {
        val wantedKey = key(spoken)
        val words = wordKeys(spoken)
        if (wantedKey.isEmpty()) return null
        rows.firstOrNull { key(it.first).contains(wantedKey) }?.let { return it }
        if (words.isNotEmpty()) {
            rows.firstOrNull { r -> val k = key(r.first); words.all { w -> k.contains(w) } }?.let { return it }
        }
        return if (fuzzy) fuzzyContact(rows, spoken) else null
    }

    private fun phoneRows(): List<Pair<String, String>> {
        val out = ArrayList<Pair<String, String>>()
        val cursor = contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                ContactsContract.CommonDataKinds.Phone.NUMBER
            ),
            null, null, null
        )
        cursor?.use {
            while (it.moveToNext()) {
                val n = it.getString(0) ?: continue
                val num = it.getString(1) ?: continue
                out.add(Pair(n, num))
            }
        }
        return out
    }

    private fun whatsappRows(): List<Pair<String, String>> {
        val out = ArrayList<Pair<String, String>>()
        val cursor = contentResolver.query(
            ContactsContract.Data.CONTENT_URI,
            arrayOf(ContactsContract.Data.DISPLAY_NAME, ContactsContract.Data.DATA1),
            "${ContactsContract.Data.MIMETYPE} = ?",
            arrayOf("vnd.android.cursor.item/vnd.com.whatsapp.profile"),
            null
        )
        cursor?.use {
            while (it.moveToNext()) {
                val n = it.getString(0) ?: continue
                val jid = it.getString(1) ?: continue
                val digits = jid.substringBefore('@').filter { c -> c.isDigit() }
                if (digits.isNotEmpty()) out.add(Pair(n, digits))
            }
        }
        return out
    }

    private fun notifRows(): List<Pair<String, String>> {
        val p = getSharedPreferences("jarvis_numbers", MODE_PRIVATE)
        val out = ArrayList<Pair<String, String>>()
        for ((k, v) in p.all) {
            val num = (v as? String) ?: continue
            if (num.isNotEmpty()) out.add(Pair(k, num))
        }
        return out
    }

    private fun memoryList(): MutableList<String> {
        val raw = getSharedPreferences("jarvis_memory", MODE_PRIVATE).getString("items", "[]") ?: "[]"
        val out = ArrayList<String>()
        try {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) out.add(arr.getString(i))
        } catch (e: Exception) {
        }
        return out
    }

    private fun saveMemory(list: List<String>) {
        val arr = JSONArray()
        list.takeLast(60).forEach { arr.put(it) }
        getSharedPreferences("jarvis_memory", MODE_PRIVATE).edit().putString("items", arr.toString()).apply()
    }

    private fun remember(text: String): String? {
        val t = text.trim()
        if (t.isEmpty()) return "No entendí qué recordar."
        val list = memoryList()
        if (list.none { norm(it) == norm(t) }) list.add(t.take(300))
        saveMemory(list)
        return null
    }

    private fun forget(text: String): String? {
        val w = norm(text)
        if (w.isEmpty()) return "No entendí qué olvidar."
        val list = memoryList()
        val keep = list.filter { !norm(it).contains(w) }
        saveMemory(keep)
        return if (keep.size == list.size) "No tenía nada guardado sobre eso." else null
    }

    // ---------- Recordatorios, listas y controles del teléfono ----------

    private fun reminder(j: JSONObject): String? {
        val text = j.optString("text", "").ifBlank { "Recordatorio" }
        val parsed: java.util.Date? = try {
            SimpleDateFormat("yyyy-MM-dd'T'HH:mm", Locale.US).parse(j.optString("start"))
        } catch (e: Exception) {
            null
        }
        val start = parsed ?: return "No entendí cuándo recordártelo."
        val diff = start.time - System.currentTimeMillis()
        if (diff < 0) return "Esa hora ya pasó."
        if (diff <= 23 * 3600 * 1000L) {
            val c = java.util.Calendar.getInstance().apply { time = start }
            startActivity(
                newTask(
                    Intent(AlarmClock.ACTION_SET_ALARM)
                        .putExtra(AlarmClock.EXTRA_HOUR, c.get(java.util.Calendar.HOUR_OF_DAY))
                        .putExtra(AlarmClock.EXTRA_MINUTES, c.get(java.util.Calendar.MINUTE))
                        .putExtra(AlarmClock.EXTRA_MESSAGE, text)
                        .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
                )
            )
            return null
        }
        return addEvent(JSONObject().put("title", text).put("start", j.optString("start")).put("minutes", 15))
    }

    private fun listsLoad(): JSONObject = try {
        JSONObject(getSharedPreferences("jarvis_lists", MODE_PRIVATE).getString("data", "{}") ?: "{}")
    } catch (e: Exception) {
        JSONObject()
    }

    private fun listsSave(o: JSONObject) {
        getSharedPreferences("jarvis_lists", MODE_PRIVATE).edit().putString("data", o.toString()).apply()
    }

    private fun itemsOf(j: JSONObject): List<String> {
        val arr = j.optJSONArray("items")
        if (arr != null) return (0 until arr.length()).map { arr.optString(it) }.filter { it.isNotBlank() }
        return j.optString("items", "").split(",").map { it.trim() }.filter { it.isNotEmpty() }
    }

    private fun listNameOf(j: JSONObject): String =
        j.optString("list", "").trim().ifEmpty { "compras" }.lowercase(Locale.ROOT)

    private fun listAdd(j: JSONObject): String? {
        val name = listNameOf(j)
        val items = itemsOf(j)
        if (items.isEmpty()) return "No entendí qué agregar."
        val all = listsLoad()
        val arr = all.optJSONArray(name) ?: JSONArray()
        items.forEach { arr.put(it) }
        all.put(name, arr)
        listsSave(all)
        return null
    }

    private fun listRead(j: JSONObject): String? {
        val name = listNameOf(j)
        val arr = listsLoad().optJSONArray(name)
        if (arr == null || arr.length() == 0) return "Tu lista de $name está vacía."
        val items = (0 until arr.length()).map { arr.optString(it) }
        return "Tu lista de $name: " + items.joinToString(", ") + "."
    }

    private fun listRemove(j: JSONObject): String? {
        val name = listNameOf(j)
        val all = listsLoad()
        val arr = all.optJSONArray(name) ?: return "Tu lista de $name está vacía."
        val items = itemsOf(j)
        if (items.isEmpty()) {
            all.remove(name)
            listsSave(all)
            return "Listo, vacié la lista de $name."
        }
        val keep = JSONArray()
        var removed = 0
        for (i in 0 until arr.length()) {
            val cur = arr.optString(i)
            if (items.any { w -> norm(cur).contains(norm(w)) }) removed++ else keep.put(cur)
        }
        all.put(name, keep)
        listsSave(all)
        return if (removed == 0) "No encontré eso en la lista." else null
    }

    private fun volume(j: JSONObject): String? {
        val am = getSystemService(android.media.AudioManager::class.java)
        val st = android.media.AudioManager.STREAM_MUSIC
        val ui = android.media.AudioManager.FLAG_SHOW_UI
        val max = am.getStreamMaxVolume(st)
        when (j.optString("mode", "up")) {
            "up" -> am.adjustStreamVolume(st, android.media.AudioManager.ADJUST_RAISE, ui)
            "down" -> am.adjustStreamVolume(st, android.media.AudioManager.ADJUST_LOWER, ui)
            "mute" -> am.adjustStreamVolume(st, android.media.AudioManager.ADJUST_MUTE, ui)
            "unmute" -> am.adjustStreamVolume(st, android.media.AudioManager.ADJUST_UNMUTE, ui)
            "max" -> am.setStreamVolume(st, max, ui)
            "level" -> am.setStreamVolume(st, (max * j.optInt("percent", 50) / 100).coerceIn(0, max), ui)
        }
        return null
    }

    private fun brightness(j: JSONObject): String? {
        if (!Settings.System.canWrite(this)) {
            startActivity(newTask(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:$packageName"))))
            return "Necesito permiso para cambiar el brillo. Activalo para Jarvis en la pantalla que se abrió."
        }
        val pct = j.optInt("percent", 50).coerceIn(1, 100)
        Settings.System.putInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS_MODE, Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL)
        Settings.System.putInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS, pct * 255 / 100)
        return null
    }

    private fun connectivity(what: String): String? {
        val action = if (Build.VERSION.SDK_INT >= 29) {
            when (what) {
                "volume" -> Settings.Panel.ACTION_VOLUME
                "nfc" -> Settings.Panel.ACTION_NFC
                "airplane" -> Settings.ACTION_AIRPLANE_MODE_SETTINGS
                "bluetooth" -> Settings.ACTION_BLUETOOTH_SETTINGS
                else -> Settings.Panel.ACTION_INTERNET_CONNECTIVITY
            }
        } else if (what == "bluetooth") Settings.ACTION_BLUETOOTH_SETTINGS else Settings.ACTION_WIFI_SETTINGS
        startActivity(newTask(Intent(action)))
        return "Android no me deja cambiar eso solo. Te abrí el panel para que lo toques."
    }

    private fun systemAction(which: String): String? {
        val svc = SendAccessibilityService.instance
            ?: return "Necesito el permiso de accesibilidad para eso. Activalo desde la app de Jarvis."
        val code = when (which) {
            "screenshot" -> android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_TAKE_SCREENSHOT
            "home" -> android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_HOME
            "back" -> android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_BACK
            "recents" -> android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_RECENTS
            "lock" -> android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_LOCK_SCREEN
            "notifications" -> android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS
            else -> return "No sé hacer eso todavía."
        }
        return if (svc.performGlobalAction(code)) null else "No pude hacerlo."
    }

    private fun playMusic(q: String): String? {
        if (q.isBlank()) return "No entendí qué música poner."
        val i = Intent("android.media.action.MEDIA_PLAY_FROM_SEARCH")
            .putExtra(android.app.SearchManager.QUERY, q)
            .putExtra("android.intent.extra.focus", "vnd.android.cursor.item/*")
        return try {
            startActivity(newTask(i))
            null
        } catch (e: Exception) {
            openApp("YouTube", q)
        }
    }

    private fun scanChats(): String? {
        if (!SendAccessibilityService.running) {
            return "Necesito el permiso de accesibilidad. Activalo desde la app de Jarvis."
        }
        if (!openWhatsApp()) return "No encontré WhatsApp."
        SendAccessibilityService.startScan()
        return "Voy a leer tus chats de WhatsApp, esperá un momento."
    }

    private fun openApp(name: String, query: String): String? {
        if (name.isBlank()) return "No entendí qué app abrir."
        val pm = packageManager
        val launch = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(launch, 0)
        if (apps.isEmpty()) return "No puedo ver las apps instaladas."
        val rows = apps.map { Pair(it.loadLabel(pm).toString(), it.activityInfo.packageName) }
        val m = matchContact(rows, name) ?: return "No encontré la app $name."
        val pkg = m.second
        val q = query.trim()
        if (q.isNotEmpty()) {
            val uri: String? = when (pkg) {
                "com.google.android.youtube" -> "https://www.youtube.com/results?search_query=" + Uri.encode(q)
                "com.spotify.music" -> "spotify:search:" + Uri.encode(q)
                "com.google.android.apps.maps" -> "geo:0,0?q=" + Uri.encode(q)
                "com.instagram.android" -> if (q.contains(" ")) null else "instagram://user?username=" + Uri.encode(q.removePrefix("@"))
                else -> null
            }
            if (uri != null) {
                try {
                    startActivity(newTask(Intent(Intent.ACTION_VIEW, Uri.parse(uri)).setPackage(pkg)))
                    return null
                } catch (e: Exception) {
                }
            }
        }
        val li = pm.getLaunchIntentForPackage(pkg) ?: return "No pude abrir ${m.first}."
        startActivity(newTask(li))
        return if (q.isNotEmpty()) "Abrí ${m.first}, pero buscar adentro de esa app todavía no puedo." else null
    }

    private fun createFile(name: String, content: String): String? {
        if (Build.VERSION.SDK_INT >= 30 && !android.os.Environment.isExternalStorageManager()) {
            return "Necesito el permiso de archivos. Tocá ese botón en la app de Jarvis."
        }
        val clean = name.replace("..", "").replace("\\", "/").trim().trim('/').ifBlank { "nota.txt" }
        val base = java.io.File(
            android.os.Environment.getExternalStoragePublicDirectory(android.os.Environment.DIRECTORY_DOCUMENTS),
            "Jarvis"
        )
        val f = java.io.File(base, clean)
        f.parentFile?.mkdirs()
        f.writeText(content)
        return "Listo, guardé ${f.name} en Documentos, carpeta Jarvis."
    }

    private val STOP = setOf("los", "las", "del", "una", "uno", "que", "con", "mis")

    private fun spokenWords(t: String): List<String> = wordKeys(t).filter { it !in STOP }

    /** Junta todos los contactos conocidos (agenda, WhatsApp y quienes te escribieron) sin repetir nombres. */
    private fun allRows(includeReply: Boolean): List<Pair<String, String>> {
        val out = ArrayList<Pair<String, String>>()
        val seen = HashSet<String>()
        fun add(name: String, num: String) {
            val k = key(name)
            if (k.isEmpty() || !seen.add(k)) return
            out.add(Pair(name, num))
        }
        phoneRows().forEach { add(it.first, it.second) }
        whatsappRows().forEach { add(it.first, "+" + it.second) }
        notifRows().forEach { add(it.first, "+" + it.second) }
        if (includeReply) {
            ReplyStore.names().forEach { add(it, "") }
            getSharedPreferences("jarvis_chats", MODE_PRIVATE).all.keys.forEach { add(it, "") }
            NotifStore.all(this).filter { it.app == "WhatsApp" }.forEach {
                add(it.sender.replace(Regex("\\s*\\(\\d+\\s+(mensajes?|messages?)\\)\\s*$"), "").trim(), "")
            }
        }
        return out
    }

    /** Todos los contactos que pueden ser el que dijo el usuario, sin importar cómo estén escritos. */
    private fun candidates(rows: List<Pair<String, String>>, spoken: String): List<Pair<String, String>> {
        val wantedKey = key(spoken)
        if (wantedKey.isEmpty()) return emptyList()
        val words = spokenWords(spoken)
        if (words.isNotEmpty()) {
            // 1) cada palabra dicha es una palabra completa del nombre (ej. "creadora" en "La Creadora 💜")
            val t0 = rows.filter { r -> val tk = wordKeys(r.first); words.all { w -> w in tk } }
            if (t0.isNotEmpty()) return t0
            // 2) el nombre contiene las palabras dichas en cualquier lugar
            val t1 = rows.filter { r -> val k = key(r.first); words.all { w -> k.contains(w) } }
            if (t1.isNotEmpty()) return t1
        }
        val t2 = rows.filter { key(it.first).contains(wantedKey) }
        if (t2.isNotEmpty()) return t2
        // 3) parecido por sonido (por si el reconocimiento de voz lo escribió distinto)
        var pw = phon(spoken).split(" ").filter { it.length >= 3 && it !in STOP }
        if (pw.isEmpty()) pw = phon(spoken).split(" ").filter { it.length >= 2 }
        if (pw.isEmpty()) return emptyList()
        val scored = rows.mapNotNull { r -> nameScore(pw, r.first, false)?.let { Pair(r, it) } }
        val best = scored.minOfOrNull { it.second } ?: return emptyList()
        return scored.filter { it.second == best }.map { it.first }
    }

    private fun askWhich(kind: String, cands: List<Pair<String, String>>, text: String): String {
        val list = cands.take(4)
        getSharedPreferences("jarvis", MODE_PRIVATE).edit()
            .putString("choice_kind", kind)
            .putString("choice_names", list.joinToString("\u0001") { it.first })
            .putString("choice_numbers", list.joinToString("\u0001") { it.second })
            .putString("choice_text", text)
            .apply()
        val opts = list.mapIndexed { i, c -> "${i + 1}, ${c.first}" }.joinToString(". ")
        return "Encontré ${list.size}: $opts. ¿Cuál?"
    }

    private fun clearChoice() {
        getSharedPreferences("jarvis", MODE_PRIVATE).edit()
            .remove("choice_kind").remove("choice_names").remove("choice_numbers").remove("choice_text").apply()
    }

    private fun chooseContact(option: Int): String? {
        val prefs = getSharedPreferences("jarvis", MODE_PRIVATE)
        val kind = prefs.getString("choice_kind", null) ?: return "No tengo ninguna elección pendiente."
        val names = (prefs.getString("choice_names", "") ?: "").split("\u0001")
        val numbers = (prefs.getString("choice_numbers", "") ?: "").split("\u0001")
        val text = prefs.getString("choice_text", "") ?: ""
        if (option < 1 || option > names.size) return "No entendí cuál. Decime el número."
        clearChoice()
        val c = Pair(names[option - 1], numbers.getOrElse(option - 1) { "" })
        return if (kind == "call") placeCall(c) else stageSend(c, text)
    }

    private fun openWhatsApp(): Boolean {
        val pm = packageManager
        val li = pm.getLaunchIntentForPackage("com.whatsapp") ?: pm.getLaunchIntentForPackage("com.whatsapp.w4b") ?: return false
        startActivity(newTask(li))
        return true
    }

    private fun placeCall(match: Pair<String, String>): String? {
        // Preferimos llamar por WhatsApp, buscando el chat por nombre.
        if (SendAccessibilityService.running && openWhatsApp()) {
            SendAccessibilityService.startFlow(match.first, "", true)
            return "Llamando a ${match.first} por WhatsApp."
        }
        if (match.second.isBlank()) {
            return "Para llamar por WhatsApp necesito el permiso de accesibilidad. Activalo desde la app de Jarvis."
        }
        startActivity(newTask(Intent(Intent.ACTION_CALL, Uri.parse("tel:" + Uri.encode(match.second)))))
        return "Llamando a ${match.first}."
    }

    private fun stageSend(target: Pair<String, String>, text: String): String? {
        getSharedPreferences("jarvis", MODE_PRIVATE).edit()
            .putString("send_name", target.first)
            .putString("send_number", target.second.filter { it.isDigit() })
            .putString("send_text", text)
            .apply()
        return "Le voy a escribir a ${target.first}: $text. ¿Lo envío?"
    }

    private fun callContact(name: String): String? {
        if (checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
            return "Me faltan los permisos de contactos. Dalos desde la app de Jarvis."
        }
        val spoken = if (key(name).isEmpty()) {
            lastSender() ?: return "No tengo ningún mensaje reciente para saber a quién llamar."
        } else name
        val rows = allRows(true)
        if (rows.isEmpty()) return "No veo ningún contacto ni chat. Revisá el permiso de contactos de Jarvis."
        val c = candidates(rows, spoken)
        if (c.size == 1) return placeCall(c[0])
        if (c.size > 1) return askWhich("call", c, "")
        val cerca = closestNames(rows, spoken)
        return if (cerca.isNotEmpty()) "No encontré a $spoken. ¿Quisiste decir ${cerca.joinToString(" o ")}?"
        else "No encontré a $spoken entre ${rows.size} contactos. Escuché: $heard."
    }

    private fun prepareSend(contact: String, text: String): String? {
        if (checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
            return "Me faltan los permisos de contactos. Dalos desde la app de Jarvis."
        }
        if (text.isBlank()) return "No entendí qué mensaje enviar."
        val spoken = if (key(contact).isEmpty()) {
            lastSender() ?: return "No tengo ningún mensaje reciente para saber a quién escribirle."
        } else contact
        val rows = allRows(true)
        val c = candidates(rows, spoken)
        if (c.size == 1) return stageSend(c[0], text)
        if (c.size > 1) return askWhich("send", c, text)
        val cerca = closestNames(rows, spoken)
        return if (cerca.isNotEmpty()) "No encontré a $spoken. ¿Quisiste decir ${cerca.joinToString(" o ")}?"
        else "No encontré a $spoken para escribirle. Escuché: $heard."
    }

    private fun cancelSend(): String? {
        getSharedPreferences("jarvis", MODE_PRIVATE).edit()
            .remove("send_name").remove("send_number").remove("send_text")
            .remove("choice_kind").remove("choice_names").remove("choice_numbers").remove("choice_text").apply()
        return null
    }

    private fun confirmSend(): String? {
        val prefs = getSharedPreferences("jarvis", MODE_PRIVATE)
        val number = prefs.getString("send_number", null) ?: return "No tengo ningún mensaje pendiente de enviar."
        val text = prefs.getString("send_text", "") ?: ""
        val name = prefs.getString("send_name", "") ?: ""
        cancelSend()
        if (number.isEmpty()) {
            if (ReplyStore.send(this, name, text)) return "Mensaje enviado a $name."
            if (SendAccessibilityService.running && openWhatsApp()) {
                SendAccessibilityService.startFlow(name, text, false)
                return null
            }
            return "Para escribirle a $name necesito el permiso de accesibilidad. Activalo desde la app de Jarvis."
        }
        SendAccessibilityService.armedUntil = System.currentTimeMillis() + 20000
        val uri = Uri.parse("https://wa.me/$number?text=" + Uri.encode(text))
        try {
            startActivity(newTask(Intent(Intent.ACTION_VIEW, uri).setPackage("com.whatsapp")))
        } catch (e: android.content.ActivityNotFoundException) {
            startActivity(newTask(Intent(Intent.ACTION_VIEW, uri)))
        }
        return if (SendAccessibilityService.running) null
        else "Abrí el chat con el mensaje listo, pero me falta el permiso de accesibilidad para enviarlo solo."
    }

    /** Busca mensajes de un contacto aunque el nombre dicho no coincida exacto con el de la notificación. */
    private fun findMessagesFor(contact: String, items: List<NotifStore.Item>): List<NotifStore.Item> {
        val wanted = norm(contact)
        val wantedKey = key(contact)
        // 1) coincidencia directa por nombre dicho
        items.filter { norm(it.sender).contains(wanted) || (wantedKey.isNotEmpty() && key(it.sender).contains(wantedKey)) }
            .takeIf { it.isNotEmpty() }?.let { return it.takeLast(3) }
        // 2) resolver el nombre contra la agenda y buscar por el nombre guardado
        if (checkSelfPermission(Manifest.permission.READ_CONTACTS) == PackageManager.PERMISSION_GRANTED) {
            val resolved = matchContact(phoneRows(), contact) ?: matchContact(whatsappRows(), contact)
            if (resolved != null) {
                val rk = key(resolved.first)
                items.filter { rk.isNotEmpty() && (key(it.sender).contains(rk) || rk.contains(key(it.sender))) }
                    .takeIf { it.isNotEmpty() }?.let { return it.takeLast(3) }
            }
        }
        // 3) parecido por sonido contra los remitentes guardados
        val words = phon(contact).split(" ").filter { it.length >= 2 }
        if (words.isEmpty()) return emptyList()
        val scored = items.mapNotNull { i -> nameScore(words, i.sender, true)?.let { Pair(i, it) } }
        val best = scored.minOfOrNull { it.second } ?: return emptyList()
        return scored.filter { it.second == best }.map { it.first }.takeLast(3)
    }

    private fun readMessages(contact: String): String? {
        clearPending()
        val wanted = norm(contact)
        val items = NotifStore.all(this).filter { it.app == "WhatsApp" }
        val list = if (wanted.isEmpty()) items.takeLast(3) else findMessagesFor(contact, items)
        if (list.isEmpty()) {
            return if (wanted.isEmpty()) "No tengo mensajes recientes de WhatsApp."
            else "No tengo mensajes recientes de $contact."
        }
        return list.joinToString(" ") { "${it.sender} dice: ${it.text}." }
    }

    private fun readNotifications(): String? {
        val list = NotifStore.all(this).takeLast(5)
        if (list.isEmpty()) {
            return "No tengo notificaciones guardadas. Revisá que Jarvis tenga acceso a las notificaciones."
        }
        return list.joinToString(" ") { "${it.app}: ${it.sender}. ${it.text}." }
    }

    fun announce(sender: String, voice: Boolean = false) {
        main.post {
            getSharedPreferences("jarvis", MODE_PRIVATE).edit()
                .putString("pending_sender", sender)
                .putString("pending_type", if (voice) "voice" else "text")
                .apply()
            val frase = if (voice) "Señor, $sender le mandó un audio. ¿Quiere que lo reproduzca?"
            else "Señor, le escribió $sender. ¿Quiere saber qué dice?"
            speak(frase)
        }
    }

    private fun clearPending() {
        getSharedPreferences("jarvis", MODE_PRIVATE).edit()
            .remove("pending_sender").remove("pending_type").apply()
    }

    private fun findLastVoiceNote(): java.io.File? {
        val roots = listOf(
            "/storage/emulated/0/Android/media/com.whatsapp/WhatsApp/Media/WhatsApp Voice Notes",
            "/storage/emulated/0/Android/media/com.whatsapp.w4b/WhatsApp Business/Media/WhatsApp Business Voice Notes",
            "/storage/emulated/0/WhatsApp/Media/WhatsApp Voice Notes"
        )
        val all = roots.flatMap { r ->
            val dir = java.io.File(r)
            if (!dir.exists()) emptyList<java.io.File>()
            else dir.walkTopDown().filter { it.isFile && it.extension.lowercase() in listOf("opus", "ogg", "m4a", "mp3", "aac") }.toList()
        }
        return all.maxByOrNull { it.lastModified() }
    }

    private fun playVoiceNote(): String? {
        clearPending()
        if (Build.VERSION.SDK_INT >= 30 && !android.os.Environment.isExternalStorageManager()) {
            return "Necesito el permiso de audios de WhatsApp. Tocá ese botón en la app de Jarvis."
        }
        val file = (try { findLastVoiceNote() } catch (e: Exception) { null })
            ?: return "No encontré audios en la carpeta de WhatsApp."
        main.postDelayed({
            try {
                player?.release()
                player = android.media.MediaPlayer().apply {
                    setDataSource(file.absolutePath)
                    setOnCompletionListener { mp -> mp.release() }
                    prepare()
                    start()
                }
            } catch (e: Exception) {
                android.widget.Toast.makeText(this, "No pude reproducir el audio: ${e.message}", android.widget.Toast.LENGTH_LONG).show()
            }
        }, 2500)
        return null
    }

    /** Elige el calendario de tu cuenta de Google (el que ves en la app Calendario). */
    private fun writableCalendar(): Pair<Long, String>? {
        val cols = arrayOf(CalendarContract.Calendars._ID, CalendarContract.Calendars.ACCOUNT_TYPE, CalendarContract.Calendars.ACCOUNT_NAME, CalendarContract.Calendars.OWNER_ACCOUNT, CalendarContract.Calendars.CALENDAR_ACCESS_LEVEL, CalendarContract.Calendars.IS_PRIMARY)
        val sel = "${CalendarContract.Calendars.CALENDAR_ACCESS_LEVEL} >= ${CalendarContract.Calendars.CAL_ACCESS_CONTRIBUTOR} AND ${CalendarContract.Calendars.VISIBLE} = 1"
        class Cal(val id: Long, val type: String, val name: String, val owner: String, val level: Int, val primary: Boolean)
        val all = ArrayList<Cal>()
        contentResolver.query(CalendarContract.Calendars.CONTENT_URI, cols, sel, null, null)?.use { c ->
            while (c.moveToNext()) {
                all.add(Cal(c.getLong(0), c.getString(1) ?: "", c.getString(2) ?: "", c.getString(3) ?: "", c.getInt(4), c.getInt(5) == 1))
            }
        }
        val pick = all.firstOrNull { it.type == "com.google" && it.name == it.owner && it.level >= 500 }
            ?: all.firstOrNull { it.type == "com.google" && it.level >= 500 }
            ?: all.firstOrNull { it.primary && it.type != "LOCAL" }
            ?: all.firstOrNull { it.level >= 700 && it.type != "LOCAL" }
            ?: all.firstOrNull { it.level >= 500 }
            ?: all.firstOrNull()
        return pick?.let { Pair(it.id, it.name) }
    }

    private fun addEvent(j: JSONObject): String? {
        val start = SimpleDateFormat("yyyy-MM-dd'T'HH:mm", Locale.US).parse(j.getString("start"))
            ?: return "No entendí la fecha."
        val minutes = j.optInt("minutes", 60)
        val title = j.optString("title", "Evento")
        val allDay = j.optBoolean("allday", false)
        // Si tengo permiso de calendario lo agendo directo; si no, abro el calendario para que lo confirmes.
        if (checkSelfPermission(Manifest.permission.WRITE_CALENDAR) == PackageManager.PERMISSION_GRANTED) {
            try {
                val calPick = writableCalendar()
                if (calPick != null) {
                    val calId = calPick.first
                    val values = android.content.ContentValues()
                    values.put(CalendarContract.Events.CALENDAR_ID, calId)
                    values.put(CalendarContract.Events.TITLE, title)
                    if (allDay) {
                        val utc = java.util.Calendar.getInstance(java.util.TimeZone.getTimeZone("UTC"))
                        val loc = java.util.Calendar.getInstance().apply { time = start }
                        utc.clear()
                        utc.set(loc.get(java.util.Calendar.YEAR), loc.get(java.util.Calendar.MONTH), loc.get(java.util.Calendar.DAY_OF_MONTH))
                        values.put(CalendarContract.Events.DTSTART, utc.timeInMillis)
                        values.put(CalendarContract.Events.DTEND, utc.timeInMillis + 86400000L)
                        values.put(CalendarContract.Events.ALL_DAY, 1)
                        values.put(CalendarContract.Events.EVENT_TIMEZONE, "UTC")
                    } else {
                        values.put(CalendarContract.Events.DTSTART, start.time)
                        values.put(CalendarContract.Events.DTEND, start.time + minutes * 60000L)
                        values.put(CalendarContract.Events.EVENT_TIMEZONE, java.util.TimeZone.getDefault().id)
                    }
                    val uri = contentResolver.insert(CalendarContract.Events.CONTENT_URI, values)
                    if (uri != null) {
                        try {
                            val rv = android.content.ContentValues()
                            rv.put(CalendarContract.Reminders.EVENT_ID, android.content.ContentUris.parseId(uri))
                            rv.put(CalendarContract.Reminders.MINUTES, 15)
                            rv.put(CalendarContract.Reminders.METHOD, CalendarContract.Reminders.METHOD_ALERT)
                            contentResolver.insert(CalendarContract.Reminders.CONTENT_URI, rv)
                        } catch (e: Exception) {
                        }
                        val whenTxt = SimpleDateFormat(
                            if (allDay) "EEEE d 'de' MMMM" else "EEEE d 'de' MMMM 'a las' HH:mm",
                            Locale("es", "AR")
                        ).format(start)
                        return "Agendado en tu calendario ${calPick.second}: $title, $whenTxt."
                    }
                }
            } catch (e: Exception) {
            }
        }
        val end = start.time + minutes * 60000L
        startActivity(
            newTask(
                Intent(Intent.ACTION_INSERT)
                    .setData(CalendarContract.Events.CONTENT_URI)
                    .putExtra(CalendarContract.Events.TITLE, title)
                    .putExtra(CalendarContract.EXTRA_EVENT_BEGIN_TIME, start.time)
                    .putExtra(CalendarContract.EXTRA_EVENT_END_TIME, end)
            )
        )
        return "Te abrí el calendario para que confirmes el evento. Para agendar directo, activá el permiso de calendario."
    }

    private fun post(key: String, model: String, body: JSONObject, readMs: Int = 90000): Pair<Int, String> {
        try {
            return postOnce(key, model, body, readMs)
        } catch (e: java.net.SocketTimeoutException) {
            return Pair(504, "timeout")
        }
    }

    private fun postOnce(key: String, model: String, body: JSONObject, readMs: Int): Pair<Int, String> {
        val url = URL("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent")
        val c = url.openConnection() as HttpURLConnection
        c.requestMethod = "POST"
        c.connectTimeout = 10000
        c.readTimeout = readMs
        c.doOutput = true
        c.setRequestProperty("Content-Type", "application/json")
        c.setRequestProperty("x-goog-api-key", key)
        c.outputStream.use { it.write(body.toString().toByteArray()) }
        val code = c.responseCode
        val stream = if (code in 200..299) c.inputStream else c.errorStream
        val txt = stream?.bufferedReader()?.readText() ?: ""
        return Pair(code, txt)
    }

    // ---------- IAs rápidas gratuitas (Groq, Cerebras) con respaldo en Gemini ----------

    private fun pickModel(name: String, base: String, key: String): String? {
        val prefs = getSharedPreferences("jarvis", MODE_PRIVATE)
        prefs.getString("${name}_model", null)?.let { if (it.isNotBlank()) return it }
        val c = URL("$base/models").openConnection() as HttpURLConnection
        c.connectTimeout = 6000
        c.readTimeout = 8000
        c.setRequestProperty("Authorization", "Bearer $key")
        if (c.responseCode !in 200..299) return null
        val ids = ArrayList<String>()
        val data = JSONObject(c.inputStream.bufferedReader().use { it.readText() }).optJSONArray("data") ?: return null
        for (i in 0 until data.length()) ids.add(data.getJSONObject(i).optString("id"))
        val prefer = if (name == "groq")
            listOf("llama-3.3-70b-versatile", "llama-3.3-70b", "llama-3.1-70b", "gpt-oss-120b", "llama-3.1-8b-instant")
        else listOf("llama-3.3-70b", "gpt-oss-120b", "llama3.1-8b", "qwen-3-32b", "llama")
        var chosen: String? = null
        for (p in prefer) {
            chosen = ids.firstOrNull { it.contains(p) }
            if (chosen != null) break
        }
        if (chosen == null) chosen = ids.firstOrNull { !Regex("whisper|guard|embed|tts|distil|vision|orpheus|safeguard").containsMatchIn(it) }
        if (chosen != null) prefs.edit().putString("${name}_model", chosen).apply()
        return chosen
    }

    private fun openAiChat(name: String, base: String, key: String, system: String, question: String): String? {
        val prefs = getSharedPreferences("jarvis", MODE_PRIVATE)
        val model = pickModel(name, base, key) ?: return null
        val msgs = JSONArray().put(JSONObject().put("role", "system").put("content", system))
        for ((role, text) in history.toList().takeLast(6)) {
            msgs.put(JSONObject().put("role", if (role == "model") "assistant" else "user").put("content", text))
        }
        msgs.put(JSONObject().put("role", "user").put("content", question))
        var useJsonMode = true
        for (attempt in 0 until 2) {
            val body = JSONObject().put("model", model).put("messages", msgs)
                .put("temperature", 0.3).put("max_tokens", 700)
            if (useJsonMode) body.put("response_format", JSONObject().put("type", "json_object"))
            val c = URL("$base/chat/completions").openConnection() as HttpURLConnection
            c.requestMethod = "POST"
            c.connectTimeout = 6000
            c.readTimeout = 12000
            c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json")
            c.setRequestProperty("Authorization", "Bearer $key")
            c.outputStream.use { it.write(body.toString().toByteArray()) }
            val code = c.responseCode
            val txt = (if (code in 200..299) c.inputStream else c.errorStream)?.bufferedReader()?.use { it.readText() } ?: ""
            if (code == 429 || code >= 500) {
                prefs.edit().putLong("${name}_cool", System.currentTimeMillis() + 60000L).apply()
                return null
            }
            if (code == 400 && useJsonMode) {
                useJsonMode = false
                continue
            }
            if (code == 400 || code == 404) {
                prefs.edit().remove("${name}_model").apply()
                return null
            }
            if (code !in 200..299) return null
            val content = JSONObject(txt).optJSONArray("choices")?.optJSONObject(0)
                ?.optJSONObject("message")?.optString("content", "") ?: ""
            val a = content.indexOf('{')
            val b = content.lastIndexOf('}')
            if (a < 0 || b <= a) return null
            val json = content.substring(a, b + 1)
            return try {
                JSONObject(json)
                json
            } catch (e: Exception) {
                null
            }
        }
        return null
    }

    private fun callFastProviders(system: String, question: String): String? {
        val prefs = getSharedPreferences("jarvis", MODE_PRIVATE)
        val providers = listOf(
            Triple("groq", "https://api.groq.com/openai/v1", prefs.getString("groq_key", "") ?: ""),
            Triple("cerebras", "https://api.cerebras.ai/v1", prefs.getString("cerebras_key", "") ?: "")
        )
        for ((name, base, k) in providers) {
            if (k.isBlank()) continue
            if (System.currentTimeMillis() < prefs.getLong("${name}_cool", 0L)) continue
            val r = try {
                openAiChat(name, base, k, system, question)
            } catch (e: Exception) {
                null
            }
            if (r != null) return r
        }
        return null
    }

    private fun callGemini(key: String, question: String): String {
        val now = SimpleDateFormat("EEEE d 'de' MMMM 'de' yyyy, HH:mm", Locale("es")).format(Date())
        val iso = SimpleDateFormat("yyyy-MM-dd'T'HH:mm", Locale.US).format(Date())
        val prefs = getSharedPreferences("jarvis", MODE_PRIVATE)
        val pending = prefs.getString("pending_sender", "") ?: ""
        val pendingType = prefs.getString("pending_type", "text")
        val pendingLine = if (pending.isEmpty()) ""
        else if (pendingType == "voice")
            "Hace poco avisaste al usuario de que $pending le mandó un audio de WhatsApp. " +
                "Si el usuario responde que sí o pide escucharlo, usá play_voice_note.\n"
        else
            "Hace poco avisaste al usuario de un mensaje de WhatsApp de $pending (no sabés qué dice). " +
                "Si el usuario responde que sí o pide leerlo, usá read_messages con contact = ese nombre.\n"
        val sendText = prefs.getString("send_text", "") ?: ""
        val sendLine = if (sendText.isEmpty()) ""
        else "Hay un mensaje de WhatsApp pendiente de confirmar para ${prefs.getString("send_name", "")}: \"$sendText\". " +
            "Si el usuario confirma (sí, dale, enviá), usá confirm_send. Si dice que no, usá cancel_send. " +
            "Si lo corrige, usá send_whatsapp de nuevo con el texto corregido.\n"
        val mem = memoryList()
        val choiceNames = prefs.getString("choice_names", "") ?: ""
        val choiceLine = if (choiceNames.isEmpty()) ""
        else "Hay una elección pendiente entre estos contactos: " +
            choiceNames.split("\u0001").mapIndexed { i, n -> "${i + 1}) $n" }.joinToString(", ") +
            ". Si el usuario elige uno, usá choose_contact con option = su número. Si dice que ninguno, usá cancel_send.\n"
        val memoryLine = if (mem.isEmpty()) "" else "Lo que sabés del usuario (memoria):\n" + mem.joinToString("\n") { "- $it" } + "\n"
        val system = """
Sos Jarvis, un asistente de voz en el celular del usuario.
Respondé SIEMPRE y SOLO con un objeto JSON válido, sin markdown ni texto extra.
Esquema: {"say":"lo que decís en voz alta","action":"none|alarm|alarm_off|timer|flashlight|dnd|call|calendar|read_messages|read_notifications|play_voice_note|send_whatsapp|confirm_send|cancel_send|image_search|web_search|open_app|remember|forget|create_file|choose_contact|reminder|list_add|list_read|list_remove|volume|brightness|connectivity|system|camera|play_music|scan_chats|handsfree|close_app|diagnose|guide|guide_next|help|media|note_add|note_read|note_delete|dictation|read_mail|agenda|alarm_list", ...campos}
Campos según la acción:
- alarm: hour (0-23), minute (0-59), label
- alarm_off: borra o apaga una alarma. Sin campos = la próxima; con hour y minute = la de esa hora.
- alarm_list: sin campos. Abre la lista de alarmas de la app de reloj.
- read_messages: contact (nombre del contacto, o vacío para los últimos mensajes de WhatsApp). El teléfono los lee en voz alta; vos no ves el contenido.
- read_notifications: sin campos, lee en voz alta las últimas notificaciones
- play_voice_note: sin campos, reproduce el último audio de WhatsApp recibido
- send_whatsapp: contact (nombre tal como lo dijo, vacío = el último que escribió), text (el mensaje exacto a enviar). El teléfono pide confirmación al usuario antes de enviar.
- confirm_send: sin campos, cuando el usuario confirma el envío pendiente
- cancel_send: sin campos, cuando el usuario cancela el envío pendiente
- timer: seconds, label
- flashlight: on (true o false)
- dnd (no molestar): on (true o false)
- call: contact (el nombre tal como lo dijo el usuario; vacío = el último contacto que escribió por WhatsApp)
- calendar: title, start (formato yyyy-MM-ddTHH:mm, hora local), minutes (duración, 60 por defecto), allday (true si es de todo el día). Agenda el evento directo en el calendario.
- image_search: query (qué imagen buscar, en pocas palabras). Abre Google Imágenes en Chrome y las muestra en pantalla. En say decí algo corto como "Acá tenés las imágenes."
- web_search: query (qué buscar). Abre una búsqueda de Google en Chrome.
- choose_contact: option (número 1, 2, 3...). Solo cuando hay una elección pendiente entre contactos y el usuario elige uno (por número, "el primero", o diciendo el nombre completo).
- reminder: text (qué recordar), start (yyyy-MM-ddTHH:mm, hora local). Si es en las próximas 23 horas suena como alarma con ese texto; si es más lejos, se abre el calendario para confirmar.
- list_add: list (nombre de la lista, "compras" por defecto), items (lista de cosas a agregar)
- list_read: list. Lee en voz alta la lista.
- list_remove: list, items (qué sacar; vacío = vaciar toda la lista)
- volume: mode (up|down|mute|unmute|max|level), percent (solo con level, 0-100)
- brightness: percent (1-100)
- connectivity: what (wifi|data|airplane|nfc|volume). Android no deja cambiarlo solo: abre el panel.
- system: which (screenshot|home|back|recents|lock|notifications)
- camera: sin campos, abre la cámara
- play_music: query (canción, artista o género). Abre la música en la app que tenga el teléfono.
- scan_chats: sin campos. Lee la lista de chats de WhatsApp para conocer todos los nombres. Usalo si el usuario dice "aprendé mis chats" o si no encuentra a alguien.
- handsfree: on (true o false). Activa o desactiva el manos libres (el teléfono escucha la palabra "Jarvis" todo el tiempo). Con 10 % de batería o menos se pausa solo, salvo que esté cargando.
- close_app: sin campos. Cierra la app que el usuario tiene abierta en pantalla (abre recientes y la desliza). No cierra apps por nombre.
- diagnose: sin campos. Revisa qué permisos le faltan a Jarvis y lo dice en voz alta.
- guide: topic (qué querés activar, ej. captura, notificaciones, micrófono; vacío = el primero que falte). Guía paso a paso, un paso por vez, y abre la pantalla de Ajustes que corresponde.
- guide_next: dir (next, repeat o stop). Para seguir, repetir o cortar una guía en curso.
- help: sin campos. Cuenta qué puede hacer Jarvis.
- media: cmd (play, pause, next, previous, stop). Controla la música o el video que está sonando.
- note_add: text (nota corta que el usuario dicta; se guarda con fecha)
- note_read: which (last = la última, all = las últimas cinco)
- note_delete: which (last, all) o text (palabra clave de la nota a borrar)
- dictation: sin campos. Modo dictado largo: el usuario habla seguido y dice "listo" para guardar todo como una nota.
- read_mail: sin campos. Lee los mails recientes que llegaron como notificación (Gmail y otras apps de correo).
- agenda: day (today, tomorrow o week). Lee los eventos del calendario.
- open_app: app (nombre de la app, ej. Instagram, YouTube, Spotify, Maps), query (opcional, qué buscar adentro; funciona en YouTube, Spotify y Maps; en Instagram solo un nombre de usuario)
- remember: text (dato importante del usuario o de sus proyectos, en una oración). Usalo cuando diga "acordate de..." o cuente algo importante sobre él o un proyecto.
- forget: text (palabra clave de lo que hay que olvidar)
- create_file: name (nombre, puede incluir carpeta, ej. proyecto/notas.md), content (todo el contenido del archivo). Sirve para crear proyectos, notas, listas o textos que el usuario pida. Se guarda en Documentos/Jarvis.
Si el usuario pregunta qué podés hacer, nombrá en una frase tus capacidades (llamar y escribir por WhatsApp, alarmas, recordatorios, listas, calendario, volumen y brillo, capturas, música, buscar, abrir apps, recordar cosas, crear archivos) y sugerí algo que todavía no usó.
Si hay algo que no podés hacer todavía, decíselo claro y proponé la alternativa más cercana.
Si no hay nada que ejecutar, action es "none" y solo conversás.
"say" es MUY breve: una sola oración corta (idealmente menos de 12 palabras), salvo que el usuario pida una explicación. Español rioplatense, sin markdown.
${memoryLine}${choiceLine}${pendingLine}${sendLine}Fecha y hora actual: $now (formato ISO: $iso).
""".trimIndent()
        callFastProviders(system, question)?.let { return it }
        val contents = JSONArray()
        for ((role, text) in history.toList().takeLast(6)) {
            contents.put(
                JSONObject().put("role", role)
                    .put("parts", JSONArray().put(JSONObject().put("text", text)))
            )
        }
        contents.put(
            JSONObject().put("role", "user")
                .put("parts", JSONArray().put(JSONObject().put("text", question)))
        )
        val body = JSONObject()
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system))))
            .put("contents", contents)

        // Primero intentamos con "pensamiento" bajo para que responda rápido.
        // Si el modelo no acepta esa opción (error 400), reintentamos sin ella.
        val fast = JSONObject(body.toString()).put(
            "generationConfig",
            JSONObject()
                .put("responseMimeType", "application/json")
                .put("thinkingConfig", JSONObject().put("thinkingLevel", "minimal"))
        )
        var code = 0
        var txt = ""
        for (attempt in 0 until 3) {
        if (attempt > 0) {
            if (code != 503) break
            try { Thread.sleep(1500L * attempt) } catch (e: InterruptedException) { }
        }
        for (mi in (if (attempt == 0) textModelIdx else 0) until MODELS.size) {
            val model = MODELS[mi]
            var r = if (thinkingOk) post(key, model, fast, 20000) else post(key, model, body, 20000)
            if (r.first == 400 && thinkingOk) {
                val r2 = post(key, model, body, 20000)
                if (r2.first in 200..299) thinkingOk = false
                r = r2
            }
            code = r.first
            txt = r.second
            if (code != 404 && code != 429 && code != 503 && code != 504) {
                if (code in 200..299) textModelIdx = mi
                break
            }
        }
        if (code != 503) break
        }
        if (code !in 200..299) textModelIdx = 0

        if (code !in 200..299) {
            if (code == 429) return "Gemini: se acabó el cupo gratis por ahora. Probá más tarde."
            if (code == 504) return "Gemini tardó demasiado en responder. Probá de nuevo."
            if (code == 503) return "Gemini está saturado en este momento. Probá de nuevo en unos segundos."
            val msg = try {
                JSONObject(txt).getJSONObject("error").getString("message")
            } catch (e: Exception) {
                txt.take(150)
            }
            return "Gemini devolvió el error $code: ${msg.take(120)}"
        }
        val cands = JSONObject(txt).optJSONArray("candidates")
        val parts = cands?.optJSONObject(0)?.optJSONObject("content")?.optJSONArray("parts")
            ?: return "Gemini no devolvió respuesta: ${txt.take(150)}"
        val sb = StringBuilder()
        for (i in 0 until parts.length()) sb.append(parts.getJSONObject(i).optString("text", ""))
        return sb.toString().trim().ifEmpty { "No tengo respuesta para eso." }
    }

    override fun onDestroy() {
        instance = null
        player?.release()
        stopSpeaking()
        bubble?.let { wm.removeView(it) }
        bubble = null
        main.removeCallbacksAndMessages(null)
        try { batteryReceiver?.let { unregisterReceiver(it) } } catch (e: Exception) { }
        recognizer?.destroy()
        tts?.shutdown()
        super.onDestroy()
    }
}
