package com.jarvis.app

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.net.Uri
import android.provider.AlarmClock
import android.provider.CalendarContract
import android.provider.ContactsContract
import android.provider.Settings
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.TextView
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.concurrent.thread
import kotlin.math.abs

class OverlayService : Service(), TextToSpeech.OnInitListener {

    companion object {
        // Modelos de Gemini, en orden. Si uno no existe (404) o se acabó su cupo gratis (429),
        // se prueba el siguiente. Los "lite" son mucho más rápidos y tienen más cupo gratis.
        @Volatile var instance: OverlayService? = null
        @Volatile var ttsAttempt = 0
        @Volatile var ttsModelIdx = 0
        @Volatile var textModelIdx = 0
        @Volatile var thinkingOk = true
        val TTS_MODELS = listOf("gemini-3.8-flash-lite-tts", "gemini-3.8-flash-tts")
        val MODELS = listOf("gemini-3.5-flash-lite", "gemini-3.1-flash-lite", "gemini-4-hydrogen")
        const val COLOR_IDLE = "#E6007AFF"
        const val COLOR_LISTENING = "#E6FF3B30"
        const val COLOR_THINKING = "#E6FF9500"
    }

    private lateinit var wm: WindowManager
    private var bubble: TextView? = null
    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private val main = Handler(Looper.getMainLooper())
    private val history = java.util.concurrent.CopyOnWriteArrayList<Pair<String, String>>()
    @Volatile private var heard = ""
    private var player: android.media.MediaPlayer? = null
    private var voicePlayer: android.media.MediaPlayer? = null
    private val speakId = java.util.concurrent.atomic.AtomicInteger(0)
    private val waitId = java.util.concurrent.atomic.AtomicInteger(0)
    private var wakeActive = false
    @Volatile private var commandBusy = false
    @Volatile private var cloudPending = false
    private var listenSilent = false
    private var batteryPct = 100
    private var charging = false
    private var lowBattery = false
    private var wakeErrors = 0
    private var batteryReceiver: android.content.BroadcastReceiver? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        instance = this
        startAsForeground()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        tts = TextToSpeech(this, this)
        addBubble()
        registerBattery()
        main.postDelayed({ startWake() }, 2500)
    }

    override fun onInit(status: Int) {
        tts?.language = Locale("es")
        val saved = getSharedPreferences("jarvis", MODE_PRIVATE).getString("voice", null)
        if (saved != null) {
            tts?.voices?.firstOrNull { it.name == saved }?.let { tts?.voice = it }
        }
        tts?.setPitch(0.85f)
        tts?.setSpeechRate(0.95f)
    }

    private fun startAsForeground() {
        val channelId = "jarvis"
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(channelId, "Jarvis", NotificationManager.IMPORTANCE_MIN)
        )
        val n = Notification.Builder(this, channelId)
            .setContentTitle("Jarvis activo")
            .setContentText(notifText())
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } else {
            startForeground(1, n)
        }
    }

    private fun setBubble(letter: String, color: String) {
        bubble?.text = letter
        (bubble?.background as? GradientDrawable)?.setColor(Color.parseColor(color))
    }

    private fun addBubble() {
        val size = (56 * resources.displayMetrics.density).toInt()
        val tv = TextView(this).apply {
            text = "J"
            textSize = 22f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.parseColor(COLOR_IDLE))
            }
        }
        val lp = WindowManager.LayoutParams(
            size, size,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.END
            x = 16
            y = 300
        }

        var startX = 0
        var startY = 0
        var touchX = 0f
        var touchY = 0f
        var moved = false

        tv.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = lp.x; startY = lp.y
                    touchX = e.rawX; touchY = e.rawY
                    moved = false
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - touchX).toInt()
                    val dy = (e.rawY - touchY).toInt()
                    if (abs(dx) > 10 || abs(dy) > 10) moved = true
                    if (moved) {
                        lp.x = startX - dx
                        lp.y = startY + dy
                        wm.updateViewLayout(tv, lp)
                    }
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) {
                        if (e.eventTime - e.downTime > 800) stopSelf() else listen()
                    }
                }
            }
            true
        }
        bubble = tv
        wm.addView(tv, lp)
    }

    private fun say(text: String) {
        setBubble("J", COLOR_IDLE)
        speak(text)
    }

    private fun localSpeak(text: String) {
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis")
    }

    private fun stopSpeaking() {
        speakId.incrementAndGet()
        tts?.stop()
        try { voicePlayer?.release() } catch (e: Exception) { }
        voicePlayer = null
    }

    private fun speak(text: String) {
        if (wakeActive) stopWake()
        resumeAfterSpeech(text.trimEnd().endsWith("?"))
        stopSpeaking()
        val id = speakId.get()
        val prefs = getSharedPreferences("jarvis", MODE_PRIVATE)
        val voice = prefs.getString("cloud_voice", "Charon") ?: ""
        val key = prefs.getString("key", "") ?: ""
        if (voice.isEmpty() || key.isEmpty() || text.length > 700) {
            localSpeak(text)
            return
        }
        cloudPending = true
        thread {
            val f = try { cloudTts(key, voice, text) } catch (e: Exception) { null }
            main.post {
                cloudPending = false
                if (id != speakId.get()) {
                    f?.delete()
                } else if (f == null) {
                    localSpeak(text)
                } else {
                    playSpeechFile(f, text)
                }
            }
        }
    }

    private fun playSpeechFile(f: java.io.File, text: String) {
        try {
            val mp = android.media.MediaPlayer()
            voicePlayer = mp
            mp.setDataSource(f.absolutePath)
            mp.setOnCompletionListener { it.release(); f.delete() }
            mp.prepare()
            mp.start()
        } catch (e: Exception) {
            f.delete()
            localSpeak(text)
        }
    }

    private fun addWavHeader(pcm: ByteArray, rate: Int): ByteArray {
        val bb = java.nio.ByteBuffer.allocate(44 + pcm.size).order(java.nio.ByteOrder.LITTLE_ENDIAN)
        bb.put("RIFF".toByteArray()); bb.putInt(36 + pcm.size); bb.put("WAVE".toByteArray())
        bb.put("fmt ".toByteArray()); bb.putInt(16); bb.putShort(1); bb.putShort(1)
        bb.putInt(rate); bb.putInt(rate * 2); bb.putShort(2); bb.putShort(16)
        bb.put("data".toByteArray()); bb.putInt(pcm.size); bb.put(pcm)
        return bb.array()
    }

    private fun cloudTts(key: String, voice: String, text: String): java.io.File? {
        val style = "calm, deep, refined and precise, like a sophisticated English butler, warm, natural and unhurried"
        val oldPrompt = "Say calmly, with the deep, refined and precise voice of a sophisticated English butler, speaking Spanish: $text"
        // Intentos en orden: (formato de voz, ¿estilo aparte del texto?)
        val attempts = listOf(Pair(0, true), Pair(0, false), Pair(1, false))
        for (mi in ttsModelIdx until TTS_MODELS.size) {
            val model = TTS_MODELS[mi]
            for (ai in (if (mi == ttsModelIdx) ttsAttempt else 0) until attempts.size) {
                val (shape, useMeta) = attempts[ai]
                val voiceCfg = if (shape == 0) JSONObject().put("voice", voice)
                else JSONObject().put("prebuiltVoiceConfig", JSONObject().put("voiceName", voice))
                val part = if (useMeta) JSONObject().put("text", text).put("speech_metadata", JSONObject().put("style", style))
                else JSONObject().put("text", oldPrompt)
                val body = JSONObject()
                    .put("contents", JSONArray().put(JSONObject().put("parts", JSONArray().put(part))))
                    .put(
                        "generationConfig",
                        JSONObject()
                            .put("responseModalities", JSONArray().put("AUDIO"))
                            .put("speechConfig", JSONObject().put("voiceConfig", voiceCfg))
                    )
                val r = post(key, model, body)
                if (r.first == 400) continue
                if (r.first !in 200..299) break
                val parts = JSONObject(r.second).optJSONArray("candidates")?.optJSONObject(0)
                    ?.optJSONObject("content")?.optJSONArray("parts") ?: break
                for (i in 0 until parts.length()) {
                    val pt = parts.getJSONObject(i)
                    val inline = pt.optJSONObject("inlineData") ?: pt.optJSONObject("inline_data") ?: continue
                    val b64 = inline.optString("data", "")
                    if (b64.isEmpty()) continue
                    val mime = inline.optString("mimeType", inline.optString("mime_type", ""))
                    val bytes = android.util.Base64.decode(b64, android.util.Base64.DEFAULT)
                    val isWav = bytes.size > 4 && bytes[0] == 'R'.code.toByte() && bytes[1] == 'I'.code.toByte()
                    val rate = Regex("rate=(\\d+)").find(mime)?.groupValues?.get(1)?.toIntOrNull() ?: 24000
                    val file = java.io.File(cacheDir, "tts_${System.currentTimeMillis()}.wav")
                    file.writeBytes(if (isWav) bytes else addWavHeader(bytes, rate))
                    ttsModelIdx = mi
                    ttsAttempt = ai
                    return file
                }
                break
            }
        }
        ttsModelIdx = 0
        ttsAttempt = 0
        return null
    }

    // ---------- Manos libres (palabra "Jarvis") y batería ----------

    private val wakeStarter = Runnable { startWake() }
    private val wakeRegex = Regex("(?i)\\b(jarvis|yarvis|jarbis|jarvi|jarvez|garvis|charvis|yarvi|jarviz)\\b")

    private fun handsFreeEnabled(): Boolean = getSharedPreferences("jarvis", MODE_PRIVATE).getBoolean("handsfree", true)

    private fun handsFreeNow(): Boolean = handsFreeEnabled() && !lowBattery

    private fun notifText(): String =
        if (handsFreeNow()) "Manos libres: decí \"Jarvis\" y tu pedido. También podés tocar la burbuja."
        else "Tocá la burbuja para hablar. Mantenela apretada para pausar."

    private fun updateNotification() {
        val nm = getSystemService(NotificationManager::class.java)
        val n = Notification.Builder(this, "jarvis")
            .setContentTitle("Jarvis activo")
            .setContentText(notifText())
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .build()
        nm.notify(1, n)
    }

    private fun registerBattery() {
        val r = object : android.content.BroadcastReceiver() {
            override fun onReceive(c: android.content.Context?, i: Intent?) {
                if (i != null) onBattery(i)
            }
        }
        batteryReceiver = r
        val sticky = registerReceiver(r, android.content.IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        if (sticky != null) onBattery(sticky)
    }

    private fun onBattery(i: Intent) {
        val level = i.getIntExtra(android.os.BatteryManager.EXTRA_LEVEL, -1)
        val scale = i.getIntExtra(android.os.BatteryManager.EXTRA_SCALE, 100)
        if (level < 0 || scale <= 0) return
        batteryPct = level * 100 / scale
        val st = i.getIntExtra(android.os.BatteryManager.EXTRA_STATUS, -1)
        charging = st == android.os.BatteryManager.BATTERY_STATUS_CHARGING ||
            st == android.os.BatteryManager.BATTERY_STATUS_FULL
        val wasLow = lowBattery
        // Con histéresis para que no prenda y apague en 10-12 %.
        lowBattery = if (wasLow) !(batteryPct >= 13 || charging) else (batteryPct <= 10 && !charging)
        if (wasLow == lowBattery) return
        updateNotification()
        if (lowBattery) {
            stopWake()
            say("Batería baja. Pauso el manos libres. Tocá la burbuja para hablarme.")
        } else {
            android.widget.Toast.makeText(this, "Manos libres activado.", android.widget.Toast.LENGTH_SHORT).show()
            if (!commandBusy) startWake()
        }
    }

    private fun stopWake() {
        wakeActive = false
        main.removeCallbacks(wakeStarter)
        try { recognizer?.destroy() } catch (e: Exception) { }
        recognizer = null
    }

    private fun startWake() {
        main.removeCallbacks(wakeStarter)
        if (!handsFreeNow() || commandBusy || wakeActive) return
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) return
        if (!SpeechRecognizer.isRecognitionAvailable(this)) return
        try { recognizer?.destroy() } catch (e: Exception) { }
        wakeActive = true
        setBubble("J", COLOR_IDLE)
        recognizer = SpeechRecognizer.createSpeechRecognizer(this).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onPartialResults(partialResults: Bundle?) {}
                override fun onEvent(eventType: Int, params: Bundle?) {}
                override fun onError(error: Int) {
                    wakeActive = false
                    wakeRestart(error)
                }
                override fun onResults(results: Bundle?) {
                    wakeActive = false
                    wakeErrors = 0
                    val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull() ?: ""
                    onWakeText(text)
                }
            })
            startListening(
                Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE, "es-AR")
                    putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 1200L)
                    putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 900L)
                }
            )
        }
    }

    private fun wakeRestart(error: Int) {
        val benign = error == SpeechRecognizer.ERROR_NO_MATCH || error == SpeechRecognizer.ERROR_SPEECH_TIMEOUT
        if (benign) wakeErrors = 0 else wakeErrors++
        if (wakeErrors > 6) {
            setBubble("J", "#E6808080")
            android.widget.Toast.makeText(this, "No puedo escuchar ahora. Tocá la burbuja para hablarme.", android.widget.Toast.LENGTH_LONG).show()
            return
        }
        val delay = when {
            benign -> 250L
            error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> 1500L
            else -> 4000L
        }
        main.postDelayed(wakeStarter, delay)
    }

    private fun onWakeText(text: String) {
        val m = wakeRegex.find(text)
        if (m == null) {
            main.postDelayed(wakeStarter, 150)
            return
        }
        val cmd = text.substring(m.range.last + 1).trim().trimStart(',', '.', ':', ';', '!', '¡', ' ')
        commandBusy = true
        if (cmd.length < 2) {
            try {
                android.media.ToneGenerator(android.media.AudioManager.STREAM_MUSIC, 60)
                    .startTone(android.media.ToneGenerator.TONE_PROP_ACK, 120)
            } catch (e: Exception) { }
            listen()
        } else {
            heard = cmd
            ask(cmd)
        }
    }

    private fun resumeAfterSpeech(followUp: Boolean) {
        main.removeCallbacks(wakeStarter)
        val id = waitId.incrementAndGet()
        main.postDelayed({ waitSpeechDone(id, followUp, 0) }, 700)
    }

    private fun waitSpeechDone(id: Int, followUp: Boolean, n: Int) {
        if (id != waitId.get()) return
        val speaking = (tts?.isSpeaking == true) || cloudPending ||
            (try { voicePlayer?.isPlaying == true } catch (e: Exception) { false })
        if (speaking && n < 120) {
            main.postDelayed({ waitSpeechDone(id, followUp, n + 1) }, 500)
            return
        }
        commandBusy = false
        if (!handsFreeNow()) return
        if (followUp) listen(true) else startWake()
    }

    private fun listen(silent: Boolean = false) {
        listenSilent = silent
        commandBusy = true
        wakeErrors = 0
        stopWake()
        stopSpeaking()
        try { player?.release() } catch (e: Exception) { }
        player = null
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            say("Falta el permiso del micrófono.")
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            say("Este teléfono no tiene reconocimiento de voz.")
            return
        }
        recognizer?.destroy()
        setBubble("●", COLOR_LISTENING)
        recognizer = SpeechRecognizer.createSpeechRecognizer(this).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onPartialResults(partialResults: Bundle?) {}
                override fun onEvent(eventType: Int, params: Bundle?) {}
                override fun onError(error: Int) {
                    if (listenSilent) {
                        setBubble("J", COLOR_IDLE)
                        resumeAfterSpeech(false)
                    } else say("No te escuché, probá de nuevo.")
                }
                override fun onResults(results: Bundle?) {
                    val text = results
                        ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        ?.firstOrNull()
                    if (text.isNullOrBlank()) {
                        if (listenSilent) {
                            setBubble("J", COLOR_IDLE)
                            resumeAfterSpeech(false)
                        } else say("No te escuché.")
                    } else {
                        heard = text
                        ask(text)
                    }
                }
            })
            startListening(
                Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE, "es-AR")
                    putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 900L)
                    putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 700L)
                }
            )
        }
    }

    private fun ask(question: String) {
        setBubble("…", COLOR_THINKING)
        val key = getSharedPreferences("jarvis", MODE_PRIVATE).getString("key", "") ?: ""
        thread {
            val answer = try {
                callGemini(key, question)
            } catch (e: java.io.IOException) {
                "No pude conectarme a internet. Detalle: ${e.javaClass.simpleName} ${e.message}"
            } catch (e: Exception) {
                "Error inesperado: ${e.javaClass.simpleName} ${e.message}"
            }
            val isError = answer.startsWith("No pude") || answer.startsWith("Error") || answer.startsWith("Gemini")
            history.add(Pair("user", question))
            history.add(
                Pair(
                    "model",
                    if (isError) JSONObject().put("say", answer).put("action", "none").toString() else answer
                )
            )
            while (history.size > 8) history.removeAt(0)
            main.post { handleReply(answer) }
        }
    }

    private fun handleReply(raw: String) {
        if (raw.startsWith("No pude") || raw.startsWith("Error") || raw.startsWith("Gemini")) {
            android.widget.Toast.makeText(this, raw, android.widget.Toast.LENGTH_LONG).show()
            say(raw)
            return
        }
        val json = try {
            JSONObject(raw.substring(raw.indexOf('{'), raw.lastIndexOf('}') + 1))
        } catch (e: Exception) {
            null
        }
        if (json == null) {
            say(raw)
            return
        }
        val speech = json.optString("say", "")
        val msg = try {
            runAction(json)
        } catch (e: Exception) {
            "No pude hacer eso: ${e.message}"
        }
        if (msg != null) android.widget.Toast.makeText(this, msg, android.widget.Toast.LENGTH_LONG).show()
        say(msg ?: speech.ifEmpty { "Listo." })
    }

    private fun newTask(i: Intent): Intent = i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)

    private fun runAction(j: JSONObject): String? {
        when (j.optString("action", "none")) {
            "alarm" -> startActivity(
                newTask(
                    Intent(AlarmClock.ACTION_SET_ALARM)
                        .putExtra(AlarmClock.EXTRA_HOUR, j.getInt("hour"))
                        .putExtra(AlarmClock.EXTRA_MINUTES, j.optInt("minute", 0))
                        .putExtra(AlarmClock.EXTRA_MESSAGE, j.optString("label", "Jarvis"))
                        .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
                )
            )
            "timer" -> startActivity(
                newTask(
                    Intent(AlarmClock.ACTION_SET_TIMER)
                        .putExtra(AlarmClock.EXTRA_LENGTH, j.getInt("seconds"))
                        .putExtra(AlarmClock.EXTRA_MESSAGE, j.optString("label", "Jarvis"))
                        .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
                )
            )
            "alarm_off" -> return deleteNextAlarm()
            "read_messages" -> return readMessages(j.optString("contact", ""))
            "play_voice_note" -> return playVoiceNote()
            "send_whatsapp" -> return prepareSend(j.optString("contact", ""), j.optString("text", ""))
            "confirm_send" -> return confirmSend()
            "cancel_send" -> return cancelSend()
            "read_notifications" -> return readNotifications()
            "flashlight" -> setTorch(j.optBoolean("on", true))
            "dnd" -> return setDnd(j.optBoolean("on", true))
            "call" -> return callContact(j.optString("contact", ""))
            "calendar" -> return addEvent(j)
            "image_search" -> return openSearch(j.optString("query", ""), true)
            "web_search" -> return openSearch(j.optString("query", ""), false)
            "choose_contact" -> return chooseContact(j.optInt("option", 0))
            "reminder" -> return reminder(j)
            "list_add" -> return listAdd(j)
            "list_read" -> return listRead(j)
            "list_remove" -> return listRemove(j)
            "volume" -> return volume(j)
            "brightness" -> return brightness(j)
            "connectivity" -> return connectivity(j.optString("what", "wifi"))
            "system" -> return systemAction(j.optString("which", ""))
            "camera" -> startActivity(newTask(Intent(android.provider.MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA)))
            "play_music" -> return playMusic(j.optString("query", ""))
            "scan_chats" -> return scanChats()
            "handsfree" -> {
                val on = j.optBoolean("on", true)
                getSharedPreferences("jarvis", MODE_PRIVATE).edit().putBoolean("handsfree", on).apply()
                if (!on) stopWake()
                updateNotification()
                return if (on && lowBattery) "Lo activé, pero con la batería baja queda en pausa hasta que cargues." else null
            }
            "open_app" -> return openApp(j.optString("app", ""), j.optString("query", ""))
            "remember" -> return remember(j.optString("text", ""))
            "forget" -> return forget(j.optString("text", ""))
            "create_file" -> return createFile(j.optString("name", ""), j.optString("content", ""))
        }
        return null
    }

    private fun openSearch(query: String, images: Boolean): String? {
        if (query.isBlank()) return "No entendí qué buscar."
        val url = "https://www.google.com/search?" + (if (images) "tbm=isch&" else "") + "q=" + Uri.encode(query)
        try {
            startActivity(newTask(Intent(Intent.ACTION_VIEW, Uri.parse(url)).setPackage("com.android.chrome")))
        } catch (e: Exception) {
            startActivity(newTask(Intent(Intent.ACTION_VIEW, Uri.parse(url))))
        }
        return null
    }

    private fun setTorch(on: Boolean) {
        val cm = getSystemService(CameraManager::class.java)
        val id = cm.cameraIdList.firstOrNull {
            cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
        } ?: return
        cm.setTorchMode(id, on)
    }

    private fun setDnd(on: Boolean): String? {
        val nm = getSystemService(NotificationManager::class.java)
        if (!nm.isNotificationPolicyAccessGranted) {
            startActivity(newTask(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)))
            return "Necesito permiso para No molestar. Activalo para Jarvis en la pantalla que se abrió."
        }
        nm.setInterruptionFilter(
            if (on) NotificationManager.INTERRUPTION_FILTER_PRIORITY
            else NotificationManager.INTERRUPTION_FILTER_ALL
        )
        return null
    }

    private fun norm(t: String): String =
        java.text.Normalizer.normalize(t, java.text.Normalizer.Form.NFD)
            .replace(Regex("\\p{InCombiningDiacriticalMarks}+"), "")
            .lowercase(Locale.ROOT)
            .trim()

    private fun deleteNextAlarm(): String? {
        return try {
            val action = if (Build.VERSION.SDK_INT >= 36) "android.intent.action.DELETE_ALARM"
            else AlarmClock.ACTION_DISMISS_ALARM
            startActivity(
                newTask(
                    Intent(action)
                        .putExtra(AlarmClock.EXTRA_ALARM_SEARCH_MODE, AlarmClock.ALARM_SEARCH_MODE_NEXT)
                        .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
                )
            )
            null
        } catch (e: android.content.ActivityNotFoundException) {
            "Tu app de reloj no me deja borrar alarmas por voz."
        }
    }

    private fun key(t: String): String =
        norm(t).replace(Regex("\\b(numeral|almohadilla|hashtag)\\b"), "").replace(Regex("[^a-z0-9]"), "")

    private fun wordKeys(t: String): List<String> =
        norm(t).replace(Regex("\\b(numeral|almohadilla|hashtag)\\b"), " ")
            .split(Regex("\\s+"))
            .map { key(it) }
            .filter { it.isNotEmpty() && (it.length > 2 || it.all { c -> c.isDigit() }) }

    private fun lastSender(): String? =
        NotifStore.all(this).lastOrNull { it.app == "WhatsApp" }?.sender

    /** Busca el contacto que mejor coincida. rows = lista de (nombre, número). */
    private fun phon(t: String): String {
        var s = norm(t).replace(Regex("[^a-z0-9 ]"), " ")
        s = s.replace("ch", "x").replace("qu", "k").replace("ce", "se").replace("ci", "si")
            .replace("c", "k").replace("ll", "y").replace("z", "s").replace("v", "b")
            .replace("w", "b").replace("ph", "f").replace("h", "")
        return s.replace(Regex("(.)\\1+"), "\$1")
    }

    private fun lev(a: String, b: String): Int {
        val d = IntArray(b.length + 1) { it }
        for (i in 1..a.length) {
            var prev = d[0]
            d[0] = i
            for (j in 1..b.length) {
                val tmp = d[j]
                d[j] = minOf(d[j] + 1, d[j - 1] + 1, prev + if (a[i - 1] == b[j - 1]) 0 else 1)
                prev = tmp
            }
        }
        return d[b.length]
    }

    /** Qué tan parecido es un nombre a lo que dijo el usuario (menor = más parecido, null = no se parece). */
    private fun nameScore(words: List<String>, name: String, loose: Boolean): Int? {
        val tokens = phon(name).split(" ").filter { it.isNotEmpty() }
        if (tokens.isEmpty()) return null
        var total = 0
        for (w in words) {
            var best = Int.MAX_VALUE
            for (t in tokens) {
                val d = if (w.length >= 3 && t.startsWith(w)) 0 else lev(w, t)
                if (d < best) best = d
            }
            val limit = if (loose) maxOf(2, w.length / 2) else maxOf(1, w.length / 4)
            if (best > limit) return null
            total += best
        }
        return total
    }

    private fun fuzzyContact(rows: List<Pair<String, String>>, spoken: String): Pair<String, String>? {
        val words = phon(spoken).split(" ").filter { it.length >= 2 }
        if (words.isEmpty()) return null
        var best: Pair<String, String>? = null
        var bestScore = Int.MAX_VALUE
        for (r in rows) {
            val sc = nameScore(words, r.first, false) ?: continue
            if (sc < bestScore) { bestScore = sc; best = r }
        }
        return best
    }

    private fun closestNames(rows: List<Pair<String, String>>, spoken: String): List<String> {
        val words = phon(spoken).split(" ").filter { it.length >= 2 }
        if (words.isEmpty()) return emptyList()
        return rows.mapNotNull { r -> nameScore(words, r.first, true)?.let { Pair(r.first, it) } }
            .sortedBy { it.second }.map { it.first }.distinct().take(3)
    }

    private fun matchContact(rows: List<Pair<String, String>>, spoken: String, fuzzy: Boolean = true): Pair<String, String>? {
        val wantedKey = key(spoken)
        val words = wordKeys(spoken)
        if (wantedKey.isEmpty()) return null
        rows.firstOrNull { key(it.first).contains(wantedKey) }?.let { return it }
        if (words.isNotEmpty()) {
            rows.firstOrNull { r -> val k = key(r.first); words.all { w -> k.contains(w) } }?.let { return it }
        }
        return if (fuzzy) fuzzyContact(rows, spoken) else null
    }

    private fun phoneRows(): List<Pair<String, String>> {
        val out = ArrayList<Pair<String, String>>()
        val cursor = contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                ContactsContract.CommonDataKinds.Phone.NUMBER
            ),
            null, null, null
        )
        cursor?.use {
            while (it.moveToNext()) {
                val n = it.getString(0) ?: continue
                val num = it.getString(1) ?: continue
                out.add(Pair(n, num))
            }
        }
        return out
    }

    private fun whatsappRows(): List<Pair<String, String>> {
        val out = ArrayList<Pair<String, String>>()
        val cursor = contentResolver.query(
            ContactsContract.Data.CONTENT_URI,
            arrayOf(ContactsContract.Data.DISPLAY_NAME, ContactsContract.Data.DATA1),
            "${ContactsContract.Data.MIMETYPE} = ?",
            arrayOf("vnd.android.cursor.item/vnd.com.whatsapp.profile"),
            null
        )
        cursor?.use {
            while (it.moveToNext()) {
                val n = it.getString(0) ?: continue
                val jid = it.getString(1) ?: continue
                val digits = jid.substringBefore('@').filter { c -> c.isDigit() }
                if (digits.isNotEmpty()) out.add(Pair(n, digits))
            }
        }
        return out
    }

    private fun notifRows(): List<Pair<String, String>> {
        val p = getSharedPreferences("jarvis_numbers", MODE_PRIVATE)
        val out = ArrayList<Pair<String, String>>()
        for ((k, v) in p.all) {
            val num = (v as? String) ?: continue
            if (num.isNotEmpty()) out.add(Pair(k, num))
        }
        return out
    }

    private fun memoryList(): MutableList<String> {
        val raw = getSharedPreferences("jarvis_memory", MODE_PRIVATE).getString("items", "[]") ?: "[]"
        val out = ArrayList<String>()
        try {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) out.add(arr.getString(i))
        } catch (e: Exception) {
        }
        return out
    }

    private fun saveMemory(list: List<String>) {
        val arr = JSONArray()
        list.takeLast(60).forEach { arr.put(it) }
        getSharedPreferences("jarvis_memory", MODE_PRIVATE).edit().putString("items", arr.toString()).apply()
    }

    private fun remember(text: String): String? {
        val t = text.trim()
        if (t.isEmpty()) return "No entendí qué recordar."
        val list = memoryList()
        if (list.none { norm(it) == norm(t) }) list.add(t.take(300))
        saveMemory(list)
        return null
    }

    private fun forget(text: String): String? {
        val w = norm(text)
        if (w.isEmpty()) return "No entendí qué olvidar."
        val list = memoryList()
        val keep = list.filter { !norm(it).contains(w) }
        saveMemory(keep)
        return if (keep.size == list.size) "No tenía nada guardado sobre eso." else null
    }

    // ---------- Recordatorios, listas y controles del teléfono ----------

    private fun reminder(j: JSONObject): String? {
        val text = j.optString("text", "").ifBlank { "Recordatorio" }
        val parsed: java.util.Date? = try {
            SimpleDateFormat("yyyy-MM-dd'T'HH:mm", Locale.US).parse(j.optString("start"))
        } catch (e: Exception) {
            null
        }
        val start = parsed ?: return "No entendí cuándo recordártelo."
        val diff = start.time - System.currentTimeMillis()
        if (diff < 0) return "Esa hora ya pasó."
        if (diff <= 23 * 3600 * 1000L) {
            val c = java.util.Calendar.getInstance().apply { time = start }
            startActivity(
                newTask(
                    Intent(AlarmClock.ACTION_SET_ALARM)
                        .putExtra(AlarmClock.EXTRA_HOUR, c.get(java.util.Calendar.HOUR_OF_DAY))
                        .putExtra(AlarmClock.EXTRA_MINUTES, c.get(java.util.Calendar.MINUTE))
                        .putExtra(AlarmClock.EXTRA_MESSAGE, text)
                        .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
                )
            )
            return null
        }
        return addEvent(JSONObject().put("title", text).put("start", j.optString("start")).put("minutes", 15))
    }

    private fun listsLoad(): JSONObject = try {
        JSONObject(getSharedPreferences("jarvis_lists", MODE_PRIVATE).getString("data", "{}") ?: "{}")
    } catch (e: Exception) {
        JSONObject()
    }

    private fun listsSave(o: JSONObject) {
        getSharedPreferences("jarvis_lists", MODE_PRIVATE).edit().putString("data", o.toString()).apply()
    }

    private fun itemsOf(j: JSONObject): List<String> {
        val arr = j.optJSONArray("items")
        if (arr != null) return (0 until arr.length()).map { arr.optString(it) }.filter { it.isNotBlank() }
        return j.optString("items", "").split(",").map { it.trim() }.filter { it.isNotEmpty() }
    }

    private fun listNameOf(j: JSONObject): String =
        j.optString("list", "").trim().ifEmpty { "compras" }.lowercase(Locale.ROOT)

    private fun listAdd(j: JSONObject): String? {
        val name = listNameOf(j)
        val items = itemsOf(j)
        if (items.isEmpty()) return "No entendí qué agregar."
        val all = listsLoad()
        val arr = all.optJSONArray(name) ?: JSONArray()
        items.forEach { arr.put(it) }
        all.put(name, arr)
        listsSave(all)
        return null
    }

    private fun listRead(j: JSONObject): String? {
        val name = listNameOf(j)
        val arr = listsLoad().optJSONArray(name)
        if (arr == null || arr.length() == 0) return "Tu lista de $name está vacía."
        val items = (0 until arr.length()).map { arr.optString(it) }
        return "Tu lista de $name: " + items.joinToString(", ") + "."
    }

    private fun listRemove(j: JSONObject): String? {
        val name = listNameOf(j)
        val all = listsLoad()
        val arr = all.optJSONArray(name) ?: return "Tu lista de $name está vacía."
        val items = itemsOf(j)
        if (items.isEmpty()) {
            all.remove(name)
            listsSave(all)
            return "Listo, vacié la lista de $name."
        }
        val keep = JSONArray()
        var removed = 0
        for (i in 0 until arr.length()) {
            val cur = arr.optString(i)
            if (items.any { w -> norm(cur).contains(norm(w)) }) removed++ else keep.put(cur)
        }
        all.put(name, keep)
        listsSave(all)
        return if (removed == 0) "No encontré eso en la lista." else null
    }

    private fun volume(j: JSONObject): String? {
        val am = getSystemService(android.media.AudioManager::class.java)
        val st = android.media.AudioManager.STREAM_MUSIC
        val ui = android.media.AudioManager.FLAG_SHOW_UI
        val max = am.getStreamMaxVolume(st)
        when (j.optString("mode", "up")) {
            "up" -> am.adjustStreamVolume(st, android.media.AudioManager.ADJUST_RAISE, ui)
            "down" -> am.adjustStreamVolume(st, android.media.AudioManager.ADJUST_LOWER, ui)
            "mute" -> am.adjustStreamVolume(st, android.media.AudioManager.ADJUST_MUTE, ui)
            "unmute" -> am.adjustStreamVolume(st, android.media.AudioManager.ADJUST_UNMUTE, ui)
            "max" -> am.setStreamVolume(st, max, ui)
            "level" -> am.setStreamVolume(st, (max * j.optInt("percent", 50) / 100).coerceIn(0, max), ui)
        }
        return null
    }

    private fun brightness(j: JSONObject): String? {
        if (!Settings.System.canWrite(this)) {
            startActivity(newTask(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:$packageName"))))
            return "Necesito permiso para cambiar el brillo. Activalo para Jarvis en la pantalla que se abrió."
        }
        val pct = j.optInt("percent", 50).coerceIn(1, 100)
        Settings.System.putInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS_MODE, Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL)
        Settings.System.putInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS, pct * 255 / 100)
        return null
    }

    private fun connectivity(what: String): String? {
        val action = if (Build.VERSION.SDK_INT >= 29) {
            when (what) {
                "volume" -> Settings.Panel.ACTION_VOLUME
                "nfc" -> Settings.Panel.ACTION_NFC
                "airplane" -> Settings.ACTION_AIRPLANE_MODE_SETTINGS
                else -> Settings.Panel.ACTION_INTERNET_CONNECTIVITY
            }
        } else Settings.ACTION_WIFI_SETTINGS
        startActivity(newTask(Intent(action)))
        return "Android no me deja cambiar eso solo. Te abrí el panel para que lo toques."
    }

    private fun systemAction(which: String): String? {
        val svc = SendAccessibilityService.instance
            ?: return "Necesito el permiso de accesibilidad para eso. Activalo desde la app de Jarvis."
        val code = when (which) {
            "screenshot" -> android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_TAKE_SCREENSHOT
            "home" -> android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_HOME
            "back" -> android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_BACK
            "recents" -> android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_RECENTS
            "lock" -> android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_LOCK_SCREEN
            "notifications" -> android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS
            else -> return "No sé hacer eso todavía."
        }
        return if (svc.performGlobalAction(code)) null else "No pude hacerlo."
    }

    private fun playMusic(q: String): String? {
        if (q.isBlank()) return "No entendí qué música poner."
        val i = Intent("android.media.action.MEDIA_PLAY_FROM_SEARCH")
            .putExtra(android.app.SearchManager.QUERY, q)
            .putExtra("android.intent.extra.focus", "vnd.android.cursor.item/*")
        return try {
            startActivity(newTask(i))
            null
        } catch (e: Exception) {
            openApp("YouTube", q)
        }
    }

    private fun scanChats(): String? {
        if (!SendAccessibilityService.running) {
            return "Necesito el permiso de accesibilidad. Activalo desde la app de Jarvis."
        }
        if (!openWhatsApp()) return "No encontré WhatsApp."
        SendAccessibilityService.startScan()
        return "Voy a leer tus chats de WhatsApp, esperá un momento."
    }

    private fun openApp(name: String, query: String): String? {
        if (name.isBlank()) return "No entendí qué app abrir."
        val pm = packageManager
        val launch = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(launch, 0)
        if (apps.isEmpty()) return "No puedo ver las apps instaladas."
        val rows = apps.map { Pair(it.loadLabel(pm).toString(), it.activityInfo.packageName) }
        val m = matchContact(rows, name) ?: return "No encontré la app $name."
        val pkg = m.second
        val q = query.trim()
        if (q.isNotEmpty()) {
            val uri: String? = when (pkg) {
                "com.google.android.youtube" -> "https://www.youtube.com/results?search_query=" + Uri.encode(q)
                "com.spotify.music" -> "spotify:search:" + Uri.encode(q)
                "com.google.android.apps.maps" -> "geo:0,0?q=" + Uri.encode(q)
                "com.instagram.android" -> if (q.contains(" ")) null else "instagram://user?username=" + Uri.encode(q.removePrefix("@"))
                else -> null
            }
            if (uri != null) {
                try {
                    startActivity(newTask(Intent(Intent.ACTION_VIEW, Uri.parse(uri)).setPackage(pkg)))
                    return null
                } catch (e: Exception) {
                }
            }
        }
        val li = pm.getLaunchIntentForPackage(pkg) ?: return "No pude abrir ${m.first}."
        startActivity(newTask(li))
        return if (q.isNotEmpty()) "Abrí ${m.first}, pero buscar adentro de esa app todavía no puedo." else null
    }

    private fun createFile(name: String, content: String): String? {
        if (Build.VERSION.SDK_INT >= 30 && !android.os.Environment.isExternalStorageManager()) {
            return "Necesito el permiso de archivos. Tocá ese botón en la app de Jarvis."
        }
        val clean = name.replace("..", "").replace("\\", "/").trim().trim('/').ifBlank { "nota.txt" }
        val base = java.io.File(
            android.os.Environment.getExternalStoragePublicDirectory(android.os.Environment.DIRECTORY_DOCUMENTS),
            "Jarvis"
        )
        val f = java.io.File(base, clean)
        f.parentFile?.mkdirs()
        f.writeText(content)
        return "Listo, guardé ${f.name} en Documentos, carpeta Jarvis."
    }

    private val STOP = setOf("los", "las", "del", "una", "uno", "que", "con", "mis")

    private fun spokenWords(t: String): List<String> = wordKeys(t).filter { it !in STOP }

    /** Junta todos los contactos conocidos (agenda, WhatsApp y quienes te escribieron) sin repetir nombres. */
    private fun allRows(includeReply: Boolean): List<Pair<String, String>> {
        val out = ArrayList<Pair<String, String>>()
        val seen = HashSet<String>()
        fun add(name: String, num: String) {
            val k = key(name)
            if (k.isEmpty() || !seen.add(k)) return
            out.add(Pair(name, num))
        }
        phoneRows().forEach { add(it.first, it.second) }
        whatsappRows().forEach { add(it.first, "+" + it.second) }
        notifRows().forEach { add(it.first, "+" + it.second) }
        if (includeReply) {
            ReplyStore.names().forEach { add(it, "") }
            getSharedPreferences("jarvis_chats", MODE_PRIVATE).all.keys.forEach { add(it, "") }
            NotifStore.all(this).filter { it.app == "WhatsApp" }.forEach {
                add(it.sender.replace(Regex("\\s*\\(\\d+\\s+(mensajes?|messages?)\\)\\s*$"), "").trim(), "")
            }
        }
        return out
    }

    /** Todos los contactos que pueden ser el que dijo el usuario, sin importar cómo estén escritos. */
    private fun candidates(rows: List<Pair<String, String>>, spoken: String): List<Pair<String, String>> {
        val wantedKey = key(spoken)
        if (wantedKey.isEmpty()) return emptyList()
        val words = spokenWords(spoken)
        if (words.isNotEmpty()) {
            // 1) cada palabra dicha es una palabra completa del nombre (ej. "creadora" en "La Creadora 💜")
            val t0 = rows.filter { r -> val tk = wordKeys(r.first); words.all { w -> w in tk } }
            if (t0.isNotEmpty()) return t0
            // 2) el nombre contiene las palabras dichas en cualquier lugar
            val t1 = rows.filter { r -> val k = key(r.first); words.all { w -> k.contains(w) } }
            if (t1.isNotEmpty()) return t1
        }
        val t2 = rows.filter { key(it.first).contains(wantedKey) }
        if (t2.isNotEmpty()) return t2
        // 3) parecido por sonido (por si el reconocimiento de voz lo escribió distinto)
        var pw = phon(spoken).split(" ").filter { it.length >= 3 && it !in STOP }
        if (pw.isEmpty()) pw = phon(spoken).split(" ").filter { it.length >= 2 }
        if (pw.isEmpty()) return emptyList()
        val scored = rows.mapNotNull { r -> nameScore(pw, r.first, false)?.let { Pair(r, it) } }
        val best = scored.minOfOrNull { it.second } ?: return emptyList()
        return scored.filter { it.second == best }.map { it.first }
    }

    private fun askWhich(kind: String, cands: List<Pair<String, String>>, text: String): String {
        val list = cands.take(4)
        getSharedPreferences("jarvis", MODE_PRIVATE).edit()
            .putString("choice_kind", kind)
            .putString("choice_names", list.joinToString("\u0001") { it.first })
            .putString("choice_numbers", list.joinToString("\u0001") { it.second })
            .putString("choice_text", text)
            .apply()
        val opts = list.mapIndexed { i, c -> "${i + 1}, ${c.first}" }.joinToString(". ")
        return "Encontré ${list.size}: $opts. ¿Cuál?"
    }

    private fun clearChoice() {
        getSharedPreferences("jarvis", MODE_PRIVATE).edit()
            .remove("choice_kind").remove("choice_names").remove("choice_numbers").remove("choice_text").apply()
    }

    private fun chooseContact(option: Int): String? {
        val prefs = getSharedPreferences("jarvis", MODE_PRIVATE)
        val kind = prefs.getString("choice_kind", null) ?: return "No tengo ninguna elección pendiente."
        val names = (prefs.getString("choice_names", "") ?: "").split("\u0001")
        val numbers = (prefs.getString("choice_numbers", "") ?: "").split("\u0001")
        val text = prefs.getString("choice_text", "") ?: ""
        if (option < 1 || option > names.size) return "No entendí cuál. Decime el número."
        clearChoice()
        val c = Pair(names[option - 1], numbers.getOrElse(option - 1) { "" })
        return if (kind == "call") placeCall(c) else stageSend(c, text)
    }

    private fun openWhatsApp(): Boolean {
        val pm = packageManager
        val li = pm.getLaunchIntentForPackage("com.whatsapp") ?: pm.getLaunchIntentForPackage("com.whatsapp.w4b") ?: return false
        startActivity(newTask(li))
        return true
    }

    private fun placeCall(match: Pair<String, String>): String? {
        // Preferimos llamar por WhatsApp, buscando el chat por nombre.
        if (SendAccessibilityService.running && openWhatsApp()) {
            SendAccessibilityService.startFlow(match.first, "", true)
            return "Llamando a ${match.first} por WhatsApp."
        }
        if (match.second.isBlank()) {
            return "Para llamar por WhatsApp necesito el permiso de accesibilidad. Activalo desde la app de Jarvis."
        }
        startActivity(newTask(Intent(Intent.ACTION_CALL, Uri.parse("tel:" + Uri.encode(match.second)))))
        return "Llamando a ${match.first}."
    }

    private fun stageSend(target: Pair<String, String>, text: String): String? {
        getSharedPreferences("jarvis", MODE_PRIVATE).edit()
            .putString("send_name", target.first)
            .putString("send_number", target.second.filter { it.isDigit() })
            .putString("send_text", text)
            .apply()
        return "Le voy a escribir a ${target.first}: $text. ¿Lo envío?"
    }

    private fun callContact(name: String): String? {
        if (checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
            return "Me faltan los permisos de contactos. Dalos desde la app de Jarvis."
        }
        val spoken = if (key(name).isEmpty()) {
            lastSender() ?: return "No tengo ningún mensaje reciente para saber a quién llamar."
        } else name
        val rows = allRows(true)
        if (rows.isEmpty()) return "No veo ningún contacto ni chat. Revisá el permiso de contactos de Jarvis."
        val c = candidates(rows, spoken)
        if (c.size == 1) return placeCall(c[0])
        if (c.size > 1) return askWhich("call", c, "")
        val cerca = closestNames(rows, spoken)
        return if (cerca.isNotEmpty()) "No encontré a $spoken. ¿Quisiste decir ${cerca.joinToString(" o ")}?"
        else "No encontré a $spoken entre ${rows.size} contactos. Escuché: $heard."
    }

    private fun prepareSend(contact: String, text: String): String? {
        if (checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
            return "Me faltan los permisos de contactos. Dalos desde la app de Jarvis."
        }
        if (text.isBlank()) return "No entendí qué mensaje enviar."
        val spoken = if (key(contact).isEmpty()) {
            lastSender() ?: return "No tengo ningún mensaje reciente para saber a quién escribirle."
        } else contact
        val rows = allRows(true)
        val c = candidates(rows, spoken)
        if (c.size == 1) return stageSend(c[0], text)
        if (c.size > 1) return askWhich("send", c, text)
        val cerca = closestNames(rows, spoken)
        return if (cerca.isNotEmpty()) "No encontré a $spoken. ¿Quisiste decir ${cerca.joinToString(" o ")}?"
        else "No encontré a $spoken para escribirle. Escuché: $heard."
    }

    private fun cancelSend(): String? {
        getSharedPreferences("jarvis", MODE_PRIVATE).edit()
            .remove("send_name").remove("send_number").remove("send_text")
            .remove("choice_kind").remove("choice_names").remove("choice_numbers").remove("choice_text").apply()
        return null
    }

    private fun confirmSend(): String? {
        val prefs = getSharedPreferences("jarvis", MODE_PRIVATE)
        val number = prefs.getString("send_number", null) ?: return "No tengo ningún mensaje pendiente de enviar."
        val text = prefs.getString("send_text", "") ?: ""
        val name = prefs.getString("send_name", "") ?: ""
        cancelSend()
        if (number.isEmpty()) {
            if (ReplyStore.send(this, name, text)) return "Mensaje enviado a $name."
            if (SendAccessibilityService.running && openWhatsApp()) {
                SendAccessibilityService.startFlow(name, text, false)
                return null
            }
            return "Para escribirle a $name necesito el permiso de accesibilidad. Activalo desde la app de Jarvis."
        }
        SendAccessibilityService.armedUntil = System.currentTimeMillis() + 20000
        val uri = Uri.parse("https://wa.me/$number?text=" + Uri.encode(text))
        try {
            startActivity(newTask(Intent(Intent.ACTION_VIEW, uri).setPackage("com.whatsapp")))
        } catch (e: android.content.ActivityNotFoundException) {
            startActivity(newTask(Intent(Intent.ACTION_VIEW, uri)))
        }
        return if (SendAccessibilityService.running) null
        else "Abrí el chat con el mensaje listo, pero me falta el permiso de accesibilidad para enviarlo solo."
    }

    /** Busca mensajes de un contacto aunque el nombre dicho no coincida exacto con el de la notificación. */
    private fun findMessagesFor(contact: String, items: List<NotifStore.Item>): List<NotifStore.Item> {
        val wanted = norm(contact)
        val wantedKey = key(contact)
        // 1) coincidencia directa por nombre dicho
        items.filter { norm(it.sender).contains(wanted) || (wantedKey.isNotEmpty() && key(it.sender).contains(wantedKey)) }
            .takeIf { it.isNotEmpty() }?.let { return it.takeLast(3) }
        // 2) resolver el nombre contra la agenda y buscar por el nombre guardado
        if (checkSelfPermission(Manifest.permission.READ_CONTACTS) == PackageManager.PERMISSION_GRANTED) {
            val resolved = matchContact(phoneRows(), contact) ?: matchContact(whatsappRows(), contact)
            if (resolved != null) {
                val rk = key(resolved.first)
                items.filter { rk.isNotEmpty() && (key(it.sender).contains(rk) || rk.contains(key(it.sender))) }
                    .takeIf { it.isNotEmpty() }?.let { return it.takeLast(3) }
            }
        }
        // 3) parecido por sonido contra los remitentes guardados
        val words = phon(contact).split(" ").filter { it.length >= 2 }
        if (words.isEmpty()) return emptyList()
        val scored = items.mapNotNull { i -> nameScore(words, i.sender, true)?.let { Pair(i, it) } }
        val best = scored.minOfOrNull { it.second } ?: return emptyList()
        return scored.filter { it.second == best }.map { it.first }.takeLast(3)
    }

    private fun readMessages(contact: String): String? {
        clearPending()
        val wanted = norm(contact)
        val items = NotifStore.all(this).filter { it.app == "WhatsApp" }
        val list = if (wanted.isEmpty()) items.takeLast(3) else findMessagesFor(contact, items)
        if (list.isEmpty()) {
            return if (wanted.isEmpty()) "No tengo mensajes recientes de WhatsApp."
            else "No tengo mensajes recientes de $contact."
        }
        return list.joinToString(" ") { "${it.sender} dice: ${it.text}." }
    }

    private fun readNotifications(): String? {
        val list = NotifStore.all(this).takeLast(5)
        if (list.isEmpty()) {
            return "No tengo notificaciones guardadas. Revisá que Jarvis tenga acceso a las notificaciones."
        }
        return list.joinToString(" ") { "${it.app}: ${it.sender}. ${it.text}." }
    }

    fun announce(sender: String, voice: Boolean = false) {
        main.post {
            getSharedPreferences("jarvis", MODE_PRIVATE).edit()
                .putString("pending_sender", sender)
                .putString("pending_type", if (voice) "voice" else "text")
                .apply()
            val frase = if (voice) "Señor, $sender le mandó un audio. ¿Quiere que lo reproduzca?"
            else "Señor, le escribió $sender. ¿Quiere saber qué dice?"
            speak(frase)
        }
    }

    private fun clearPending() {
        getSharedPreferences("jarvis", MODE_PRIVATE).edit()
            .remove("pending_sender").remove("pending_type").apply()
    }

    private fun findLastVoiceNote(): java.io.File? {
        val roots = listOf(
            "/storage/emulated/0/Android/media/com.whatsapp/WhatsApp/Media/WhatsApp Voice Notes",
            "/storage/emulated/0/Android/media/com.whatsapp.w4b/WhatsApp Business/Media/WhatsApp Business Voice Notes",
            "/storage/emulated/0/WhatsApp/Media/WhatsApp Voice Notes"
        )
        val all = roots.flatMap { r ->
            val dir = java.io.File(r)
            if (!dir.exists()) emptyList<java.io.File>()
            else dir.walkTopDown().filter { it.isFile && it.extension.lowercase() in listOf("opus", "ogg", "m4a", "mp3", "aac") }.toList()
        }
        return all.maxByOrNull { it.lastModified() }
    }

    private fun playVoiceNote(): String? {
        clearPending()
        if (Build.VERSION.SDK_INT >= 30 && !android.os.Environment.isExternalStorageManager()) {
            return "Necesito el permiso de audios de WhatsApp. Tocá ese botón en la app de Jarvis."
        }
        val file = (try { findLastVoiceNote() } catch (e: Exception) { null })
            ?: return "No encontré audios en la carpeta de WhatsApp."
        main.postDelayed({
            try {
                player?.release()
                player = android.media.MediaPlayer().apply {
                    setDataSource(file.absolutePath)
                    setOnCompletionListener { mp -> mp.release() }
                    prepare()
                    start()
                }
            } catch (e: Exception) {
                android.widget.Toast.makeText(this, "No pude reproducir el audio: ${e.message}", android.widget.Toast.LENGTH_LONG).show()
            }
        }, 2500)
        return null
    }

    private fun addEvent(j: JSONObject): String? {
        val start = SimpleDateFormat("yyyy-MM-dd'T'HH:mm", Locale.US).parse(j.getString("start"))
            ?: return "No entendí la fecha."
        val end = start.time + j.optInt("minutes", 60) * 60000L
        startActivity(
            newTask(
                Intent(Intent.ACTION_INSERT)
                    .setData(CalendarContract.Events.CONTENT_URI)
                    .putExtra(CalendarContract.Events.TITLE, j.optString("title", "Evento"))
                    .putExtra(CalendarContract.EXTRA_EVENT_BEGIN_TIME, start.time)
                    .putExtra(CalendarContract.EXTRA_EVENT_END_TIME, end)
            )
        )
        return null
    }

    private fun post(key: String, model: String, body: JSONObject, readMs: Int = 90000): Pair<Int, String> {
        try {
            return postOnce(key, model, body, readMs)
        } catch (e: java.net.SocketTimeoutException) {
            return Pair(504, "timeout")
        }
    }

    private fun postOnce(key: String, model: String, body: JSONObject, readMs: Int): Pair<Int, String> {
        val url = URL("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent")
        val c = url.openConnection() as HttpURLConnection
        c.requestMethod = "POST"
        c.connectTimeout = 10000
        c.readTimeout = readMs
        c.doOutput = true
        c.setRequestProperty("Content-Type", "application/json")
        c.setRequestProperty("x-goog-api-key", key)
        c.outputStream.use { it.write(body.toString().toByteArray()) }
        val code = c.responseCode
        val stream = if (code in 200..299) c.inputStream else c.errorStream
        val txt = stream?.bufferedReader()?.readText() ?: ""
        return Pair(code, txt)
    }

    private fun callGemini(key: String, question: String): String {
        val now = SimpleDateFormat("EEEE d 'de' MMMM 'de' yyyy, HH:mm", Locale("es")).format(Date())
        val iso = SimpleDateFormat("yyyy-MM-dd'T'HH:mm", Locale.US).format(Date())
        val prefs = getSharedPreferences("jarvis", MODE_PRIVATE)
        val pending = prefs.getString("pending_sender", "") ?: ""
        val pendingType = prefs.getString("pending_type", "text")
        val pendingLine = if (pending.isEmpty()) ""
        else if (pendingType == "voice")
            "Hace poco avisaste al usuario de que $pending le mandó un audio de WhatsApp. " +
                "Si el usuario responde que sí o pide escucharlo, usá play_voice_note.\n"
        else
            "Hace poco avisaste al usuario de un mensaje de WhatsApp de $pending (no sabés qué dice). " +
                "Si el usuario responde que sí o pide leerlo, usá read_messages con contact = ese nombre.\n"
        val sendText = prefs.getString("send_text", "") ?: ""
        val sendLine = if (sendText.isEmpty()) ""
        else "Hay un mensaje de WhatsApp pendiente de confirmar para ${prefs.getString("send_name", "")}: \"$sendText\". " +
            "Si el usuario confirma (sí, dale, enviá), usá confirm_send. Si dice que no, usá cancel_send. " +
            "Si lo corrige, usá send_whatsapp de nuevo con el texto corregido.\n"
        val mem = memoryList()
        val choiceNames = prefs.getString("choice_names", "") ?: ""
        val choiceLine = if (choiceNames.isEmpty()) ""
        else "Hay una elección pendiente entre estos contactos: " +
            choiceNames.split("\u0001").mapIndexed { i, n -> "${i + 1}) $n" }.joinToString(", ") +
            ". Si el usuario elige uno, usá choose_contact con option = su número. Si dice que ninguno, usá cancel_send.\n"
        val memoryLine = if (mem.isEmpty()) "" else "Lo que sabés del usuario (memoria):\n" + mem.joinToString("\n") { "- $it" } + "\n"
        val system = """
Sos Jarvis, un asistente de voz en el celular del usuario.
Respondé SIEMPRE y SOLO con un objeto JSON válido, sin markdown ni texto extra.
Esquema: {"say":"lo que decís en voz alta","action":"none|alarm|alarm_off|timer|flashlight|dnd|call|calendar|read_messages|read_notifications|play_voice_note|send_whatsapp|confirm_send|cancel_send|image_search|web_search|open_app|remember|forget|create_file|choose_contact|reminder|list_add|list_read|list_remove|volume|brightness|connectivity|system|camera|play_music|scan_chats|handsfree", ...campos}
Campos según la acción:
- alarm: hour (0-23), minute (0-59), label
- alarm_off: borra la próxima alarma programada (sin campos)
- read_messages: contact (nombre del contacto, o vacío para los últimos mensajes de WhatsApp). El teléfono los lee en voz alta; vos no ves el contenido.
- read_notifications: sin campos, lee en voz alta las últimas notificaciones
- play_voice_note: sin campos, reproduce el último audio de WhatsApp recibido
- send_whatsapp: contact (nombre tal como lo dijo, vacío = el último que escribió), text (el mensaje exacto a enviar). El teléfono pide confirmación al usuario antes de enviar.
- confirm_send: sin campos, cuando el usuario confirma el envío pendiente
- cancel_send: sin campos, cuando el usuario cancela el envío pendiente
- timer: seconds, label
- flashlight: on (true o false)
- dnd (no molestar): on (true o false)
- call: contact (el nombre tal como lo dijo el usuario; vacío = el último contacto que escribió por WhatsApp)
- calendar: title, start (formato yyyy-MM-ddTHH:mm, hora local), minutes (duración, 60 por defecto)
- image_search: query (qué imagen buscar, en pocas palabras). Abre Google Imágenes en Chrome y las muestra en pantalla. En say decí algo corto como "Acá tenés las imágenes."
- web_search: query (qué buscar). Abre una búsqueda de Google en Chrome.
- choose_contact: option (número 1, 2, 3...). Solo cuando hay una elección pendiente entre contactos y el usuario elige uno (por número, "el primero", o diciendo el nombre completo).
- reminder: text (qué recordar), start (yyyy-MM-ddTHH:mm, hora local). Si es en las próximas 23 horas suena como alarma con ese texto; si es más lejos, se abre el calendario para confirmar.
- list_add: list (nombre de la lista, "compras" por defecto), items (lista de cosas a agregar)
- list_read: list. Lee en voz alta la lista.
- list_remove: list, items (qué sacar; vacío = vaciar toda la lista)
- volume: mode (up|down|mute|unmute|max|level), percent (solo con level, 0-100)
- brightness: percent (1-100)
- connectivity: what (wifi|data|airplane|nfc|volume). Android no deja cambiarlo solo: abre el panel.
- system: which (screenshot|home|back|recents|lock|notifications)
- camera: sin campos, abre la cámara
- play_music: query (canción, artista o género). Abre la música en la app que tenga el teléfono.
- scan_chats: sin campos. Lee la lista de chats de WhatsApp para conocer todos los nombres. Usalo si el usuario dice "aprendé mis chats" o si no encuentra a alguien.
- handsfree: on (true o false). Activa o desactiva el manos libres (el teléfono escucha la palabra "Jarvis" todo el tiempo). Con 10 % de batería o menos se pausa solo, salvo que esté cargando.
- open_app: app (nombre de la app, ej. Instagram, YouTube, Spotify, Maps), query (opcional, qué buscar adentro; funciona en YouTube, Spotify y Maps; en Instagram solo un nombre de usuario)
- remember: text (dato importante del usuario o de sus proyectos, en una oración). Usalo cuando diga "acordate de..." o cuente algo importante sobre él o un proyecto.
- forget: text (palabra clave de lo que hay que olvidar)
- create_file: name (nombre, puede incluir carpeta, ej. proyecto/notas.md), content (todo el contenido del archivo). Sirve para crear proyectos, notas, listas o textos que el usuario pida. Se guarda en Documentos/Jarvis.
Si el usuario pregunta qué podés hacer, nombrá en una frase tus capacidades (llamar y escribir por WhatsApp, alarmas, recordatorios, listas, calendario, volumen y brillo, capturas, música, buscar, abrir apps, recordar cosas, crear archivos) y sugerí algo que todavía no usó.
Si hay algo que no podés hacer todavía, decíselo claro y proponé la alternativa más cercana.
Si no hay nada que ejecutar, action es "none" y solo conversás.
"say" es MUY breve: una sola oración corta (idealmente menos de 12 palabras), salvo que el usuario pida una explicación. Español rioplatense, sin markdown.
${memoryLine}${choiceLine}${pendingLine}${sendLine}Fecha y hora actual: $now (formato ISO: $iso).
""".trimIndent()
        val contents = JSONArray()
        for ((role, text) in history.toList().takeLast(6)) {
            contents.put(
                JSONObject().put("role", role)
                    .put("parts", JSONArray().put(JSONObject().put("text", text)))
            )
        }
        contents.put(
            JSONObject().put("role", "user")
                .put("parts", JSONArray().put(JSONObject().put("text", question)))
        )
        val body = JSONObject()
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system))))
            .put("contents", contents)

        // Primero intentamos con "pensamiento" bajo para que responda rápido.
        // Si el modelo no acepta esa opción (error 400), reintentamos sin ella.
        val fast = JSONObject(body.toString()).put(
            "generationConfig",
            JSONObject()
                .put("responseMimeType", "application/json")
                .put("thinkingConfig", JSONObject().put("thinkingLevel", "minimal"))
        )
        var code = 0
        var txt = ""
        for (attempt in 0 until 3) {
        if (attempt > 0) {
            if (code != 503) break
            try { Thread.sleep(1500L * attempt) } catch (e: InterruptedException) { }
        }
        for (mi in (if (attempt == 0) textModelIdx else 0) until MODELS.size) {
            val model = MODELS[mi]
            var r = if (thinkingOk) post(key, model, fast, 20000) else post(key, model, body, 20000)
            if (r.first == 400 && thinkingOk) {
                val r2 = post(key, model, body, 20000)
                if (r2.first in 200..299) thinkingOk = false
                r = r2
            }
            code = r.first
            txt = r.second
            if (code != 404 && code != 429 && code != 503 && code != 504) {
                if (code in 200..299) textModelIdx = mi
                break
            }
        }
        if (code != 503) break
        }
        if (code !in 200..299) textModelIdx = 0

        if (code !in 200..299) {
            if (code == 429) return "Gemini: se acabó el cupo gratis por ahora. Probá más tarde."
            if (code == 504) return "Gemini tardó demasiado en responder. Probá de nuevo."
            if (code == 503) return "Gemini está saturado en este momento. Probá de nuevo en unos segundos."
            val msg = try {
                JSONObject(txt).getJSONObject("error").getString("message")
            } catch (e: Exception) {
                txt.take(150)
            }
            return "Gemini devolvió el error $code: ${msg.take(120)}"
        }
        val cands = JSONObject(txt).optJSONArray("candidates")
        val parts = cands?.optJSONObject(0)?.optJSONObject("content")?.optJSONArray("parts")
            ?: return "Gemini no devolvió respuesta: ${txt.take(150)}"
        val sb = StringBuilder()
        for (i in 0 until parts.length()) sb.append(parts.getJSONObject(i).optString("text", ""))
        return sb.toString().trim().ifEmpty { "No tengo respuesta para eso." }
    }

    override fun onDestroy() {
        instance = null
        player?.release()
        stopSpeaking()
        bubble?.let { wm.removeView(it) }
        bubble = null
        main.removeCallbacksAndMessages(null)
        try { batteryReceiver?.let { unregisterReceiver(it) } } catch (e: Exception) { }
        recognizer?.destroy()
        tts?.shutdown()
        super.onDestroy()
    }
}
