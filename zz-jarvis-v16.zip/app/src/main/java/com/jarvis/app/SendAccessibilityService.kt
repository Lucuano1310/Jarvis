package com.jarvis.app

import android.accessibilityservice.AccessibilityService
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Toast
import java.text.Normalizer

class SendAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile var armedUntil = 0L
        @Volatile var running = false
        @Volatile var instance: SendAccessibilityService? = null

        // Flujo "buscar el chat por nombre": escribir o llamar desde WhatsApp.
        @Volatile var flowUntil = 0L
        @Volatile var flowName = ""
        @Volatile var flowText = ""
        @Volatile var flowCall = false
        @Volatile var flowStep = 0
        @Volatile var flowTries = 0

        fun startFlow(name: String, text: String, call: Boolean): Boolean {
            val s = instance ?: return false
            s.beginFlow(name, text, call)
            return true
        }
    }

    private val h = Handler(Looper.getMainLooper())
    private val poll = object : Runnable {
        override fun run() {
            if (System.currentTimeMillis() < flowUntil) {
                try { stepFlow() } catch (e: Exception) { }
                h.postDelayed(this, 700)
            } else if (flowStep in 0..3) {
                flowStep = 99
                Toast.makeText(
                    this@SendAccessibilityService,
                    "No pude encontrar el chat de $flowName en WhatsApp.",
                    Toast.LENGTH_LONG
                ).show()
            }
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        running = true
        instance = this
    }

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        running = false
        instance = null
        return super.onUnbind(intent)
    }

    private fun beginFlow(name: String, text: String, call: Boolean) {
        flowName = name
        flowText = text
        flowCall = call
        flowStep = 0
        flowTries = 0
        flowUntil = System.currentTimeMillis() + 35000
        h.removeCallbacks(poll)
        h.postDelayed(poll, 1800)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (System.currentTimeMillis() > armedUntil) return
        val root = rootInActiveWindow ?: return
        val node = findSend(root) ?: return
        if (node.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
            armedUntil = 0L
        }
    }

    override fun onInterrupt() {}

    // ---------- Flujo por nombre ----------

    private fun stepFlow() {
        val root = rootInActiveWindow ?: return
        val pkg = root.packageName?.toString() ?: return
        if (!pkg.startsWith("com.whatsapp")) return
        val entry = findById(root, "entry")
        val token = firstToken(flowName)
        when (flowStep) {
            0 -> {
                if (entry != null) {
                    // estamos dentro de un chat: volvemos a la lista
                    performGlobalAction(GLOBAL_ACTION_BACK)
                    return
                }
                val s = findSearch(root)
                if (s != null && clickNode(s)) {
                    flowStep = 1
                    flowTries = 0
                }
            }
            1 -> {
                val edit = findEdit(root)
                if (edit != null) {
                    if (setText(edit, token)) {
                        flowStep = 2
                        flowTries = 0
                    }
                } else {
                    flowTries++
                    if (flowTries > 6) flowStep = 0
                }
            }
            2 -> {
                val r = findResult(root, token)
                if (r != null && clickNode(r)) {
                    flowStep = 3
                    flowTries = 0
                }
            }
            3 -> {
                if (entry == null) return
                if (flowCall) {
                    val b = findByDesc(root, listOf("llamada de voz", "voice call", "llamar", "call"))
                    if (b != null && clickNode(b)) {
                        flowStep = 4
                        flowTries = 0
                    }
                } else {
                    if (flowText.isNotEmpty() && setText(entry, flowText)) flowStep = 5
                }
            }
            4 -> {
                // WhatsApp a veces pide confirmar la llamada
                val ok = findButtonText(root, listOf("llamar", "call"))
                if (ok != null && clickNode(ok)) {
                    flowUntil = 0L
                    flowStep = 100
                    return
                }
                flowTries++
                if (flowTries >= 3) {
                    flowUntil = 0L
                    flowStep = 100
                }
            }
            5 -> {
                val send = findSend(root)
                if (send != null && send.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                    flowUntil = 0L
                    flowStep = 100
                } else {
                    flowTries++
                    if (flowTries > 6) flowStep = 3
                }
            }
        }
    }

    private fun norm(t: String): String =
        Normalizer.normalize(t, Normalizer.Form.NFD)
            .replace(Regex("\\p{InCombiningDiacriticalMarks}+"), "")
            .lowercase()

    private fun keyOf(t: String): String = norm(t).replace(Regex("[^a-z0-9]"), "")

    private fun firstToken(name: String): String =
        name.split(Regex("[^\\p{L}\\p{N}]+")).firstOrNull { it.length >= 2 } ?: name.trim()

    private fun walk(n: AccessibilityNodeInfo?, out: MutableList<AccessibilityNodeInfo>, depth: Int = 0) {
        if (n == null || depth > 30) return
        out.add(n)
        for (i in 0 until n.childCount) walk(n.getChild(i), out, depth + 1)
    }

    private fun all(root: AccessibilityNodeInfo): List<AccessibilityNodeInfo> {
        val out = ArrayList<AccessibilityNodeInfo>()
        walk(root, out)
        return out
    }

    private fun findById(root: AccessibilityNodeInfo, name: String): AccessibilityNodeInfo? {
        for (p in listOf("com.whatsapp", "com.whatsapp.w4b")) {
            val n = root.findAccessibilityNodeInfosByViewId("$p:id/$name").firstOrNull()
            if (n != null) return n
        }
        return null
    }

    private fun label(n: AccessibilityNodeInfo): String =
        ((n.text?.toString() ?: "") + " " + (n.contentDescription?.toString() ?: "")).lowercase()

    private fun findSearch(root: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        findById(root, "menuitem_search")?.let { return it }
        return all(root).firstOrNull {
            val t = label(it)
            it.className?.toString() != "android.widget.EditText" && (t.contains("buscar") || t.contains("search"))
        }
    }

    private fun findEdit(root: AccessibilityNodeInfo): AccessibilityNodeInfo? =
        all(root).firstOrNull { it.className?.toString() == "android.widget.EditText" }

    private fun findResult(root: AccessibilityNodeInfo, token: String): AccessibilityNodeInfo? {
        val t = norm(token)
        val cands = all(root).filter {
            it.className?.toString() != "android.widget.EditText" &&
                (it.text?.toString() ?: "").isNotEmpty() &&
                norm(it.text.toString()).contains(t)
        }
        if (cands.isEmpty()) return null
        val wanted = keyOf(flowName)
        return cands.firstOrNull { keyOf(it.text.toString()) == wanted } ?: cands.first()
    }

    private fun findByDesc(root: AccessibilityNodeInfo, descs: List<String>): AccessibilityNodeInfo? {
        for (d in descs) {
            val n = all(root).firstOrNull {
                val cd = it.contentDescription?.toString()?.lowercase() ?: ""
                cd.isNotEmpty() && cd.contains(d) && !cd.contains("video")
            }
            if (n != null) return n
        }
        return null
    }

    private fun findButtonText(root: AccessibilityNodeInfo, names: List<String>): AccessibilityNodeInfo? =
        all(root).firstOrNull {
            val t = it.text?.toString()?.trim()?.lowercase() ?: ""
            t in names
        }

    private fun clickNode(n0: AccessibilityNodeInfo): Boolean {
        var n: AccessibilityNodeInfo? = n0
        var d = 0
        while (n != null && d < 6) {
            if (n.isClickable && n.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
            n = n.parent
            d++
        }
        return false
    }

    private fun setText(n: AccessibilityNodeInfo, text: String): Boolean {
        val b = Bundle()
        b.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        return n.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, b)
    }

    private fun findSend(root: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        for (id in listOf("com.whatsapp:id/send", "com.whatsapp.w4b:id/send")) {
            val n = root.findAccessibilityNodeInfosByViewId(id).firstOrNull()
            if (n != null) return n
        }
        for (label in listOf("Enviar", "Send")) {
            val n = root.findAccessibilityNodeInfosByText(label).firstOrNull { it.isClickable }
            if (n != null) return n
        }
        return null
    }
}
