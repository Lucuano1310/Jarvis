package com.jarvis.app

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.net.Uri
import android.provider.AlarmClock
import android.provider.CalendarContract
import android.provider.ContactsContract
import android.provider.Settings
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.TextView
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.concurrent.thread
import kotlin.math.abs

class OverlayService : Service(), TextToSpeech.OnInitListener {

    companion object {
        // Modelos de Gemini, en orden. Si uno no existe (404) o se acabó su cupo gratis (429),
        // se prueba el siguiente. Los "lite" son mucho más rápidos y tienen más cupo gratis.
        @Volatile var instance: OverlayService? = null
        val TTS_MODELS = listOf("gemini-3.8-flash-lite-tts", "gemini-3.8-flash-tts")
        val MODELS = listOf("gemini-3.5-flash-lite", "gemini-3.1-flash-lite", "gemini-4-hydrogen")
        const val COLOR_IDLE = "#E6007AFF"
        const val COLOR_LISTENING = "#E6FF3B30"
        const val COLOR_THINKING = "#E6FF9500"
    }

    private lateinit var wm: WindowManager
    private var bubble: TextView? = null
    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private val main = Handler(Looper.getMainLooper())
    private val history = java.util.concurrent.CopyOnWriteArrayList<Pair<String, String>>()
    @Volatile private var heard = ""
    private var player: android.media.MediaPlayer? = null
    private var voicePlayer: android.media.MediaPlayer? = null
    private val speakId = java.util.concurrent.atomic.AtomicInteger(0)

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        instance = this
        startAsForeground()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        tts = TextToSpeech(this, this)
        addBubble()
    }

    override fun onInit(status: Int) {
        tts?.language = Locale("es")
        val saved = getSharedPreferences("jarvis", MODE_PRIVATE).getString("voice", null)
        if (saved != null) {
            tts?.voices?.firstOrNull { it.name == saved }?.let { tts?.voice = it }
        }
        tts?.setPitch(0.85f)
        tts?.setSpeechRate(0.95f)
    }

    private fun startAsForeground() {
        val channelId = "jarvis"
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(channelId, "Jarvis", NotificationManager.IMPORTANCE_MIN)
        )
        val n = Notification.Builder(this, channelId)
            .setContentTitle("Jarvis activo")
            .setContentText("Tocá la burbuja para hablar. Mantenela apretada para pausar.")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } else {
            startForeground(1, n)
        }
    }

    private fun setBubble(letter: String, color: String) {
        bubble?.text = letter
        (bubble?.background as? GradientDrawable)?.setColor(Color.parseColor(color))
    }

    private fun addBubble() {
        val size = (56 * resources.displayMetrics.density).toInt()
        val tv = TextView(this).apply {
            text = "J"
            textSize = 22f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.parseColor(COLOR_IDLE))
            }
        }
        val lp = WindowManager.LayoutParams(
            size, size,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.END
            x = 16
            y = 300
        }

        var startX = 0
        var startY = 0
        var touchX = 0f
        var touchY = 0f
        var moved = false

        tv.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = lp.x; startY = lp.y
                    touchX = e.rawX; touchY = e.rawY
                    moved = false
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - touchX).toInt()
                    val dy = (e.rawY - touchY).toInt()
                    if (abs(dx) > 10 || abs(dy) > 10) moved = true
                    if (moved) {
                        lp.x = startX - dx
                        lp.y = startY + dy
                        wm.updateViewLayout(tv, lp)
                    }
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) {
                        if (e.eventTime - e.downTime > 800) stopSelf() else listen()
                    }
                }
            }
            true
        }
        bubble = tv
        wm.addView(tv, lp)
    }

    private fun say(text: String) {
        setBubble("J", COLOR_IDLE)
        speak(text)
    }

    private fun localSpeak(text: String) {
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis")
    }

    private fun stopSpeaking() {
        speakId.incrementAndGet()
        tts?.stop()
        try { voicePlayer?.release() } catch (e: Exception) { }
        voicePlayer = null
    }

    private fun speak(text: String) {
        stopSpeaking()
        val id = speakId.get()
        val prefs = getSharedPreferences("jarvis", MODE_PRIVATE)
        val voice = prefs.getString("cloud_voice", "Charon") ?: ""
        val key = prefs.getString("key", "") ?: ""
        if (voice.isEmpty() || key.isEmpty() || text.length > 700) {
            localSpeak(text)
            return
        }
        thread {
            val f = try { cloudTts(key, voice, text) } catch (e: Exception) { null }
            main.post {
                if (id != speakId.get()) {
                    f?.delete()
                } else if (f == null) {
                    localSpeak(text)
                } else {
                    playSpeechFile(f, text)
                }
            }
        }
    }

    private fun playSpeechFile(f: java.io.File, text: String) {
        try {
            val mp = android.media.MediaPlayer()
            voicePlayer = mp
            mp.setDataSource(f.absolutePath)
            mp.setOnCompletionListener { it.release(); f.delete() }
            mp.prepare()
            mp.start()
        } catch (e: Exception) {
            f.delete()
            localSpeak(text)
        }
    }

    private fun addWavHeader(pcm: ByteArray, rate: Int): ByteArray {
        val bb = java.nio.ByteBuffer.allocate(44 + pcm.size).order(java.nio.ByteOrder.LITTLE_ENDIAN)
        bb.put("RIFF".toByteArray()); bb.putInt(36 + pcm.size); bb.put("WAVE".toByteArray())
        bb.put("fmt ".toByteArray()); bb.putInt(16); bb.putShort(1); bb.putShort(1)
        bb.putInt(rate); bb.putInt(rate * 2); bb.putShort(2); bb.putShort(16)
        bb.put("data".toByteArray()); bb.putInt(pcm.size); bb.put(pcm)
        return bb.array()
    }

    private fun cloudTts(key: String, voice: String, text: String): java.io.File? {
        val style = "calm, deep, refined and precise, like a sophisticated English butler, warm, natural and unhurried"
        val oldPrompt = "Say calmly, with the deep, refined and precise voice of a sophisticated English butler, speaking Spanish: $text"
        // Intentos en orden: (formato de voz, ¿estilo aparte del texto?)
        val attempts = listOf(Pair(0, true), Pair(0, false), Pair(1, false))
        for (model in TTS_MODELS) {
            for ((shape, useMeta) in attempts) {
                val voiceCfg = if (shape == 0) JSONObject().put("voice", voice)
                else JSONObject().put("prebuiltVoiceConfig", JSONObject().put("voiceName", voice))
                val part = if (useMeta) JSONObject().put("text", text).put("speech_metadata", JSONObject().put("style", style))
                else JSONObject().put("text", oldPrompt)
                val body = JSONObject()
                    .put("contents", JSONArray().put(JSONObject().put("parts", JSONArray().put(part))))
                    .put(
                        "generationConfig",
                        JSONObject()
                            .put("responseModalities", JSONArray().put("AUDIO"))
                            .put("speechConfig", JSONObject().put("voiceConfig", voiceCfg))
                    )
                val r = post(key, model, body)
                if (r.first == 400) continue
                if (r.first !in 200..299) break
                val parts = JSONObject(r.second).optJSONArray("candidates")?.optJSONObject(0)
                    ?.optJSONObject("content")?.optJSONArray("parts") ?: break
                for (i in 0 until parts.length()) {
                    val pt = parts.getJSONObject(i)
                    val inline = pt.optJSONObject("inlineData") ?: pt.optJSONObject("inline_data") ?: continue
                    val b64 = inline.optString("data", "")
                    if (b64.isEmpty()) continue
                    val mime = inline.optString("mimeType", inline.optString("mime_type", ""))
                    val bytes = android.util.Base64.decode(b64, android.util.Base64.DEFAULT)
                    val isWav = bytes.size > 4 && bytes[0] == 'R'.code.toByte() && bytes[1] == 'I'.code.toByte()
                    val rate = Regex("rate=(\\d+)").find(mime)?.groupValues?.get(1)?.toIntOrNull() ?: 24000
                    val file = java.io.File(cacheDir, "tts_${System.currentTimeMillis()}.wav")
                    file.writeBytes(if (isWav) bytes else addWavHeader(bytes, rate))
                    return file
                }
                break
            }
        }
        return null
    }

    private fun listen() {
        stopSpeaking()
        try { player?.release() } catch (e: Exception) { }
        player = null
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            say("Falta el permiso del micrófono.")
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            say("Este teléfono no tiene reconocimiento de voz.")
            return
        }
        recognizer?.destroy()
        setBubble("●", COLOR_LISTENING)
        recognizer = SpeechRecognizer.createSpeechRecognizer(this).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onPartialResults(partialResults: Bundle?) {}
                override fun onEvent(eventType: Int, params: Bundle?) {}
                override fun onError(error: Int) {
                    say("No te escuché, probá de nuevo.")
                }
                override fun onResults(results: Bundle?) {
                    val text = results
                        ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        ?.firstOrNull()
                    if (text.isNullOrBlank()) say("No te escuché.") else {
                        heard = text
                        ask(text)
                    }
                }
            })
            startListening(
                Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE, "es-AR")
                }
            )
        }
    }

    private fun ask(question: String) {
        setBubble("…", COLOR_THINKING)
        val key = getSharedPreferences("jarvis", MODE_PRIVATE).getString("key", "") ?: ""
        thread {
            val answer = try {
                callGemini(key, question)
            } catch (e: java.io.IOException) {
                "No pude conectarme a internet. Detalle: ${e.javaClass.simpleName} ${e.message}"
            } catch (e: Exception) {
                "Error inesperado: ${e.javaClass.simpleName} ${e.message}"
            }
            val isError = answer.startsWith("No pude") || answer.startsWith("Error") || answer.startsWith("Gemini")
            history.add(Pair("user", question))
            history.add(
                Pair(
                    "model",
                    if (isError) JSONObject().put("say", answer).put("action", "none").toString() else answer
                )
            )
            while (history.size > 8) history.removeAt(0)
            main.post { handleReply(answer) }
        }
    }

    private fun handleReply(raw: String) {
        if (raw.startsWith("No pude") || raw.startsWith("Error") || raw.startsWith("Gemini")) {
            android.widget.Toast.makeText(this, raw, android.widget.Toast.LENGTH_LONG).show()
            say(raw)
            return
        }
        val json = try {
            JSONObject(raw.substring(raw.indexOf('{'), raw.lastIndexOf('}') + 1))
        } catch (e: Exception) {
            null
        }
        if (json == null) {
            say(raw)
            return
        }
        val speech = json.optString("say", "")
        val msg = try {
            runAction(json)
        } catch (e: Exception) {
            "No pude hacer eso: ${e.message}"
        }
        if (msg != null) android.widget.Toast.makeText(this, msg, android.widget.Toast.LENGTH_LONG).show()
        say(msg ?: speech.ifEmpty { "Listo." })
    }

    private fun newTask(i: Intent): Intent = i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)

    private fun runAction(j: JSONObject): String? {
        when (j.optString("action", "none")) {
            "alarm" -> startActivity(
                newTask(
                    Intent(AlarmClock.ACTION_SET_ALARM)
                        .putExtra(AlarmClock.EXTRA_HOUR, j.getInt("hour"))
                        .putExtra(AlarmClock.EXTRA_MINUTES, j.optInt("minute", 0))
                        .putExtra(AlarmClock.EXTRA_MESSAGE, j.optString("label", "Jarvis"))
                        .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
                )
            )
            "timer" -> startActivity(
                newTask(
                    Intent(AlarmClock.ACTION_SET_TIMER)
                        .putExtra(AlarmClock.EXTRA_LENGTH, j.getInt("seconds"))
                        .putExtra(AlarmClock.EXTRA_MESSAGE, j.optString("label", "Jarvis"))
                        .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
                )
            )
            "alarm_off" -> return deleteNextAlarm()
            "read_messages" -> return readMessages(j.optString("contact", ""))
            "play_voice_note" -> return playVoiceNote()
            "send_whatsapp" -> return prepareSend(j.optString("contact", ""), j.optString("text", ""))
            "confirm_send" -> return confirmSend()
            "cancel_send" -> return cancelSend()
            "read_notifications" -> return readNotifications()
            "flashlight" -> setTorch(j.optBoolean("on", true))
            "dnd" -> return setDnd(j.optBoolean("on", true))
            "call" -> return callContact(j.optString("contact", ""))
            "calendar" -> return addEvent(j)
        }
        return null
    }

    private fun setTorch(on: Boolean) {
        val cm = getSystemService(CameraManager::class.java)
        val id = cm.cameraIdList.firstOrNull {
            cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
        } ?: return
        cm.setTorchMode(id, on)
    }

    private fun setDnd(on: Boolean): String? {
        val nm = getSystemService(NotificationManager::class.java)
        if (!nm.isNotificationPolicyAccessGranted) {
            startActivity(newTask(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)))
            return "Necesito permiso para No molestar. Activalo para Jarvis en la pantalla que se abrió."
        }
        nm.setInterruptionFilter(
            if (on) NotificationManager.INTERRUPTION_FILTER_PRIORITY
            else NotificationManager.INTERRUPTION_FILTER_ALL
        )
        return null
    }

    private fun norm(t: String): String =
        java.text.Normalizer.normalize(t, java.text.Normalizer.Form.NFD)
            .replace(Regex("\\p{InCombiningDiacriticalMarks}+"), "")
            .lowercase(Locale.ROOT)
            .trim()

    private fun deleteNextAlarm(): String? {
        return try {
            val action = if (Build.VERSION.SDK_INT >= 36) "android.intent.action.DELETE_ALARM"
            else AlarmClock.ACTION_DISMISS_ALARM
            startActivity(
                newTask(
                    Intent(action)
                        .putExtra(AlarmClock.EXTRA_ALARM_SEARCH_MODE, AlarmClock.ALARM_SEARCH_MODE_NEXT)
                        .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
                )
            )
            null
        } catch (e: android.content.ActivityNotFoundException) {
            "Tu app de reloj no me deja borrar alarmas por voz."
        }
    }

    private fun key(t: String): String =
        norm(t).replace(Regex("\\b(numeral|almohadilla|hashtag)\\b"), "").replace(Regex("[^a-z0-9]"), "")

    private fun wordKeys(t: String): List<String> =
        norm(t).replace(Regex("\\b(numeral|almohadilla|hashtag)\\b"), " ")
            .split(Regex("\\s+"))
            .map { key(it) }
            .filter { it.isNotEmpty() && (it.length > 2 || it.all { c -> c.isDigit() }) }

    private fun lastSender(): String? =
        NotifStore.all(this).lastOrNull { it.app == "WhatsApp" }?.sender

    /** Busca el contacto que mejor coincida. rows = lista de (nombre, número). */
    private fun matchContact(rows: List<Pair<String, String>>, spoken: String): Pair<String, String>? {
        val wantedKey = key(spoken)
        val words = wordKeys(spoken)
        if (wantedKey.isEmpty()) return null
        rows.firstOrNull { key(it.first).contains(wantedKey) }?.let { return it }
        if (words.isNotEmpty()) {
            rows.firstOrNull { r -> val k = key(r.first); words.all { w -> k.contains(w) } }?.let { return it }
        }
        return null
    }

    private fun phoneRows(): List<Pair<String, String>> {
        val out = ArrayList<Pair<String, String>>()
        val cursor = contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                ContactsContract.CommonDataKinds.Phone.NUMBER
            ),
            null, null, null
        )
        cursor?.use {
            while (it.moveToNext()) {
                val n = it.getString(0) ?: continue
                val num = it.getString(1) ?: continue
                out.add(Pair(n, num))
            }
        }
        return out
    }

    private fun whatsappRows(): List<Pair<String, String>> {
        val out = ArrayList<Pair<String, String>>()
        val cursor = contentResolver.query(
            ContactsContract.Data.CONTENT_URI,
            arrayOf(ContactsContract.Data.DISPLAY_NAME, ContactsContract.Data.DATA1),
            "${ContactsContract.Data.MIMETYPE} = ?",
            arrayOf("vnd.android.cursor.item/vnd.com.whatsapp.profile"),
            null
        )
        cursor?.use {
            while (it.moveToNext()) {
                val n = it.getString(0) ?: continue
                val jid = it.getString(1) ?: continue
                val digits = jid.substringBefore('@').filter { c -> c.isDigit() }
                if (digits.isNotEmpty()) out.add(Pair(n, digits))
            }
        }
        return out
    }

    private fun callContact(name: String): String? {
        if (checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED ||
            checkSelfPermission(Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED
        ) {
            return "Me faltan los permisos de contactos y llamadas. Dalos desde la app de Jarvis."
        }
        val spoken = if (key(name).isEmpty()) {
            lastSender() ?: return "No tengo ningún mensaje reciente para saber a quién llamar."
        } else name
        val rows = phoneRows()
        val match = matchContact(rows, spoken)
        if (match != null) {
            startActivity(newTask(Intent(Intent.ACTION_CALL, Uri.parse("tel:" + Uri.encode(match.second)))))
            return "Llamando a ${match.first}."
        }
        return "No encontré a $spoken entre ${rows.size} contactos. Escuché: $heard."
    }

    private fun prepareSend(contact: String, text: String): String? {
        if (checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
            return "Me faltan los permisos de contactos. Dalos desde la app de Jarvis."
        }
        if (text.isBlank()) return "No entendí qué mensaje enviar."
        val spoken = if (key(contact).isEmpty()) {
            lastSender() ?: return "No tengo ningún mensaje reciente para saber a quién escribirle."
        } else contact
        val target = matchContact(whatsappRows(), spoken) ?: matchContact(phoneRows(), spoken)
            ?: return "No encontré a $spoken para escribirle. Escuché: $heard."
        getSharedPreferences("jarvis", MODE_PRIVATE).edit()
            .putString("send_name", target.first)
            .putString("send_number", target.second.filter { it.isDigit() })
            .putString("send_text", text)
            .apply()
        return "Le voy a escribir a ${target.first}: $text. ¿Lo envío?"
    }

    private fun cancelSend(): String? {
        getSharedPreferences("jarvis", MODE_PRIVATE).edit()
            .remove("send_name").remove("send_number").remove("send_text").apply()
        return null
    }

    private fun confirmSend(): String? {
        val prefs = getSharedPreferences("jarvis", MODE_PRIVATE)
        val number = prefs.getString("send_number", null) ?: return "No tengo ningún mensaje pendiente de enviar."
        val text = prefs.getString("send_text", "") ?: ""
        cancelSend()
        SendAccessibilityService.armedUntil = System.currentTimeMillis() + 20000
        val uri = Uri.parse("https://wa.me/$number?text=" + Uri.encode(text))
        try {
            startActivity(newTask(Intent(Intent.ACTION_VIEW, uri).setPackage("com.whatsapp")))
        } catch (e: android.content.ActivityNotFoundException) {
            startActivity(newTask(Intent(Intent.ACTION_VIEW, uri)))
        }
        return if (SendAccessibilityService.running) null
        else "Abrí el chat con el mensaje listo, pero me falta el permiso de accesibilidad para enviarlo solo."
    }

    private fun readMessages(contact: String): String? {
        clearPending()
        val wanted = norm(contact)
        val items = NotifStore.all(this).filter { it.app == "WhatsApp" }
        val list = if (wanted.isEmpty()) items.takeLast(3)
        else items.filter { norm(it.sender).contains(wanted) }.takeLast(3)
        if (list.isEmpty()) {
            return if (wanted.isEmpty()) "No tengo mensajes recientes de WhatsApp."
            else "No tengo mensajes recientes de $contact."
        }
        return list.joinToString(" ") { "${it.sender} dice: ${it.text}." }
    }

    private fun readNotifications(): String? {
        val list = NotifStore.all(this).takeLast(5)
        if (list.isEmpty()) {
            return "No tengo notificaciones guardadas. Revisá que Jarvis tenga acceso a las notificaciones."
        }
        return list.joinToString(" ") { "${it.app}: ${it.sender}. ${it.text}." }
    }

    fun announce(sender: String, voice: Boolean = false) {
        main.post {
            getSharedPreferences("jarvis", MODE_PRIVATE).edit()
                .putString("pending_sender", sender)
                .putString("pending_type", if (voice) "voice" else "text")
                .apply()
            val frase = if (voice) "Señor, $sender le mandó un audio. ¿Quiere que lo reproduzca?"
            else "Señor, le escribió $sender. ¿Quiere saber qué dice?"
            speak(frase)
        }
    }

    private fun clearPending() {
        getSharedPreferences("jarvis", MODE_PRIVATE).edit()
            .remove("pending_sender").remove("pending_type").apply()
    }

    private fun findLastVoiceNote(): java.io.File? {
        val roots = listOf(
            "/storage/emulated/0/Android/media/com.whatsapp/WhatsApp/Media/WhatsApp Voice Notes",
            "/storage/emulated/0/Android/media/com.whatsapp.w4b/WhatsApp Business/Media/WhatsApp Business Voice Notes",
            "/storage/emulated/0/WhatsApp/Media/WhatsApp Voice Notes"
        )
        val all = roots.flatMap { r ->
            val dir = java.io.File(r)
            if (!dir.exists()) emptyList<java.io.File>()
            else dir.walkTopDown().filter { it.isFile && it.extension.lowercase() in listOf("opus", "ogg", "m4a", "mp3", "aac") }.toList()
        }
        return all.maxByOrNull { it.lastModified() }
    }

    private fun playVoiceNote(): String? {
        clearPending()
        if (Build.VERSION.SDK_INT >= 30 && !android.os.Environment.isExternalStorageManager()) {
            return "Necesito el permiso de audios de WhatsApp. Tocá ese botón en la app de Jarvis."
        }
        val file = (try { findLastVoiceNote() } catch (e: Exception) { null })
            ?: return "No encontré audios en la carpeta de WhatsApp."
        main.postDelayed({
            try {
                player?.release()
                player = android.media.MediaPlayer().apply {
                    setDataSource(file.absolutePath)
                    setOnCompletionListener { mp -> mp.release() }
                    prepare()
                    start()
                }
            } catch (e: Exception) {
                android.widget.Toast.makeText(this, "No pude reproducir el audio: ${e.message}", android.widget.Toast.LENGTH_LONG).show()
            }
        }, 2500)
        return null
    }

    private fun addEvent(j: JSONObject): String? {
        val start = SimpleDateFormat("yyyy-MM-dd'T'HH:mm", Locale.US).parse(j.getString("start"))
            ?: return "No entendí la fecha."
        val end = start.time + j.optInt("minutes", 60) * 60000L
        startActivity(
            newTask(
                Intent(Intent.ACTION_INSERT)
                    .setData(CalendarContract.Events.CONTENT_URI)
                    .putExtra(CalendarContract.Events.TITLE, j.optString("title", "Evento"))
                    .putExtra(CalendarContract.EXTRA_EVENT_BEGIN_TIME, start.time)
                    .putExtra(CalendarContract.EXTRA_EVENT_END_TIME, end)
            )
        )
        return null
    }

    private fun post(key: String, model: String, body: JSONObject): Pair<Int, String> {
        val url = URL("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent")
        val c = url.openConnection() as HttpURLConnection
        c.requestMethod = "POST"
        c.connectTimeout = 20000
        c.readTimeout = 90000
        c.doOutput = true
        c.setRequestProperty("Content-Type", "application/json")
        c.setRequestProperty("x-goog-api-key", key)
        c.outputStream.use { it.write(body.toString().toByteArray()) }
        val code = c.responseCode
        val stream = if (code in 200..299) c.inputStream else c.errorStream
        val txt = stream?.bufferedReader()?.readText() ?: ""
        return Pair(code, txt)
    }

    private fun callGemini(key: String, question: String): String {
        val now = SimpleDateFormat("EEEE d 'de' MMMM 'de' yyyy, HH:mm", Locale("es")).format(Date())
        val iso = SimpleDateFormat("yyyy-MM-dd'T'HH:mm", Locale.US).format(Date())
        val prefs = getSharedPreferences("jarvis", MODE_PRIVATE)
        val pending = prefs.getString("pending_sender", "") ?: ""
        val pendingType = prefs.getString("pending_type", "text")
        val pendingLine = if (pending.isEmpty()) ""
        else if (pendingType == "voice")
            "Hace poco avisaste al usuario de que $pending le mandó un audio de WhatsApp. " +
                "Si el usuario responde que sí o pide escucharlo, usá play_voice_note.\n"
        else
            "Hace poco avisaste al usuario de un mensaje de WhatsApp de $pending (no sabés qué dice). " +
                "Si el usuario responde que sí o pide leerlo, usá read_messages con contact = ese nombre.\n"
        val sendText = prefs.getString("send_text", "") ?: ""
        val sendLine = if (sendText.isEmpty()) ""
        else "Hay un mensaje de WhatsApp pendiente de confirmar para ${prefs.getString("send_name", "")}: \"$sendText\". " +
            "Si el usuario confirma (sí, dale, enviá), usá confirm_send. Si dice que no, usá cancel_send. " +
            "Si lo corrige, usá send_whatsapp de nuevo con el texto corregido.\n"
        val system = """
Sos Jarvis, un asistente de voz en el celular del usuario.
Respondé SIEMPRE y SOLO con un objeto JSON válido, sin markdown ni texto extra.
Esquema: {"say":"lo que decís en voz alta","action":"none|alarm|alarm_off|timer|flashlight|dnd|call|calendar|read_messages|read_notifications|play_voice_note|send_whatsapp|confirm_send|cancel_send", ...campos}
Campos según la acción:
- alarm: hour (0-23), minute (0-59), label
- alarm_off: borra la próxima alarma programada (sin campos)
- read_messages: contact (nombre del contacto, o vacío para los últimos mensajes de WhatsApp). El teléfono los lee en voz alta; vos no ves el contenido.
- read_notifications: sin campos, lee en voz alta las últimas notificaciones
- play_voice_note: sin campos, reproduce el último audio de WhatsApp recibido
- send_whatsapp: contact (nombre tal como lo dijo, vacío = el último que escribió), text (el mensaje exacto a enviar). El teléfono pide confirmación al usuario antes de enviar.
- confirm_send: sin campos, cuando el usuario confirma el envío pendiente
- cancel_send: sin campos, cuando el usuario cancela el envío pendiente
- timer: seconds, label
- flashlight: on (true o false)
- dnd (no molestar): on (true o false)
- call: contact (el nombre tal como lo dijo el usuario; vacío = el último contacto que escribió por WhatsApp)
- calendar: title, start (formato yyyy-MM-ddTHH:mm, hora local), minutes (duración, 60 por defecto)
Si no hay nada que ejecutar, action es "none" y solo conversás.
"say" es breve (máximo dos oraciones), en español rioplatense, sin markdown.
${pendingLine}${sendLine}Fecha y hora actual: $now (formato ISO: $iso).
""".trimIndent()
        val contents = JSONArray()
        for ((role, text) in history.toList().takeLast(6)) {
            contents.put(
                JSONObject().put("role", role)
                    .put("parts", JSONArray().put(JSONObject().put("text", text)))
            )
        }
        contents.put(
            JSONObject().put("role", "user")
                .put("parts", JSONArray().put(JSONObject().put("text", question)))
        )
        val body = JSONObject()
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system))))
            .put("contents", contents)

        // Primero intentamos con "pensamiento" bajo para que responda rápido.
        // Si el modelo no acepta esa opción (error 400), reintentamos sin ella.
        val fast = JSONObject(body.toString()).put(
            "generationConfig",
            JSONObject()
                .put("responseMimeType", "application/json")
                .put("thinkingConfig", JSONObject().put("thinkingLevel", "minimal"))
        )
        var code = 0
        var txt = ""
        for (model in MODELS) {
            var r = post(key, model, fast)
            if (r.first == 400) r = post(key, model, body)
            code = r.first
            txt = r.second
            if (code != 404 && code != 429 && code != 503) break
        }

        if (code !in 200..299) {
            if (code == 429) return "Gemini: se acabó el cupo gratis por ahora. Probá más tarde."
            val msg = try {
                JSONObject(txt).getJSONObject("error").getString("message")
            } catch (e: Exception) {
                txt.take(150)
            }
            return "Gemini devolvió el error $code: ${msg.take(120)}"
        }
        val cands = JSONObject(txt).optJSONArray("candidates")
        val parts = cands?.optJSONObject(0)?.optJSONObject("content")?.optJSONArray("parts")
            ?: return "Gemini no devolvió respuesta: ${txt.take(150)}"
        val sb = StringBuilder()
        for (i in 0 until parts.length()) sb.append(parts.getJSONObject(i).optString("text", ""))
        return sb.toString().trim().ifEmpty { "No tengo respuesta para eso." }
    }

    override fun onDestroy() {
        instance = null
        player?.release()
        stopSpeaking()
        bubble?.let { wm.removeView(it) }
        bubble = null
        recognizer?.destroy()
        tts?.shutdown()
        super.onDestroy()
    }
}
