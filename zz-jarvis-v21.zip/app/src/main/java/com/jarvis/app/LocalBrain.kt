package com.jarvis.app

import org.json.JSONArray
import org.json.JSONObject
import java.text.Normalizer
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/**
 * Entiende los pedidos más comunes sin internet ni Gemini.
 * Devuelve el mismo JSON que Gemini ({"say":..., "action":..., campos}) o null si no lo entiende.
 */
object LocalBrain {

    class Ctx(
        val batteryPct: Int,
        val charging: Boolean,
        val pendingSend: Boolean,
        val choiceCount: Int
    )

    private val NUM = mapOf(
        "cero" to 0, "dos" to 2, "tres" to 3, "cuatro" to 4, "cinco" to 5, "seis" to 6, "siete" to 7,
        "ocho" to 8, "nueve" to 9, "diez" to 10, "once" to 11, "doce" to 12, "trece" to 13,
        "catorce" to 14, "quince" to 15, "dieciseis" to 16, "diecisiete" to 17, "dieciocho" to 18,
        "diecinueve" to 19, "veinte" to 20, "veintiuno" to 21, "veintidos" to 22, "veintitres" to 23,
        "veinticuatro" to 24, "veinticinco" to 25, "veintiseis" to 26, "veintisiete" to 27,
        "veintiocho" to 28, "veintinueve" to 29, "treinta" to 30, "cuarenta" to 40, "cincuenta" to 50,
        "sesenta" to 60
    )
    private val U9 = mapOf(
        "uno" to 1, "dos" to 2, "tres" to 3, "cuatro" to 4, "cinco" to 5,
        "seis" to 6, "siete" to 7, "ocho" to 8, "nueve" to 9
    )
    private val COMPOUND = Regex("""\b(treinta|cuarenta|cincuenta) y (uno|dos|tres|cuatro|cinco|seis|siete|ocho|nueve)\b""")
    private val SINGLES = Regex("""\b(""" + NUM.keys.sortedByDescending { it.length }.joinToString("|") + """)\b""")

    private fun norm(t: String): String =
        Normalizer.normalize(t, Normalizer.Form.NFD)
            .replace(Regex("\\p{InCombiningDiacriticalMarks}+"), "")
            .lowercase(Locale.ROOT)

    private fun digitize(s: String): String {
        var r = COMPOUND.replace(s) { m -> ((NUM[m.groupValues[1]] ?: 0) + (U9[m.groupValues[2]] ?: 0)).toString() }
        r = SINGLES.replace(r) { m -> (NUM[m.value] ?: 0).toString() }
        return r
    }

    private fun res(say: String, action: String): JSONObject =
        JSONObject().put("say", say).put("action", action)

    private val CLOCK = Regex(
        """\b(?:a\s+las?|para\s+las?)\s+(\d{1,2}|una)(?::(\d{2}))?(?:\s+y\s+(media|cuarto|\d{1,2}))?(?:\s+menos\s+(cuarto|\d{1,2}))?(?:\s+(?:de\s+la|de|en\s+la|del)\s+(manana|tarde|noche|madrugada|mediodia))?"""
    )
    private val DURATION = Regex("""\b(?:en|dentro\s+de|de|por)?\s*(\d+|un|una)\s*(horas?|min\w*|seg\w*)\b""")

    private fun nextMinutes(h: Int, m: Int, now: Calendar): Int {
        val cur = now.get(Calendar.HOUR_OF_DAY) * 60 + now.get(Calendar.MINUTE)
        val target = h * 60 + m
        return ((target - cur) % 1440 + 1440) % 1440
    }

    /** Devuelve hora, minutos y el rango (en caracteres) de la frase de hora dentro de `d`. */
    private fun parseClock(d: String): Triple<Int, Int, IntRange>? {
        val m = CLOCK.find(d) ?: return null
        var h = if (m.groupValues[1] == "una") 1 else m.groupValues[1].toIntOrNull() ?: return null
        var min = m.groupValues[2].toIntOrNull() ?: 0
        val y = m.groupValues[3]
        if (y.isNotEmpty()) min = when (y) { "media" -> 30; "cuarto" -> 15; else -> y.toIntOrNull() ?: 0 }
        val menos = m.groupValues[4]
        if (menos.isNotEmpty()) {
            val q = if (menos == "cuarto") 15 else (menos.toIntOrNull() ?: 0)
            h -= 1
            min = 60 - q
        }
        val period = m.groupValues[5]
        when (period) {
            "tarde", "noche" -> if (h < 12) h += 12
            "manana", "madrugada" -> if (h == 12) h = 0
            "mediodia" -> if (h < 12) h = 12
            else -> {
                if (h in 1..12) {
                    val now = Calendar.getInstance()
                    val a = h % 24
                    val b = (h + 12) % 24
                    h = if (nextMinutes(a, min, now) <= nextMinutes(b, min, now)) a else b
                }
            }
        }
        if (h < 0) h += 24
        if (h > 23 || min > 59) return null
        return Triple(h, min, m.range)
    }

    private fun durationSeconds(d: String): Pair<Int, IntRange>? {
        Regex("""\bmedia\s+hora\b""").find(d)?.let { return Pair(1800, it.range) }
        val m = DURATION.find(d) ?: return null
        val q = m.groupValues[1].let { if (it == "un" || it == "una") 1 else it.toIntOrNull() ?: return null }
        val u = m.groupValues[2]
        val secs = when {
            u.startsWith("hora") -> q * 3600
            u.startsWith("min") -> q * 60
            else -> q
        }
        return Pair(secs, m.range)
    }

    fun parse(text: String, ctx: Ctx): JSONObject? {
        val ot = text.replace(Regex("[¿?¡!,;.]"), " ").trim().split(Regex("\\s+")).filter { it.isNotEmpty() }
        if (ot.isEmpty()) return null
        val n = ot.joinToString(" ") { norm(it) }
        val d = digitize(n)
        val words = ot.size
        val dTokens = d.split(" ")
        val rt = if (dTokens.size == words) ot else dTokens

        fun sliceWith(tokens: List<String>, s: String, from: Int, to: Int): String {
            if (from >= to || from < 0 || to > s.length) return ""
            val a = s.substring(0, from).count { it == ' ' }
            val b = a + s.substring(from, to).count { it == ' ' } + 1
            return tokens.subList(a.coerceAtMost(tokens.size), b.coerceAtMost(tokens.size)).joinToString(" ")
        }
        fun sn(from: Int, to: Int) = sliceWith(ot, n, from, to)
        fun grp(m: MatchResult, i: Int): String {
            val g = m.groups[i] ?: return ""
            return sn(g.range.first, g.range.last + 1)
        }

        // --- respuestas a preguntas pendientes ---
        if (ctx.pendingSend && words <= 4) {
            if (Regex("""^(si|dale|ok|okey|enviar|envialo|enviala|mandalo|mandala|confirmo|confirmar|claro|obvio|de una|listo)\b""").containsMatchIn(n))
                return res("", "confirm_send")
            if (Regex("""^(no|nono|cancela\w*|ni|nada)\b""").containsMatchIn(n))
                return res("Cancelado.", "cancel_send")
        }
        if (ctx.choiceCount > 0 && words <= 4) {
            if (Regex("""^(ninguno|ninguna|no|cancela\w*)\b""").containsMatchIn(n)) return res("Cancelado.", "cancel_send")
            val m = Regex("""\b(primer\w*|1|uno|segund\w*|2|tercer\w*|3|tres|cuart\w*|4|cuatro)\b""").find(d)
            if (m != null) {
                val t = m.value
                val opt = when {
                    t.startsWith("primer") || t == "1" || t == "uno" -> 1
                    t.startsWith("segund") || t == "2" -> 2
                    t.startsWith("tercer") || t == "3" || t == "tres" -> 3
                    else -> 4
                }
                if (opt <= ctx.choiceCount) return res("", "choose_contact").put("option", opt)
            }
        }

        // --- manos libres ---
        if (n.contains("manos libres")) {
            if (Regex("""desactiv|apag|paus|deshabilit|saca""").containsMatchIn(n))
                return res("Manos libres desactivado.", "handsfree").put("on", false)
            if (Regex("""activ|prend|habilit|encend""").containsMatchIn(n))
                return res("Manos libres activado.", "handsfree").put("on", true)
        }

        // --- cerrar app, sistema ---
        if (Regex("""\bcerr\w*\s+(esta\s+|la\s+)?(app|aplicacion)\b|\bcerr\w*\s+esto\b""").containsMatchIn(n))
            return res("Cerrando.", "close_app")
        if (Regex("""\b(captura|pantallazo|screenshot)\b""").containsMatchIn(n))
            return res("Capturando.", "system").put("which", "screenshot")
        if (Regex("""\bbloque\w*\s+(el\s+|la\s+)?(telefono|celular|pantalla)\b|\bapag\w*\s+la\s+pantalla\b""").containsMatchIn(n))
            return res("", "system").put("which", "lock")
        if (Regex("""\b(anda|volve|ir|vamos|volver)\s+(a\s+|al\s+)?(inicio|pantalla\s+de\s+inicio|home)\b""").containsMatchIn(n))
            return res("", "system").put("which", "home")
        if (Regex("""\bvolve\w*\s+(para\s+)?atras\b""").containsMatchIn(n))
            return res("", "system").put("which", "back")

        // --- notificaciones, mensajes, audios ---
        if (Regex("""\b(lee|leer|leeme|decime|dime|cuales|que)\w*\b.*\bnotificacion""").containsMatchIn(n))
            return res("", "read_notifications")
        if (Regex("""\babr\w*\s+(el\s+)?(panel|las\s+notificaciones)""").containsMatchIn(n))
            return res("", "system").put("which", "notifications")
        if (Regex("""\b(reproduc\w*|escucha\w*|pone\w*|pasa\w*)\s+(el\s+|la\s+)?(audio|nota\s+de\s+voz|mensaje\s+de\s+voz)\b""").containsMatchIn(n))
            return res("", "play_voice_note")
        Regex("""\b(lee|leer|leeme|decime|dime|contame)\w*\s+(los\s+|mis\s+)?(ultimos\s+|nuevos\s+)?mensajes(?:\s+de\s+(.+))?$""").find(n)?.let {
            return res("", "read_messages").put("contact", grp(it, 4))
        }
        if (Regex("""\b(aprend|actualiz|escanea)\w*\s+(mis\s+|todos\s+mis\s+|los\s+)?chats\b""").containsMatchIn(n))
            return res("", "scan_chats")

        // --- linterna, no molestar, cámara ---
        if (Regex("""\b(linterna|flash)\b""").containsMatchIn(n)) {
            val off = Regex("""apag|desactiv|saca|quita""").containsMatchIn(n)
            return res(if (off) "Linterna apagada." else "Linterna encendida.", "flashlight").put("on", !off)
        }
        if (n.contains("no molestar")) {
            val off = Regex("""desactiv|apag|saca|quita""").containsMatchIn(n)
            return res("", "dnd").put("on", !off)
        }
        if (Regex("""\bcamara\b""").containsMatchIn(n) && Regex("""abr|prend|activ|saca|toma|hace""").containsMatchIn(n))
            return res("", "camera")
        if (Regex("""\b(saca\w*|toma\w*|hace\w*)\s+(una\s+)?foto\b""").containsMatchIn(n))
            return res("", "camera")

        // --- alarmas ---
        if (Regex("""\b(borra|elimina|cancela|saca|quita|apaga|desactiva)\w*\s+(la\s+|mi\s+)?(proxima\s+|siguiente\s+)?alarma\b""").containsMatchIn(n))
            return res("Alarma borrada.", "alarm_off")

        // --- recordatorios ---
        val remVerb = Regex("""^(recorda|recuerda|avisa)\w*""")
        val remIdx = dTokens.indexOfFirst { remVerb.containsMatchIn(it) && !it.startsWith("recordatorio") }
        if (remIdx >= 0 && !Regex("""^(acordate|acuerdate)""").containsMatchIn(n)) {
            val clock = parseClock(d)
            val dur = durationSeconds(d)
            if (clock != null || dur != null) {
                val start = Calendar.getInstance()
                val phrase: IntRange
                if (dur != null && (clock == null || dur.second.first < clock.third.first)) {
                    start.add(Calendar.SECOND, dur.first)
                    phrase = dur.second
                } else {
                    val (h, m, r) = clock!!
                    start.set(Calendar.HOUR_OF_DAY, h)
                    start.set(Calendar.MINUTE, m)
                    start.set(Calendar.SECOND, 0)
                    if (start.timeInMillis <= System.currentTimeMillis()) start.add(Calendar.DAY_OF_YEAR, 1)
                    phrase = r
                }
                val a = d.substring(0, phrase.first).count { it == ' ' }
                val b = a + d.substring(phrase.first, phrase.last + 1).count { it == ' ' } + 1
                val keep = rt.filterIndexed { i, _ -> i != remIdx && (i < a || i >= b) }
                var txt = keep.joinToString(" ")
                txt = txt.replace(Regex("""^(?i)(que|de|para|a|de que)\s+"""), "").trim()
                if (txt.isEmpty()) txt = "Recordatorio"
                val iso = SimpleDateFormat("yyyy-MM-dd'T'HH:mm", Locale.US).format(start.time)
                val hh = SimpleDateFormat("HH:mm", Locale.US).format(start.time)
                return res("Listo, te aviso a las $hh.", "reminder").put("text", txt).put("start", iso)
            }
        }

        // --- alarma / temporizador ---
        val wantsAlarm = Regex("""\balarma\b|\bdespert\w*""").containsMatchIn(n)
        val wantsTimer = Regex("""\b(timer|temporizador|cronometro|cuenta\s+regresiva)\b""").containsMatchIn(n)
        if (wantsTimer) {
            val dur = durationSeconds(d) ?: return null
            return res("Temporizador listo.", "timer").put("seconds", dur.first).put("label", "Jarvis")
        }
        if (wantsAlarm) {
            val clock = parseClock(d)
            if (clock != null) {
                val hh = String.format(Locale.US, "%02d:%02d", clock.first, clock.second)
                return res("Alarma a las $hh.", "alarm").put("hour", clock.first).put("minute", clock.second).put("label", "Jarvis")
            }
            val dur = durationSeconds(d)
            if (dur != null) {
                if (dur.first < 60) return res("Temporizador listo.", "timer").put("seconds", dur.first).put("label", "Jarvis")
                val c = Calendar.getInstance()
                c.add(Calendar.SECOND, dur.first)
                val hh = String.format(Locale.US, "%02d:%02d", c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE))
                return res("Alarma a las $hh.", "alarm")
                    .put("hour", c.get(Calendar.HOUR_OF_DAY)).put("minute", c.get(Calendar.MINUTE)).put("label", "Jarvis")
            }
            return null
        }

        // --- volumen y brillo ---
        if (n.contains("volumen") || Regex("""\b(silencia|mutea)\w*\b""").containsMatchIn(n)) {
            Regex("""volumen\s+(?:al|a|en)\s+(\d+)""").find(d)?.let {
                return res("", "volume").put("mode", "level").put("percent", it.groupValues[1].toInt().coerceIn(0, 100))
            }
            if (Regex("""maximo|a\s+fondo""").containsMatchIn(n)) return res("", "volume").put("mode", "max")
            if (Regex("""desmutea|quita\w*\s+el\s+silencio|activa\w*\s+(el\s+)?sonido""").containsMatchIn(n))
                return res("", "volume").put("mode", "unmute")
            if (Regex("""silencia|mutea|sin\s+sonido""").containsMatchIn(n)) return res("", "volume").put("mode", "mute")
            if (Regex("""\bsub\w*|aument\w*|alza\w*|mas\s+fuerte|mas\s+alto""").containsMatchIn(n)) return res("", "volume").put("mode", "up")
            if (Regex("""\bbaj\w*|disminuy\w*|mas\s+bajo|menos""").containsMatchIn(n)) return res("", "volume").put("mode", "down")
        }
        if (n.contains("brillo")) {
            Regex("""brillo\s+(?:al|a|en)\s+(\d+)""").find(d)?.let {
                val p = it.groupValues[1].toInt().coerceIn(1, 100)
                return res("Brillo al $p por ciento.", "brightness").put("percent", p)
            }
            if (Regex("""maximo""").containsMatchIn(n)) return res("", "brightness").put("percent", 100)
            if (Regex("""minimo""").containsMatchIn(n)) return res("", "brightness").put("percent", 5)
            if (Regex("""medio""").containsMatchIn(n)) return res("", "brightness").put("percent", 50)
            if (Regex("""\bsub\w*|aument\w*|mas\s+brillo""").containsMatchIn(n)) return res("", "brightness").put("percent", 80)
            if (Regex("""\bbaj\w*|disminuy\w*|menos\s+brillo""").containsMatchIn(n)) return res("", "brightness").put("percent", 30)
        }

        // --- listas ---
        Regex("""^(?:saca\w*|borra\w*|quita\w*|elimina\w*)\s+(.+?)\s+de\s+(?:la\s+|mi\s+)?lista(?:\s+de(?:l)?\s+(.+))?$""").find(n)?.let {
            val items = grp(it, 1).split(Regex("""\s+y\s+|\s+e\s+""")).map { s -> s.trim() }.filter { s -> s.isNotEmpty() }
            val list = grp(it, 2).ifEmpty { "compras" }
            return res("", "list_remove").put("list", list).put("items", JSONArray(items))
        }
        Regex("""^(?:vacia\w*|borra\w*|limpia\w*|elimina\w*)\s+(?:la\s+|mi\s+|toda\s+la\s+)?lista(?:\s+de(?:l)?\s+(.+))?$""").find(n)?.let {
            return res("", "list_remove").put("list", grp(it, 1).ifEmpty { "compras" })
        }
        Regex("""^(?:agrega\w*|anota\w*|suma\w*|pone\w*|mete\w*|anade\w*)\s+(.+?)\s+(?:a|en)\s+(?:la\s+|mi\s+)?lista(?:\s+de(?:l)?\s+(.+))?$""").find(n)?.let {
            val items = grp(it, 1).split(Regex("""\s+y\s+|\s+e\s+""")).map { s -> s.trim() }.filter { s -> s.isNotEmpty() }
            if (items.isNotEmpty()) {
                val list = grp(it, 2).ifEmpty { "compras" }
                return res("Agregado.", "list_add").put("list", list).put("items", JSONArray(items))
            }
        }
        Regex("""^(?:lee\w*|decime|dime|mostra\w*|cual\s+es|que\s+hay\s+en)\s+(?:la\s+|mi\s+)?lista(?:\s+de(?:l)?\s+(.+))?$""").find(n)?.let {
            return res("", "list_read").put("list", grp(it, 1).ifEmpty { "compras" })
        }

        // --- memoria ---
        Regex("""^(?:acordate|acuerdate|recorda|recuerda|guarda|anota)\s+(?:de\s+)?que\s+(.+)$""").find(n)?.let {
            return res("Anotado.", "remember").put("text", grp(it, 1))
        }
        Regex("""^(?:olvidate|olvida)\s+(?:de\s+)?(.+)$""").find(n)?.let {
            return res("", "forget").put("text", grp(it, 1))
        }

        // --- hora, fecha, batería ---
        if (Regex("""\bque\s+hora\s+es\b|\bhora\s+actual\b|\bdecime\s+la\s+hora\b""").containsMatchIn(n)) {
            val t = SimpleDateFormat("HH:mm", Locale.US).format(Date())
            return res("Son las $t.", "none")
        }
        if (Regex("""\bque\s+dia\s+es\b|\bque\s+fecha\b|\bfecha\s+de\s+hoy\b""").containsMatchIn(n)) {
            val t = SimpleDateFormat("EEEE d 'de' MMMM", Locale("es", "AR")).format(Date())
            return res("Hoy es $t.", "none")
        }
        if (n.contains("bateria") && Regex("""cuanta|nivel|porcentaje|que\s+tanto|como\s+(esta|anda)""").containsMatchIn(n)) {
            return res("Tenés ${ctx.batteryPct} por ciento de batería${if (ctx.charging) ", cargando" else ""}.", "none")
        }

        // --- llamar y escribir ---
        Regex("""^(?:escribi\w*|mandale|mandar|manda|enviale|envia\w*|decile|dile)\s+(?:un\s+)?(?:mensaje\s+|whatsapp\s+|wasap\s+)?(?:a\s+|al\s+|para\s+)?(.+?)\s+(?:diciendo|que\s+diga|que\s+dice|que\s+ponga|que\s+le\s+diga|que)\s+(.+)$""").find(n)?.let {
            val contact = grp(it, 1)
            val msg = grp(it, 2)
            if (contact.isNotEmpty() && msg.isNotEmpty()) return res("", "send_whatsapp").put("contact", contact).put("text", msg)
        }
        Regex("""^(?:llama|llamar|llamale|marca)\s+(?:a\s+|al\s+|a\s+la\s+)?(.+)$""").find(n)?.let {
            val c = grp(it, 1)
            if (c.isNotEmpty()) return res("", "call").put("contact", c)
        }

        // --- música y apps ---
        Regex("""^(?:pone\w*|reproduc\w*|pasa\w*|escuchar|quiero\s+escuchar)\s+(?:musica\s+de\s+|musica\s+|la\s+cancion\s+|el\s+tema\s+|un\s+tema\s+de\s+|un\s+tema\s+|algo\s+de\s+)(.+)$""").find(n)?.let {
            return res("", "play_music").put("query", grp(it, 1))
        }
        Regex("""^(?:busca\w*|buscame)\s+(.+?)\s+en\s+(youtube|spotify|maps|google\s+maps|mapas)$""").find(n)?.let {
            val app = when (it.groupValues[2]) {
                "youtube" -> "YouTube"
                "spotify" -> "Spotify"
                else -> "Maps"
            }
            return res("", "open_app").put("app", app).put("query", grp(it, 1))
        }
        Regex("""^(?:abr\w*|lanz\w*|inici\w*|ejecut\w*)\s+(?:(?:la|el)\s+)?(?:(?:app|aplicacion)\s+)?(?:de\s+)?(.+)$""").find(n)?.let {
            val app = grp(it, 1)
            if (app.isNotEmpty() && app.split(" ").size <= 3) return res("", "open_app").put("app", app)
        }

        return null
    }
}
