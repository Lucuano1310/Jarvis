package com.jarvis.app

import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import android.os.Environment
import java.io.File
import java.io.FileOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

/** Crea PDF y Word (.docx) simples, y lee texto de un .docx. */
object Docs {
    fun outDir(): File {
        val d = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS), "Jarvis")
        d.mkdirs()
        return d
    }

    fun safeName(title: String): String {
        val s = title.trim().take(40).replace(Regex("[^A-Za-z0-9áéíóúñÁÉÍÓÚÑ _-]"), "").trim().replace(' ', '_')
        return if (s.isBlank()) "documento" else s
    }

    fun createPdf(title: String, body: String, out: File) {
        val doc = PdfDocument()
        var pageNo = 1
        var page = doc.startPage(PdfDocument.PageInfo.Builder(595, 842, pageNo).create())
        var canvas = page.canvas
        val titlePaint = Paint().apply {
            textSize = 20f
            isFakeBoldText = true
        }
        val p = Paint().apply { textSize = 12f }
        var y = 60f
        canvas.drawText(title.take(60), 50f, y, titlePaint)
        y += 34f
        for (para in body.split("\n")) {
            var line = ""
            for (w in para.split(" ")) {
                val test = if (line.isEmpty()) w else "$line $w"
                if (p.measureText(test) > 495f) {
                    canvas.drawText(line, 50f, y, p)
                    y += 18f
                    line = w
                    if (y > 790f) {
                        doc.finishPage(page)
                        pageNo++
                        page = doc.startPage(PdfDocument.PageInfo.Builder(595, 842, pageNo).create())
                        canvas = page.canvas
                        y = 60f
                    }
                } else {
                    line = test
                }
            }
            canvas.drawText(line, 50f, y, p)
            y += 24f
            if (y > 790f) {
                doc.finishPage(page)
                pageNo++
                page = doc.startPage(PdfDocument.PageInfo.Builder(595, 842, pageNo).create())
                canvas = page.canvas
                y = 60f
            }
        }
        doc.finishPage(page)
        FileOutputStream(out).use { doc.writeTo(it) }
        doc.close()
    }

    private fun esc(s: String): String = s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")

    fun createDocx(title: String, body: String, out: File) {
        ZipOutputStream(FileOutputStream(out)).use { z ->
            fun put(name: String, content: String) {
                z.putNextEntry(ZipEntry(name))
                z.write(content.toByteArray(Charsets.UTF_8))
                z.closeEntry()
            }
            put(
                "[Content_Types].xml",
                "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
                    "<Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\">" +
                    "<Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/>" +
                    "<Default Extension=\"xml\" ContentType=\"application/xml\"/>" +
                    "<Override PartName=\"/word/document.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml\"/>" +
                    "</Types>"
            )
            put(
                "_rels/.rels",
                "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
                    "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">" +
                    "<Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"word/document.xml\"/>" +
                    "</Relationships>"
            )
            val sb = StringBuilder()
            sb.append("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>")
            sb.append("<w:document xmlns:w=\"http://schemas.openxmlformats.org/wordprocessingml/2006/main\"><w:body>")
            sb.append("<w:p><w:r><w:rPr><w:b/><w:sz w:val=\"32\"/></w:rPr><w:t xml:space=\"preserve\">").append(esc(title)).append("</w:t></w:r></w:p>")
            for (para in body.split("\n")) {
                sb.append("<w:p><w:r><w:t xml:space=\"preserve\">").append(esc(para)).append("</w:t></w:r></w:p>")
            }
            sb.append("</w:body></w:document>")
            put("word/document.xml", sb.toString())
        }
    }

    fun readDocx(file: File): String {
        ZipInputStream(file.inputStream()).use { z ->
            var e = z.nextEntry
            while (e != null) {
                if (e.name == "word/document.xml") {
                    val xml = z.readBytes().toString(Charsets.UTF_8)
                    return xml.replace("</w:p>", "\n").replace(Regex("<[^>]+>"), "")
                        .replace("&amp;", "&").replace("&lt;", "<").replace("&gt;", ">").trim()
                }
                e = z.nextEntry
            }
        }
        return ""
    }
}
