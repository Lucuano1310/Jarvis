package com.jarvis.app

import java.text.Normalizer
import java.util.Locale

/** Palabras y frases para practicar inglés. Varias respuestas válidas se separan con "/". */
object English {
    val WORDS: List<Pair<String, String>> = listOf(
        "hello" to "hola", "goodbye" to "adios/chau", "please" to "por favor", "thank you" to "gracias",
        "sorry" to "perdon/lo siento", "yes" to "si", "no" to "no", "water" to "agua", "bread" to "pan",
        "milk" to "leche", "coffee" to "cafe", "apple" to "manzana", "orange" to "naranja", "banana" to "banana/platano",
        "house" to "casa", "car" to "auto/coche", "dog" to "perro", "cat" to "gato", "book" to "libro",
        "phone" to "telefono/celular", "friend" to "amigo/amiga", "family" to "familia", "mother" to "madre/mama",
        "father" to "padre/papa", "brother" to "hermano", "sister" to "hermana", "school" to "escuela/colegio",
        "teacher" to "maestro/profesor/docente", "student" to "estudiante/alumno", "work" to "trabajo/trabajar",
        "time" to "tiempo/hora", "day" to "dia", "night" to "noche", "morning" to "manana", "today" to "hoy",
        "tomorrow" to "manana", "yesterday" to "ayer", "week" to "semana", "month" to "mes", "year" to "ano",
        "one" to "uno", "two" to "dos", "three" to "tres", "four" to "cuatro", "five" to "cinco", "six" to "seis",
        "seven" to "siete", "eight" to "ocho", "nine" to "nueve", "ten" to "diez", "red" to "rojo", "blue" to "azul",
        "green" to "verde", "yellow" to "amarillo", "black" to "negro", "white" to "blanco", "big" to "grande",
        "small" to "pequeno/chico", "good" to "bueno/bien", "bad" to "malo/mal", "happy" to "feliz/contento",
        "sad" to "triste", "hot" to "caliente/calor", "cold" to "frio", "eat" to "comer", "drink" to "beber/tomar",
        "sleep" to "dormir", "walk" to "caminar", "run" to "correr", "read" to "leer", "write" to "escribir",
        "speak" to "hablar", "listen" to "escuchar", "open" to "abrir", "close" to "cerrar", "buy" to "comprar",
        "love" to "amor/amar/querer", "food" to "comida", "city" to "ciudad", "street" to "calle",
        "money" to "dinero/plata", "How are you?" to "como estas", "What is your name?" to "como te llamas/cual es tu nombre",
        "I am fine" to "estoy bien", "Where is the bathroom?" to "donde esta el bano", "How much is it?" to "cuanto cuesta/cuanto sale",
        "I don't understand" to "no entiendo", "Good morning" to "buen dia/buenos dias", "Good night" to "buenas noches",
        "See you later" to "hasta luego/nos vemos"
    )

    private fun norm(t: String): String =
        Normalizer.normalize(t, Normalizer.Form.NFD)
            .replace(Regex("\\p{InCombiningDiacriticalMarks}+"), "")
            .lowercase(Locale.ROOT)
            .replace(Regex("[^a-z0-9 ]"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()

    fun spanishShown(es: String): String = es.split("/").first()

    fun check(answer: String, es: String): Boolean {
        val a = norm(answer)
        if (a.isEmpty()) return false
        for (opt in es.split("/")) {
            val o = norm(opt)
            if (o.isEmpty()) continue
            if (a == o || a.contains(o) || (a.length >= 3 && o.contains(a))) return true
        }
        return false
    }
}
