package com.jarvis.app

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import java.io.File

/** Aparece en el menú "Compartir" de Android: recibe fotos, PDF, Word y textos para que Jarvis los procese. */
class ShareActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val svc = OverlayService.instance
        if (svc == null) {
            Toast.makeText(this, "Primero abrí Jarvis y tocá Guardar clave y activar.", Toast.LENGTH_LONG).show()
            finish()
            return
        }
        val type = intent.type ?: ""
        val text = intent.getStringExtra(Intent.EXTRA_TEXT)
        val uri: Uri? = if (Build.VERSION.SDK_INT >= 33) {
            intent.getParcelableExtra(Intent.EXTRA_STREAM, Uri::class.java)
        } else {
            @Suppress("DEPRECATION")
            intent.getParcelableExtra(Intent.EXTRA_STREAM)
        }
        var path: String? = null
        if (uri != null) path = copyToCache(uri, type)
        if (path == null && text.isNullOrBlank()) {
            Toast.makeText(this, "No pude leer lo que compartiste.", Toast.LENGTH_LONG).show()
            finish()
            return
        }
        val isImage = type.startsWith("image/")
        val labels = ArrayList<String>()
        val modes = ArrayList<String>()
        labels.add("Leer el texto en voz alta (sin internet)"); modes.add("read")
        if (isImage) {
            labels.add("Describir la imagen (con internet)"); modes.add("describe")
        }
        labels.add("Traducir al inglés (sin internet)"); modes.add("to_en")
        labels.add("Traducir al español (sin internet)"); modes.add("to_es")
        labels.add("Explicar o resumir (con internet)"); modes.add("summarize")
        labels.add("Guardar el texto como PDF"); modes.add("pdf")
        labels.add("Guardar el texto como Word"); modes.add("word")
        AlertDialog.Builder(this)
            .setTitle("Jarvis: ¿qué hago con esto?")
            .setItems(labels.toTypedArray()) { _, i ->
                svc.processShare(path, type, text, modes[i])
                finish()
            }
            .setOnCancelListener { finish() }
            .show()
    }

    private fun copyToCache(uri: Uri, type: String): String? {
        return try {
            val ext = when {
                type.startsWith("image/") -> "jpg"
                type == "application/pdf" -> "pdf"
                type.contains("wordprocessingml") -> "docx"
                else -> "txt"
            }
            val f = File(cacheDir, "share_${System.currentTimeMillis()}.$ext")
            contentResolver.openInputStream(uri)?.use { input ->
                f.outputStream().use { out ->
                    var total = 0L
                    val buf = ByteArray(16384)
                    while (true) {
                        val n = input.read(buf)
                        if (n < 0) break
                        total += n
                        if (total > 25L * 1024 * 1024) break
                        out.write(buf, 0, n)
                    }
                }
            } ?: return null
            f.absolutePath
        } catch (e: Exception) {
            null
        }
    }
}
