package com.jarvis.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.Calendar
import java.util.Locale

/** Gastos e ingresos anotados por voz. Todo queda guardado en el teléfono y anda sin internet. */
object Finance {
    private fun prefs(ctx: Context) = ctx.getSharedPreferences("jarvis_money", Context.MODE_PRIVATE)

    private fun load(ctx: Context): JSONArray = try {
        JSONArray(prefs(ctx).getString("items", "[]") ?: "[]")
    } catch (e: Exception) {
        JSONArray()
    }

    private fun save(ctx: Context, a: JSONArray) {
        prefs(ctx).edit().putString("items", a.toString()).apply()
    }

    fun fmt(a: Double): String = String.format(Locale("es", "AR"), "%,.0f", a)

    fun add(ctx: Context, amount: Double, category: String, note: String, income: Boolean): String {
        val a = load(ctx)
        a.put(
            JSONObject().put("t", System.currentTimeMillis()).put("a", amount)
                .put("c", category.lowercase(Locale.ROOT).trim()).put("n", note).put("i", if (income) 1 else 0)
        )
        save(ctx, a)
        val what = if (income) "ingreso" else "gasto"
        val cat = if (category.isNotBlank()) " en ${category.trim()}" else ""
        return "Anotado el $what de ${fmt(amount)} pesos$cat."
    }

    private fun range(period: String): Pair<Long, Long> {
        val c = Calendar.getInstance()
        c.set(Calendar.HOUR_OF_DAY, 0)
        c.set(Calendar.MINUTE, 0)
        c.set(Calendar.SECOND, 0)
        c.set(Calendar.MILLISECOND, 0)
        val now = System.currentTimeMillis()
        return when (period) {
            "week" -> {
                val diff = (c.get(Calendar.DAY_OF_WEEK) + 5) % 7
                c.add(Calendar.DAY_OF_YEAR, -diff)
                Pair(c.timeInMillis, now)
            }
            "month" -> {
                c.set(Calendar.DAY_OF_MONTH, 1)
                Pair(c.timeInMillis, now)
            }
            "lastmonth" -> {
                c.set(Calendar.DAY_OF_MONTH, 1)
                val end = c.timeInMillis
                c.add(Calendar.MONTH, -1)
                Pair(c.timeInMillis, end)
            }
            else -> Pair(c.timeInMillis, now)
        }
    }

    private fun label(period: String): String = when (period) {
        "week" -> "Esta semana"
        "month" -> "Este mes"
        "lastmonth" -> "El mes pasado"
        else -> "Hoy"
    }

    fun total(ctx: Context, period: String, category: String?): String {
        val (s, e) = range(period)
        val a = load(ctx)
        var spent = 0.0
        var inc = 0.0
        val cat = category?.lowercase(Locale.ROOT)?.trim() ?: ""
        for (i in 0 until a.length()) {
            val o = a.getJSONObject(i)
            val t = o.optLong("t")
            if (t < s || t >= e) continue
            if (cat.isNotEmpty() && !o.optString("c").contains(cat)) continue
            if (o.optInt("i") == 1) inc += o.optDouble("a") else spent += o.optDouble("a")
        }
        val sb = StringBuilder("${label(period)} gastaste ${fmt(spent)} pesos")
        if (cat.isNotEmpty()) sb.append(" en $cat")
        sb.append(".")
        if (inc > 0 && cat.isEmpty()) sb.append(" Tus ingresos fueron ${fmt(inc)}.")
        val budget = prefs(ctx).getFloat("budget", 0f).toDouble()
        if (period == "month" && budget > 0 && cat.isEmpty()) {
            sb.append(
                if (budget >= spent) " Te quedan ${fmt(budget - spent)} del presupuesto."
                else " Te pasaste ${fmt(spent - budget)} del presupuesto."
            )
        }
        return sb.toString()
    }

    fun top(ctx: Context, period: String): String {
        val (s, e) = range(period)
        val a = load(ctx)
        val map = HashMap<String, Double>()
        for (i in 0 until a.length()) {
            val o = a.getJSONObject(i)
            val t = o.optLong("t")
            if (t < s || t >= e || o.optInt("i") == 1) continue
            val c = o.optString("c").ifBlank { "sin categoría" }
            map[c] = (map[c] ?: 0.0) + o.optDouble("a")
        }
        if (map.isEmpty()) return "${label(period)} no tenés gastos anotados."
        val best = map.entries.sortedByDescending { it.value }.take(3)
        return "${label(period)} gastaste más en: " + best.joinToString(", ") { "${it.key}, ${fmt(it.value)} pesos" } + "."
    }

    fun undo(ctx: Context): String {
        val a = load(ctx)
        if (a.length() == 0) return "No tenés gastos anotados."
        val keep = JSONArray()
        for (i in 0 until a.length() - 1) keep.put(a.getJSONObject(i))
        save(ctx, keep)
        return "Listo, borré el último movimiento."
    }

    fun setBudget(ctx: Context, amount: Double): String {
        prefs(ctx).edit().putFloat("budget", amount.toFloat()).apply()
        return "Listo, tu presupuesto del mes es de ${fmt(amount)} pesos."
    }

    /** Resumen corto para que la IA aconseje con tus números reales. Vacío si no hay datos. */
    fun summaryForPrompt(ctx: Context): String {
        val a = load(ctx)
        if (a.length() == 0) return ""
        val (s, e) = range("month")
        var spent = 0.0
        for (i in 0 until a.length()) {
            val o = a.getJSONObject(i)
            val t = o.optLong("t")
            if (t >= s && t < e && o.optInt("i") == 0) spent += o.optDouble("a")
        }
        val budget = prefs(ctx).getFloat("budget", 0f).toDouble()
        return "Finanzas del usuario: gastó ${fmt(spent)} pesos este mes" +
            (if (budget > 0) " y su presupuesto es ${fmt(budget)}" else "") + ".\n"
    }
}
