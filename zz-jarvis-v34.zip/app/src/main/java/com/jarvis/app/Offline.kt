package com.jarvis.app

import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.pdf.PdfRenderer
import android.os.ParcelFileDescriptor
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.TranslatorOptions
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.io.File

/** Traducción y lectura de texto en imágenes que funcionan sin internet (modelos de Google ML Kit). */
object Offline {

    fun lang(code: String): String = if (code == "en") TranslateLanguage.ENGLISH else TranslateLanguage.SPANISH

    /** cb(resultado, error). Si el modelo no está descargado, lo baja una vez (necesita internet). */
    fun translate(text: String, from: String, to: String, cb: (String?, String?) -> Unit) {
        val opts = TranslatorOptions.Builder()
            .setSourceLanguage(lang(from))
            .setTargetLanguage(lang(to))
            .build()
        val tr = Translation.getClient(opts)
        tr.downloadModelIfNeeded(DownloadConditions.Builder().build())
            .addOnSuccessListener {
                tr.translate(text)
                    .addOnSuccessListener { out -> cb(out, null) }
                    .addOnFailureListener { e -> cb(null, e.message ?: "falló la traducción") }
            }
            .addOnFailureListener { e -> cb(null, "descarga: " + (e.message ?: "sin conexión")) }
    }

    /** Descarga los dos modelos (español e inglés) para traducir sin internet. */
    fun downloadModels(cb: (Boolean) -> Unit) {
        translate("hola", "es", "en") { r1, _ ->
            if (r1 == null) {
                cb(false)
            } else {
                translate("hello", "en", "es") { r2, _ -> cb(r2 != null) }
            }
        }
    }

    fun ocr(bmp: Bitmap, cb: (String?) -> Unit) {
        val rec = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
        rec.process(InputImage.fromBitmap(bmp, 0))
            .addOnSuccessListener { t -> cb(t.text) }
            .addOnFailureListener { cb(null) }
    }

    /** Pasa a imagen las primeras páginas de un PDF y lee el texto de cada una. */
    fun pdfToText(file: File, maxPages: Int, cb: (String?) -> Unit) {
        try {
            val pfd = ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY)
            val renderer = PdfRenderer(pfd)
            val total = minOf(renderer.pageCount, maxPages)
            val sb = StringBuilder()
            fun next(i: Int) {
                if (i >= total) {
                    renderer.close()
                    pfd.close()
                    cb(sb.toString().trim())
                    return
                }
                val page = renderer.openPage(i)
                val bmp = Bitmap.createBitmap(page.width * 2, page.height * 2, Bitmap.Config.ARGB_8888)
                bmp.eraseColor(Color.WHITE)
                page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                page.close()
                ocr(bmp) { t ->
                    if (t != null) sb.append(t).append("\n")
                    next(i + 1)
                }
            }
            next(0)
        } catch (e: Exception) {
            cb(null)
        }
    }
}
