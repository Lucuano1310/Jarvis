package com.jarvis.app

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

class JarvisNotificationListener : NotificationListenerService() {

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        val n = sbn.notification ?: return
        if (n.flags and Notification.FLAG_GROUP_SUMMARY != 0) return
        if (n.flags and Notification.FLAG_ONGOING_EVENT != 0) return
        val pkg = sbn.packageName
        if (pkg == packageName) return

        val extras = n.extras ?: return
        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: return
        val text = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString() ?: return

        val isWhatsApp = pkg == "com.whatsapp" || pkg == "com.whatsapp.w4b"
        if (isWhatsApp && title == "WhatsApp") return

        val app = if (isWhatsApp) "WhatsApp" else pkg.substringAfterLast('.')
        if (isWhatsApp) {
            ReplyStore.save(title, n)
            val chat = title.replace(Regex("\\s*\\(\\d+\\s+(mensajes?|messages?)\\)\\s*$"), "").trim()
            if (chat.isNotEmpty()) getSharedPreferences("jarvis_chats", MODE_PRIVATE).edit().putString(chat, "1").apply()
            val digits = numberOf(sbn, title)
            if (digits != null) {
                getSharedPreferences("jarvis_numbers", MODE_PRIVATE).edit().putString(title, digits).apply()
            }
        }
        val added = NotifStore.add(this, NotifStore.Item(app, title, text, System.currentTimeMillis()))
        val lower = text.lowercase()
        val isVoice = lower.contains("mensaje de voz") || lower.contains("voice message") ||
            text.startsWith("\uD83C\uDFA4")
        if (isWhatsApp && added) OverlayService.instance?.announce(title, isVoice)
    }

    /** Intenta sacar el número del chat individual (para poder llamar o escribir aunque no esté en la agenda). */
    private fun numberOf(sbn: StatusBarNotification, title: String): String? {
        val sc = sbn.notification?.shortcutId
        if (sc != null && sc.endsWith("@s.whatsapp.net")) {
            val d = sc.substringBefore('@').filter { it.isDigit() }
            if (d.length >= 8) return d
        }
        val t = title.filter { it.isDigit() }
        if (title.trim().startsWith("+") && t.length >= 8) return t
        return null
    }
}
