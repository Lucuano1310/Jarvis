package com.jarvis.app

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class SendAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile var armedUntil = 0L
        @Volatile var running = false
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        running = true
    }

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        running = false
        return super.onUnbind(intent)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (System.currentTimeMillis() > armedUntil) return
        val root = rootInActiveWindow ?: return
        val node = findSend(root) ?: return
        if (node.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
            armedUntil = 0L
        }
    }

    override fun onInterrupt() {}

    private fun findSend(root: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        for (id in listOf("com.whatsapp:id/send", "com.whatsapp.w4b:id/send")) {
            val n = root.findAccessibilityNodeInfosByViewId(id).firstOrNull()
            if (n != null) return n
        }
        for (label in listOf("Enviar", "Send")) {
            val n = root.findAccessibilityNodeInfosByText(label).firstOrNull { it.isClickable }
            if (n != null) return n
        }
        return null
    }
}
