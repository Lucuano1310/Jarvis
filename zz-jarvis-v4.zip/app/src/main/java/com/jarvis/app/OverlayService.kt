package com.jarvis.app

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.net.Uri
import android.provider.AlarmClock
import android.provider.CalendarContract
import android.provider.ContactsContract
import android.provider.Settings
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.TextView
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.concurrent.thread
import kotlin.math.abs

class OverlayService : Service(), TextToSpeech.OnInitListener {

    companion object {
        // Modelo de Gemini. Si da error, cambiá este nombre por el que te muestre AI Studio.
        const val MODEL = "gemini-4-hydrogen"
        const val COLOR_IDLE = "#E6007AFF"
        const val COLOR_LISTENING = "#E6FF3B30"
        const val COLOR_THINKING = "#E6FF9500"
    }

    private lateinit var wm: WindowManager
    private var bubble: TextView? = null
    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private val main = Handler(Looper.getMainLooper())

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        startAsForeground()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        tts = TextToSpeech(this, this)
        addBubble()
    }

    override fun onInit(status: Int) {
        tts?.language = Locale("es")
    }

    private fun startAsForeground() {
        val channelId = "jarvis"
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(channelId, "Jarvis", NotificationManager.IMPORTANCE_MIN)
        )
        val n = Notification.Builder(this, channelId)
            .setContentTitle("Jarvis activo")
            .setContentText("Tocá la burbuja para hablar. Mantenela apretada para pausar.")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } else {
            startForeground(1, n)
        }
    }

    private fun setBubble(letter: String, color: String) {
        bubble?.text = letter
        (bubble?.background as? GradientDrawable)?.setColor(Color.parseColor(color))
    }

    private fun addBubble() {
        val size = (56 * resources.displayMetrics.density).toInt()
        val tv = TextView(this).apply {
            text = "J"
            textSize = 22f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.parseColor(COLOR_IDLE))
            }
        }
        val lp = WindowManager.LayoutParams(
            size, size,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.END
            x = 16
            y = 300
        }

        var startX = 0
        var startY = 0
        var touchX = 0f
        var touchY = 0f
        var moved = false

        tv.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = lp.x; startY = lp.y
                    touchX = e.rawX; touchY = e.rawY
                    moved = false
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - touchX).toInt()
                    val dy = (e.rawY - touchY).toInt()
                    if (abs(dx) > 10 || abs(dy) > 10) moved = true
                    if (moved) {
                        lp.x = startX - dx
                        lp.y = startY + dy
                        wm.updateViewLayout(tv, lp)
                    }
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) {
                        if (e.eventTime - e.downTime > 800) stopSelf() else listen()
                    }
                }
            }
            true
        }
        bubble = tv
        wm.addView(tv, lp)
    }

    private fun say(text: String) {
        setBubble("J", COLOR_IDLE)
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis")
    }

    private fun listen() {
        tts?.stop()
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            say("Falta el permiso del micrófono.")
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            say("Este teléfono no tiene reconocimiento de voz.")
            return
        }
        recognizer?.destroy()
        setBubble("●", COLOR_LISTENING)
        recognizer = SpeechRecognizer.createSpeechRecognizer(this).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onPartialResults(partialResults: Bundle?) {}
                override fun onEvent(eventType: Int, params: Bundle?) {}
                override fun onError(error: Int) {
                    say("No te escuché, probá de nuevo.")
                }
                override fun onResults(results: Bundle?) {
                    val text = results
                        ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        ?.firstOrNull()
                    if (text.isNullOrBlank()) say("No te escuché.") else ask(text)
                }
            })
            startListening(
                Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE, "es-AR")
                }
            )
        }
    }

    private fun ask(question: String) {
        setBubble("…", COLOR_THINKING)
        val key = getSharedPreferences("jarvis", MODE_PRIVATE).getString("key", "") ?: ""
        thread {
            val answer = try {
                callGemini(key, question)
            } catch (e: java.io.IOException) {
                "No pude conectarme a internet. Detalle: ${e.javaClass.simpleName} ${e.message}"
            } catch (e: Exception) {
                "Error inesperado: ${e.javaClass.simpleName} ${e.message}"
            }
            main.post { handleReply(answer) }
        }
    }

    private fun handleReply(raw: String) {
        if (raw.startsWith("No pude") || raw.startsWith("Error") || raw.startsWith("Gemini")) {
            android.widget.Toast.makeText(this, raw, android.widget.Toast.LENGTH_LONG).show()
            say(raw)
            return
        }
        val json = try {
            JSONObject(raw.substring(raw.indexOf('{'), raw.lastIndexOf('}') + 1))
        } catch (e: Exception) {
            null
        }
        if (json == null) {
            say(raw)
            return
        }
        val speech = json.optString("say", "")
        val msg = try {
            runAction(json)
        } catch (e: Exception) {
            "No pude hacer eso: ${e.message}"
        }
        say(msg ?: speech.ifEmpty { "Listo." })
    }

    private fun newTask(i: Intent): Intent = i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)

    private fun runAction(j: JSONObject): String? {
        when (j.optString("action", "none")) {
            "alarm" -> startActivity(
                newTask(
                    Intent(AlarmClock.ACTION_SET_ALARM)
                        .putExtra(AlarmClock.EXTRA_HOUR, j.getInt("hour"))
                        .putExtra(AlarmClock.EXTRA_MINUTES, j.optInt("minute", 0))
                        .putExtra(AlarmClock.EXTRA_MESSAGE, j.optString("label", "Jarvis"))
                        .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
                )
            )
            "timer" -> startActivity(
                newTask(
                    Intent(AlarmClock.ACTION_SET_TIMER)
                        .putExtra(AlarmClock.EXTRA_LENGTH, j.getInt("seconds"))
                        .putExtra(AlarmClock.EXTRA_MESSAGE, j.optString("label", "Jarvis"))
                        .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
                )
            )
            "flashlight" -> setTorch(j.optBoolean("on", true))
            "dnd" -> return setDnd(j.optBoolean("on", true))
            "call" -> return callContact(j.optString("contact", ""))
            "calendar" -> return addEvent(j)
        }
        return null
    }

    private fun setTorch(on: Boolean) {
        val cm = getSystemService(CameraManager::class.java)
        val id = cm.cameraIdList.firstOrNull {
            cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
        } ?: return
        cm.setTorchMode(id, on)
    }

    private fun setDnd(on: Boolean): String? {
        val nm = getSystemService(NotificationManager::class.java)
        if (!nm.isNotificationPolicyAccessGranted) {
            startActivity(newTask(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)))
            return "Necesito permiso para No molestar. Activalo para Jarvis en la pantalla que se abrió."
        }
        nm.setInterruptionFilter(
            if (on) NotificationManager.INTERRUPTION_FILTER_PRIORITY
            else NotificationManager.INTERRUPTION_FILTER_ALL
        )
        return null
    }

    private fun callContact(name: String): String? {
        if (checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED ||
            checkSelfPermission(Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED
        ) {
            return "Me faltan los permisos de contactos y llamadas. Dalos desde la app de Jarvis."
        }
        val phone = ContactsContract.CommonDataKinds.Phone.CONTENT_URI
        val cursor = contentResolver.query(
            phone,
            arrayOf(
                ContactsContract.CommonDataKinds.Phone.NUMBER,
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME
            ),
            "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?",
            arrayOf("%$name%"),
            null
        )
        cursor?.use {
            if (it.moveToFirst()) {
                val number = it.getString(0)
                val found = it.getString(1)
                startActivity(newTask(Intent(Intent.ACTION_CALL, Uri.parse("tel:" + Uri.encode(number)))))
                return "Llamando a $found."
            }
        }
        return "No encontré a $name en tus contactos."
    }

    private fun addEvent(j: JSONObject): String? {
        val start = SimpleDateFormat("yyyy-MM-dd'T'HH:mm", Locale.US).parse(j.getString("start"))
            ?: return "No entendí la fecha."
        val end = start.time + j.optInt("minutes", 60) * 60000L
        startActivity(
            newTask(
                Intent(Intent.ACTION_INSERT)
                    .setData(CalendarContract.Events.CONTENT_URI)
                    .putExtra(CalendarContract.Events.TITLE, j.optString("title", "Evento"))
                    .putExtra(CalendarContract.EXTRA_EVENT_BEGIN_TIME, start.time)
                    .putExtra(CalendarContract.EXTRA_EVENT_END_TIME, end)
            )
        )
        return null
    }

    private fun post(key: String, body: JSONObject): Pair<Int, String> {
        val url = URL("https://generativelanguage.googleapis.com/v1beta/models/$MODEL:generateContent")
        val c = url.openConnection() as HttpURLConnection
        c.requestMethod = "POST"
        c.connectTimeout = 20000
        c.readTimeout = 90000
        c.doOutput = true
        c.setRequestProperty("Content-Type", "application/json")
        c.setRequestProperty("x-goog-api-key", key)
        c.outputStream.use { it.write(body.toString().toByteArray()) }
        val code = c.responseCode
        val stream = if (code in 200..299) c.inputStream else c.errorStream
        val txt = stream?.bufferedReader()?.readText() ?: ""
        return Pair(code, txt)
    }

    private fun callGemini(key: String, question: String): String {
        val now = SimpleDateFormat("EEEE d 'de' MMMM 'de' yyyy, HH:mm", Locale("es")).format(Date())
        val iso = SimpleDateFormat("yyyy-MM-dd'T'HH:mm", Locale.US).format(Date())
        val system = """
Sos Jarvis, un asistente de voz en el celular del usuario.
Respondé SIEMPRE y SOLO con un objeto JSON válido, sin markdown ni texto extra.
Esquema: {"say":"lo que decís en voz alta","action":"none|alarm|timer|flashlight|dnd|call|calendar", ...campos}
Campos según la acción:
- alarm: hour (0-23), minute (0-59), label
- timer: seconds, label
- flashlight: on (true o false)
- dnd (no molestar): on (true o false)
- call: contact (el nombre tal como lo dijo el usuario)
- calendar: title, start (formato yyyy-MM-ddTHH:mm, hora local), minutes (duración, 60 por defecto)
Si no hay nada que ejecutar, action es "none" y solo conversás.
"say" es breve (máximo dos oraciones), en español rioplatense, sin markdown.
Fecha y hora actual: $now (formato ISO: $iso).
""".trimIndent()
        val body = JSONObject()
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system))))
            .put(
                "contents",
                JSONArray().put(
                    JSONObject().put("role", "user")
                        .put("parts", JSONArray().put(JSONObject().put("text", question)))
                )
            )

        // Primero intentamos con "pensamiento" bajo para que responda rápido.
        // Si el modelo no acepta esa opción (error 400), reintentamos sin ella.
        val fast = JSONObject(body.toString()).put(
            "generationConfig",
            JSONObject()
                .put("responseMimeType", "application/json")
                .put("thinkingConfig", JSONObject().put("thinkingLevel", "low"))
        )
        var (code, txt) = post(key, fast)
        if (code == 400) {
            val retry = post(key, body)
            code = retry.first
            txt = retry.second
        }

        if (code !in 200..299) {
            val msg = try {
                JSONObject(txt).getJSONObject("error").getString("message")
            } catch (e: Exception) {
                txt.take(150)
            }
            return "Gemini devolvió el error $code: $msg"
        }
        val cands = JSONObject(txt).optJSONArray("candidates")
        val parts = cands?.optJSONObject(0)?.optJSONObject("content")?.optJSONArray("parts")
            ?: return "Gemini no devolvió respuesta: ${txt.take(150)}"
        val sb = StringBuilder()
        for (i in 0 until parts.length()) sb.append(parts.getJSONObject(i).optString("text", ""))
        return sb.toString().trim().ifEmpty { "No tengo respuesta para eso." }
    }

    override fun onDestroy() {
        bubble?.let { wm.removeView(it) }
        bubble = null
        recognizer?.destroy()
        tts?.shutdown()
        super.onDestroy()
    }
}
