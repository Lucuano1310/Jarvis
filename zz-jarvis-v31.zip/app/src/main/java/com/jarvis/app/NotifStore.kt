package com.jarvis.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

object NotifStore {
    private const val MAX = 40

    data class Item(val app: String, val sender: String, val text: String, val time: Long)

    private fun load(ctx: Context): JSONArray {
        val p = ctx.getSharedPreferences("jarvis_notifs", Context.MODE_PRIVATE)
        return try {
            JSONArray(p.getString("items", "[]"))
        } catch (e: Exception) {
            JSONArray()
        }
    }

    /** Guarda la notificación. Devuelve false si es igual a la anterior (duplicada). */
    @Synchronized
    fun add(ctx: Context, item: Item): Boolean {
        val arr = load(ctx)
        if (arr.length() > 0) {
            val last = arr.getJSONObject(arr.length() - 1)
            if (last.optString("app") == item.app &&
                last.optString("sender") == item.sender &&
                last.optString("text") == item.text
            ) return false
        }
        arr.put(
            JSONObject()
                .put("app", item.app)
                .put("sender", item.sender)
                .put("text", item.text)
                .put("time", item.time)
        )
        val out = JSONArray()
        for (i in maxOf(0, arr.length() - MAX) until arr.length()) out.put(arr.get(i))
        ctx.getSharedPreferences("jarvis_notifs", Context.MODE_PRIVATE)
            .edit().putString("items", out.toString()).apply()
        return true
    }

    @Synchronized
    fun all(ctx: Context): List<Item> {
        val arr = load(ctx)
        val list = ArrayList<Item>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            list.add(Item(o.optString("app"), o.optString("sender"), o.optString("text"), o.optLong("time")))
        }
        return list
    }
}
