package com.jarvis.app

import android.content.Context
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

/** Clima con Open-Meteo (gratis, sin clave). Guarda hoy, mañana y pasado para poder responder sin internet. */
object Weather {
    private const val PREF = "jarvis_weather"

    private fun prefs(ctx: Context) = ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE)

    fun city(ctx: Context): String = prefs(ctx).getString("city", "") ?: ""

    private fun get(url: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 8000
        c.readTimeout = 10000
        if (c.responseCode !in 200..299) throw java.io.IOException("http ${c.responseCode}")
        return c.inputStream.bufferedReader().use { it.readText() }
    }

    /** Busca la ciudad por nombre y la guarda. Devuelve el nombre encontrado o null. */
    fun setCity(ctx: Context, name: String): String? {
        val url = "https://geocoding-api.open-meteo.com/v1/search?name=" +
            URLEncoder.encode(name, "UTF-8") + "&count=1&language=es&format=json"
        val r = JSONObject(get(url)).optJSONArray("results") ?: return null
        if (r.length() == 0) return null
        val o = r.getJSONObject(0)
        val admin = o.optString("admin1")
        val label = o.optString("name") + if (admin.isNotBlank()) ", $admin" else ""
        prefs(ctx).edit()
            .putString("city", label)
            .putString("lat", o.optDouble("latitude").toString())
            .putString("lon", o.optDouble("longitude").toString())
            .remove("days")
            .apply()
        return label
    }

    fun refresh(ctx: Context): Boolean {
        val p = prefs(ctx)
        val lat = p.getString("lat", null) ?: return false
        val lon = p.getString("lon", null) ?: return false
        val url = "https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon" +
            "&daily=weathercode,temperature_2m_max,temperature_2m_min,precipitation_probability_max" +
            "&timezone=auto&forecast_days=3"
        val d = JSONObject(get(url)).optJSONObject("daily") ?: return false
        val times = d.optJSONArray("time") ?: return false
        val codes = d.optJSONArray("weathercode") ?: return false
        val maxs = d.optJSONArray("temperature_2m_max") ?: return false
        val mins = d.optJSONArray("temperature_2m_min") ?: return false
        val rain = d.optJSONArray("precipitation_probability_max")
        val old = try { JSONObject(p.getString("days", "{}") ?: "{}") } catch (e: Exception) { JSONObject() }
        val today = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(java.util.Date())
        val days = JSONObject()
        // Conservo lo guardado que todavía sirve (hoy en adelante) y lo piso con lo nuevo.
        for (k in old.keys()) if (k >= today) days.put(k, old.getJSONObject(k))
        for (i in 0 until times.length()) {
            days.put(
                times.getString(i),
                JSONObject()
                    .put("c", codes.optInt(i))
                    .put("max", maxs.optDouble(i))
                    .put("min", mins.optDouble(i))
                    .put("p", rain?.optInt(i) ?: 0)
            )
        }
        p.edit().putString("days", days.toString()).putLong("fetched", System.currentTimeMillis()).apply()
        return true
    }

    fun ageHours(ctx: Context): Long {
        val f = prefs(ctx).getLong("fetched", 0L)
        if (f == 0L) return 9999L
        return (System.currentTimeMillis() - f) / 3600000L
    }

    private fun describe(code: Int): String = when (code) {
        0 -> "despejado"
        1 -> "mayormente despejado"
        2 -> "parcialmente nublado"
        3 -> "nublado"
        45, 48 -> "con niebla"
        in 51..57 -> "con llovizna"
        in 61..65 -> "con lluvia"
        66, 67 -> "con lluvia helada"
        in 71..75 -> "con nevadas"
        77 -> "con granizo fino"
        in 80..82 -> "con chubascos"
        85, 86 -> "con nevadas fuertes"
        95 -> "con tormenta"
        96, 99 -> "con tormenta y granizo"
        else -> "variable"
    }

    /** offset: 0 hoy, 1 mañana, 2 pasado mañana. Devuelve null si ese día no está guardado. */
    fun answer(ctx: Context, offset: Int): String? {
        val p = prefs(ctx)
        val days = try { JSONObject(p.getString("days", "{}") ?: "{}") } catch (e: Exception) { JSONObject() }
        val cal = Calendar.getInstance()
        cal.add(Calendar.DAY_OF_YEAR, offset)
        val key = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(cal.time)
        val o = days.optJSONObject(key) ?: return null
        val label = when (offset) {
            0 -> "Hoy"
            1 -> "Mañana"
            else -> "Pasado mañana"
        }
        var s = "$label en ${city(ctx)}: ${describe(o.optInt("c"))}, mínima de ${Math.round(o.optDouble("min"))} " +
            "y máxima de ${Math.round(o.optDouble("max"))} grados, con ${o.optInt("p")} por ciento de probabilidad de lluvia."
        val age = ageHours(ctx)
        if (age in 6..9000) s += " Dato guardado hace unas $age horas."
        return s
    }
}
