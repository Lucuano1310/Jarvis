package com.jarvis.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Guarda en el teléfono los últimos mensajes (de las notificaciones) de cada chat, por 3 días, para poder resumirlos. */
object MsgHistory {
    private const val PREF = "jarvis_history"

    private fun prefs(ctx: Context) = ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE)

    fun add(ctx: Context, chat: String, text: String) {
        if (chat.isBlank() || text.isBlank()) return
        val p = prefs(ctx)
        val arr = try { JSONArray(p.getString(chat, "[]") ?: "[]") } catch (e: Exception) { JSONArray() }
        if (arr.length() > 0 && arr.getJSONObject(arr.length() - 1).optString("x") == text.take(300)) return
        arr.put(JSONObject().put("t", System.currentTimeMillis()).put("x", text.take(300)))
        val min = System.currentTimeMillis() - 3L * 86400000L
        val keep = JSONArray()
        for (i in maxOf(0, arr.length() - 30) until arr.length()) {
            val o = arr.getJSONObject(i)
            if (o.optLong("t") >= min) keep.put(o)
        }
        p.edit().putString(chat, keep.toString()).apply()
    }

    fun chats(ctx: Context): List<String> = prefs(ctx).all.keys.toList()

    fun get(ctx: Context, chat: String): List<String> {
        val arr = try { JSONArray(prefs(ctx).getString(chat, "[]") ?: "[]") } catch (e: Exception) { JSONArray() }
        val out = ArrayList<String>()
        for (i in 0 until arr.length()) out.add(arr.getJSONObject(i).optString("x"))
        return out
    }

    fun clear(ctx: Context) {
        prefs(ctx).edit().clear().apply()
    }
}
