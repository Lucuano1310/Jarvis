package com.jarvis.app

import android.app.Notification
import android.app.PendingIntent
import android.app.RemoteInput
import android.content.Context
import android.content.Intent
import android.os.Bundle
import java.util.concurrent.ConcurrentHashMap

/** Guarda la acción "Responder" de las notificaciones de WhatsApp para poder contestar sin saber el número. */
object ReplyStore {
    private val map = ConcurrentHashMap<String, Pair<PendingIntent, RemoteInput>>()

    fun save(sender: String, n: Notification) {
        val actions = n.actions ?: return
        for (a in actions) {
            val ri = a.remoteInputs?.firstOrNull() ?: continue
            val pi = a.actionIntent ?: continue
            map[sender] = Pair(pi, ri)
            return
        }
    }

    fun names(): List<String> = map.keys.toList()

    fun send(ctx: Context, sender: String, text: String): Boolean {
        val e = map[sender] ?: return false
        return try {
            val intent = Intent()
            val b = Bundle()
            b.putCharSequence(e.second.resultKey, text)
            RemoteInput.addResultsToIntent(arrayOf(e.second), intent, b)
            e.first.send(ctx, 0, intent)
            true
        } catch (ex: Exception) {
            false
        }
    }
}
