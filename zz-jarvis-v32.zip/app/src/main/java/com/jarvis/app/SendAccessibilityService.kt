package com.jarvis.app

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Bitmap
import android.graphics.Path
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Toast
import java.text.Normalizer

class SendAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile var armedUntil = 0L
        @Volatile var running = false
        @Volatile var instance: SendAccessibilityService? = null

        // Flujo "buscar el chat por nombre": escribir o llamar desde WhatsApp.
        @Volatile var flowUntil = 0L
        @Volatile var flowName = ""
        @Volatile var flowText = ""
        @Volatile var flowCall = false
        @Volatile var flowStep = 0
        @Volatile var flowTries = 0
        @Volatile var flowScan = false
        @Volatile var flowMute = false
        @Volatile var flowMuteDur = "8h"
        @Volatile var scanStale = 0
        val scanSeen = HashSet<String>()

        fun closeCurrentApp(): Boolean {
            val s = instance ?: return false
            s.closeApp()
            return true
        }

        fun startMute(name: String, dur: String): Boolean {
            val svc = instance ?: return false
            svc.beginMute(name, dur)
            return true
        }

        fun screenText(): String? = instance?.collectScreenText()

        fun screenshotBase64(cb: (String?) -> Unit) {
            val svc = instance
            if (svc == null) cb(null) else svc.takeShot(cb)
        }

        fun startScan(): Boolean {
            val s = instance ?: return false
            s.beginScan()
            return true
        }

        fun startFlow(name: String, text: String, call: Boolean): Boolean {
            val s = instance ?: return false
            s.beginFlow(name, text, call)
            return true
        }
    }

    private val h = Handler(Looper.getMainLooper())
    private val poll = object : Runnable {
        override fun run() {
            if (System.currentTimeMillis() < flowUntil) {
                try { stepFlow() } catch (e: Exception) { }
                h.postDelayed(this, 700)
            } else if (flowScan) {
                flowScan = false
                flowStep = 99
                Toast.makeText(this@SendAccessibilityService, "Listo, aprendí ${scanSeen.size} chats.", Toast.LENGTH_LONG).show()
            } else if (flowStep in 0..3 || flowStep in 6..8) {
                flowStep = 99
                Toast.makeText(
                    this@SendAccessibilityService,
                    "No pude encontrar el chat de $flowName en WhatsApp.",
                    Toast.LENGTH_LONG
                ).show()
            }
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        running = true
        instance = this
    }

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        running = false
        instance = null
        return super.onUnbind(intent)
    }

    /** Abre recientes y desliza la tarjeta de la app actual hacia arriba, que es como se cierra a mano. */
    private fun closeApp() {
        performGlobalAction(GLOBAL_ACTION_RECENTS)
        h.postDelayed({
            val dm = resources.displayMetrics
            val w = dm.widthPixels.toFloat()
            val hgt = dm.heightPixels.toFloat()
            val path = Path().apply {
                moveTo(w / 2f, hgt * 0.55f)
                lineTo(w / 2f, hgt * 0.08f)
            }
            val g = GestureDescription.Builder()
                .addStroke(GestureDescription.StrokeDescription(path, 0L, 220L))
                .build()
            dispatchGesture(g, null, null)
            h.postDelayed({ performGlobalAction(GLOBAL_ACTION_HOME) }, 700)
        }, 1000)
    }

    /** Texto visible en la pantalla actual (solo cuando el usuario lo pide). Omite campos de contraseña. */
    fun collectScreenText(): String? {
        val root = rootInActiveWindow ?: return null
        val sb = StringBuilder()
        val seen = HashSet<String>()
        for (n in all(root)) {
            if (!n.isVisibleToUser || n.isPassword) continue
            val t = (n.text?.toString() ?: n.contentDescription?.toString() ?: "").trim()
            if (t.length < 2 || !seen.add(t)) continue
            sb.append(t).append('\n')
            if (sb.length > 3500) break
        }
        return sb.toString().trim()
    }

    /** Saca una captura de pantalla (Android 11 o más) y la devuelve como JPEG chico en base64. */
    @android.annotation.SuppressLint("NewApi")
    private fun takeShot(cb: (String?) -> Unit) {
        if (Build.VERSION.SDK_INT < 30) {
            cb(null)
            return
        }
        try {
            takeScreenshot(
                android.view.Display.DEFAULT_DISPLAY,
                mainExecutor,
                object : AccessibilityService.TakeScreenshotCallback {
                    override fun onSuccess(result: AccessibilityService.ScreenshotResult) {
                        var out: String? = null
                        try {
                            val hw = Bitmap.wrapHardwareBuffer(result.hardwareBuffer, result.colorSpace)
                            if (hw != null) {
                                val bmp = hw.copy(Bitmap.Config.ARGB_8888, false)
                                val scale = 1024f / maxOf(bmp.width, bmp.height)
                                val scaled = if (scale < 1f)
                                    Bitmap.createScaledBitmap(bmp, (bmp.width * scale).toInt(), (bmp.height * scale).toInt(), true)
                                else bmp
                                val bos = java.io.ByteArrayOutputStream()
                                scaled.compress(Bitmap.CompressFormat.JPEG, 70, bos)
                                out = android.util.Base64.encodeToString(bos.toByteArray(), android.util.Base64.NO_WRAP)
                            }
                        } catch (e: Exception) {
                        }
                        try {
                            result.hardwareBuffer.close()
                        } catch (e: Exception) {
                        }
                        cb(out)
                    }

                    override fun onFailure(errorCode: Int) {
                        cb(null)
                    }
                }
            )
        } catch (e: Exception) {
            cb(null)
        }
    }

    private fun beginMute(name: String, dur: String) {
        flowScan = false
        flowName = name
        flowText = ""
        flowCall = false
        flowMute = true
        flowMuteDur = dur
        flowStep = 0
        flowTries = 0
        flowUntil = System.currentTimeMillis() + 40000
        h.removeCallbacks(poll)
        h.postDelayed(poll, 1800)
    }

    private fun finishMute() {
        flowUntil = 0L
        flowStep = 100
        flowMute = false
        val msg = when (flowMuteDur) {
            "off" -> "Reactivé las notificaciones de $flowName."
            "always" -> "Silencié $flowName para siempre."
            "1w" -> "Silencié $flowName por una semana."
            else -> "Silencié $flowName por ocho horas."
        }
        Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
    }

    private fun toastClickables(root: AccessibilityNodeInfo) {
        val labels = all(root).filter { it.isClickable }
            .mapNotNull { (it.contentDescription?.toString() ?: it.text?.toString())?.takeIf { s -> s.isNotBlank() } }
            .distinct().take(14)
        Toast.makeText(this, "No encuentro el botón de llamada. Veo: " + labels.joinToString(" | "), Toast.LENGTH_LONG).show()
    }

    private fun findTextContains(root: AccessibilityNodeInfo, keys: List<String>): AccessibilityNodeInfo? {
        val nodes = all(root)
        for (k in keys) {
            val n = nodes.firstOrNull { (it.text?.toString()?.lowercase() ?: "").contains(k) }
            if (n != null) return n
        }
        return null
    }

    private fun beginScan() {
        flowMute = false
        flowScan = true
        flowStep = 0
        flowTries = 0
        scanStale = 0
        scanSeen.clear()
        flowName = "tus chats"
        flowUntil = System.currentTimeMillis() + 90000
        h.removeCallbacks(poll)
        h.postDelayed(poll, 1800)
    }

    private fun finishScan() {
        flowUntil = 0L
        flowStep = 100
        flowScan = false
        Toast.makeText(this, "Listo, aprendí ${scanSeen.size} chats.", Toast.LENGTH_LONG).show()
    }

    private fun stepScan(root: AccessibilityNodeInfo, entry: AccessibilityNodeInfo?) {
        if (entry != null) {
            performGlobalAction(GLOBAL_ACTION_BACK)
            return
        }
        val rows = ArrayList<AccessibilityNodeInfo>()
        for (p in listOf("com.whatsapp", "com.whatsapp.w4b")) {
            rows.addAll(root.findAccessibilityNodeInfosByViewId("$p:id/conversations_row_contact_name"))
        }
        if (rows.isEmpty()) {
            flowTries++
            if (flowTries > 8) finishScan()
            return
        }
        val ed = getSharedPreferences("jarvis_chats", MODE_PRIVATE).edit()
        var fresh = 0
        for (r in rows) {
            val n = r.text?.toString()?.trim() ?: continue
            if (n.isEmpty()) continue
            if (scanSeen.add(n)) {
                ed.putString(n, "1")
                fresh++
            }
        }
        ed.apply()
        if (fresh == 0) scanStale++ else scanStale = 0
        if (scanStale >= 2) {
            finishScan()
            return
        }
        var p: AccessibilityNodeInfo? = rows[0].parent
        while (p != null && !p.isScrollable) p = p.parent
        p?.performAction(AccessibilityNodeInfo.ACTION_SCROLL_FORWARD)
    }

    private fun beginFlow(name: String, text: String, call: Boolean) {
        flowScan = false
        flowMute = false
        flowName = name
        flowText = text
        flowCall = call
        flowStep = 0
        flowTries = 0
        flowUntil = System.currentTimeMillis() + 35000
        h.removeCallbacks(poll)
        h.postDelayed(poll, 1800)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event?.packageName?.toString()?.startsWith("com.whatsapp") != true) return
        if (System.currentTimeMillis() > armedUntil) return
        val root = rootInActiveWindow ?: return
        val node = findSend(root) ?: return
        if (node.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
            armedUntil = 0L
        }
    }

    override fun onInterrupt() {}

    // ---------- Flujo por nombre ----------

    private fun stepFlow() {
        val root = rootInActiveWindow ?: return
        val pkg = root.packageName?.toString() ?: return
        if (!pkg.startsWith("com.whatsapp")) return
        val entry = findById(root, "entry")
        val token = firstToken(flowName)
        if (flowScan) {
            stepScan(root, entry)
            return
        }
        when (flowStep) {
            0 -> {
                if (entry != null) {
                    // estamos dentro de un chat: volvemos a la lista
                    performGlobalAction(GLOBAL_ACTION_BACK)
                    return
                }
                val s = findSearch(root)
                if (s != null && clickNode(s)) {
                    flowStep = 1
                    flowTries = 0
                }
            }
            1 -> {
                val edit = findEdit(root)
                if (edit != null) {
                    if (setText(edit, token)) {
                        flowStep = 2
                        flowTries = 0
                    }
                } else {
                    flowTries++
                    if (flowTries > 6) flowStep = 0
                }
            }
            2 -> {
                val r = findResult(root, token)
                if (r != null && clickNode(r)) {
                    flowStep = 3
                    flowTries = 0
                }
            }
            3 -> {
                if (entry == null) return
                if (flowMute) {
                    val more = findByDesc(root, listOf("más opciones", "mas opciones", "more options"))
                    if (more != null && clickNode(more)) {
                        flowStep = 6
                        flowTries = 0
                    }
                    return
                }
                if (flowCall) {
                    val b = findById(root, "menuitem_voice_call") ?: findById(root, "menuitem_call")
                        ?: findById(root, "voice_call")
                        ?: findByDesc(root, listOf("llamada de voz", "voice call", "llamar", "llamada", "call"))
                    if (b != null && clickNode(b)) {
                        flowStep = 4
                        flowTries = 0
                    } else {
                        flowTries++
                        if (flowTries >= 10) {
                            toastClickables(root)
                            flowUntil = 0L
                            flowStep = 100
                        }
                    }
                } else {
                    if (flowText.isNotEmpty() && setText(entry, flowText)) flowStep = 5
                }
            }
            4 -> {
                // El botón de llamada de WhatsApp puede abrir un menú (voz / video): elegimos voz.
                if (flowTries == 0) {
                    flowTries++
                    return
                }
                val opt = all(root).firstOrNull {
                    val t = ((it.text?.toString() ?: "") + " " + (it.contentDescription?.toString() ?: "")).lowercase().trim()
                    !t.contains("video") && (t.contains("llamada de voz") || t.contains("voice call") ||
                        t.contains("llamada de audio") || t.contains("audio call") || t == "llamar" || t == "call" ||
                        t == "aceptar" || t == "ok" || t == "iniciar llamada")
                }
                if (opt != null && clickNode(opt)) {
                    flowUntil = 0L
                    flowStep = 100
                    return
                }
                flowTries++
                if (flowTries >= 7) {
                    flowUntil = 0L
                    flowStep = 100
                }
            }
            5 -> {
                val send = findSend(root)
                if (send != null && send.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                    flowUntil = 0L
                    flowStep = 100
                } else {
                    flowTries++
                    if (flowTries > 6) flowStep = 3
                }
            }
        }
    }

    private fun norm(t: String): String =
        Normalizer.normalize(t, Normalizer.Form.NFD)
            .replace(Regex("\\p{InCombiningDiacriticalMarks}+"), "")
            .lowercase()

    private fun keyOf(t: String): String = norm(t).replace(Regex("[^a-z0-9]"), "")

    private fun firstToken(name: String): String =
        name.split(Regex("[^\\p{L}\\p{N}]+")).firstOrNull { it.length >= 2 } ?: name.trim()

    private fun walk(n: AccessibilityNodeInfo?, out: MutableList<AccessibilityNodeInfo>, depth: Int = 0) {
        if (n == null || depth > 30) return
        out.add(n)
        for (i in 0 until n.childCount) walk(n.getChild(i), out, depth + 1)
    }

    private fun all(root: AccessibilityNodeInfo): List<AccessibilityNodeInfo> {
        val out = ArrayList<AccessibilityNodeInfo>()
        walk(root, out)
        return out
    }

    private fun findById(root: AccessibilityNodeInfo, name: String): AccessibilityNodeInfo? {
        for (p in listOf("com.whatsapp", "com.whatsapp.w4b")) {
            val n = root.findAccessibilityNodeInfosByViewId("$p:id/$name").firstOrNull()
            if (n != null) return n
        }
        return null
    }

    private fun label(n: AccessibilityNodeInfo): String =
        ((n.text?.toString() ?: "") + " " + (n.contentDescription?.toString() ?: "")).lowercase()

    private fun findSearch(root: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        findById(root, "menuitem_search")?.let { return it }
        return all(root).firstOrNull {
            val t = label(it)
            it.className?.toString() != "android.widget.EditText" && (t.contains("buscar") || t.contains("search"))
        }
    }

    private fun findEdit(root: AccessibilityNodeInfo): AccessibilityNodeInfo? =
        all(root).firstOrNull { it.className?.toString() == "android.widget.EditText" }

    private fun findResult(root: AccessibilityNodeInfo, token: String): AccessibilityNodeInfo? {
        val t = norm(token)
        val cands = all(root).filter {
            it.className?.toString() != "android.widget.EditText" &&
                (it.text?.toString() ?: "").isNotEmpty() &&
                norm(it.text.toString()).contains(t)
        }
        if (cands.isEmpty()) return null
        val wanted = keyOf(flowName)
        return cands.firstOrNull { keyOf(it.text.toString()) == wanted } ?: cands.first()
    }

    private fun findByDesc(root: AccessibilityNodeInfo, descs: List<String>): AccessibilityNodeInfo? {
        for (d in descs) {
            val n = all(root).firstOrNull {
                val cd = it.contentDescription?.toString()?.lowercase() ?: ""
                cd.isNotEmpty() && cd.contains(d) && !cd.contains("video")
            }
            if (n != null) return n
        }
        return null
    }

    private fun findButtonText(root: AccessibilityNodeInfo, names: List<String>): AccessibilityNodeInfo? =
        all(root).firstOrNull {
            val t = it.text?.toString()?.trim()?.lowercase() ?: ""
            t in names
        }

    private fun clickNode(n0: AccessibilityNodeInfo): Boolean {
        var n: AccessibilityNodeInfo? = n0
        var d = 0
        while (n != null && d < 6) {
            if (n.isClickable && n.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
            n = n.parent
            d++
        }
        return false
    }

    private fun setText(n: AccessibilityNodeInfo, text: String): Boolean {
        val b = Bundle()
        b.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        return n.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, b)
    }

    private fun findSend(root: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        for (id in listOf("com.whatsapp:id/send", "com.whatsapp.w4b:id/send")) {
            val n = root.findAccessibilityNodeInfosByViewId(id).firstOrNull()
            if (n != null) return n
        }
        for (label in listOf("Enviar", "Send")) {
            val n = root.findAccessibilityNodeInfosByText(label).firstOrNull { it.isClickable }
            if (n != null) return n
        }
        return null
    }
}
