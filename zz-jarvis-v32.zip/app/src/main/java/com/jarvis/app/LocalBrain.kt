package com.jarvis.app

import org.json.JSONArray
import org.json.JSONObject
import java.text.Normalizer
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/**
 * Entiende los pedidos más comunes sin internet ni Gemini.
 * Devuelve el mismo JSON que Gemini ({"say":..., "action":..., campos}) o null si no lo entiende.
 */
object LocalBrain {

    class Ctx(
        val batteryPct: Int,
        val charging: Boolean,
        val pendingSend: Boolean,
        val choiceCount: Int,
        val guideActive: Boolean = false,
        val muteActive: Boolean = false,
        val apps: List<String> = emptyList(),
        val routines: List<String> = emptyList(),
        val callActive: Boolean = false
    )

    private val NUM = mapOf(
        "cero" to 0, "dos" to 2, "tres" to 3, "cuatro" to 4, "cinco" to 5, "seis" to 6, "siete" to 7,
        "ocho" to 8, "nueve" to 9, "diez" to 10, "once" to 11, "doce" to 12, "trece" to 13,
        "catorce" to 14, "quince" to 15, "dieciseis" to 16, "diecisiete" to 17, "dieciocho" to 18,
        "diecinueve" to 19, "veinte" to 20, "veintiuno" to 21, "veintidos" to 22, "veintitres" to 23,
        "veinticuatro" to 24, "veinticinco" to 25, "veintiseis" to 26, "veintisiete" to 27,
        "veintiocho" to 28, "veintinueve" to 29, "treinta" to 30, "cuarenta" to 40, "cincuenta" to 50,
        "sesenta" to 60
    )
    private val U9 = mapOf(
        "uno" to 1, "dos" to 2, "tres" to 3, "cuatro" to 4, "cinco" to 5,
        "seis" to 6, "siete" to 7, "ocho" to 8, "nueve" to 9
    )
    private val COMPOUND = Regex("""\b(treinta|cuarenta|cincuenta) y (uno|dos|tres|cuatro|cinco|seis|siete|ocho|nueve)\b""")
    private val SINGLES = Regex("""\b(""" + NUM.keys.sortedByDescending { it.length }.joinToString("|") + """)\b""")

    private fun norm(t: String): String =
        Normalizer.normalize(t, Normalizer.Form.NFD)
            .replace(Regex("\\p{InCombiningDiacriticalMarks}+"), "")
            .lowercase(Locale.ROOT)

    private fun digitize(s: String): String {
        var r = COMPOUND.replace(s) { m -> ((NUM[m.groupValues[1]] ?: 0) + (U9[m.groupValues[2]] ?: 0)).toString() }
        r = SINGLES.replace(r) { m -> (NUM[m.value] ?: 0).toString() }
        return r
    }

    private fun res(say: String, action: String): JSONObject =
        JSONObject().put("say", say).put("action", action)

    private val CLOCK = Regex(
        """\b(?:a\s+las?|para\s+las?)\s+(\d{1,2}|una)(?::(\d{2}))?(?:\s+y\s+(media|cuarto|\d{1,2}))?(?:\s+menos\s+(cuarto|\d{1,2}))?(?:\s+(?:de\s+la|de|en\s+la|del)\s+(manana|tarde|noche|madrugada|mediodia))?"""
    )
    private val DURATION = Regex("""\b(?:en|dentro\s+de|de|por)?\s*(\d+|un|una)\s*(horas?|min\w*|seg\w*)\b""")

    private fun nextMinutes(h: Int, m: Int, now: Calendar): Int {
        val cur = now.get(Calendar.HOUR_OF_DAY) * 60 + now.get(Calendar.MINUTE)
        val target = h * 60 + m
        return ((target - cur) % 1440 + 1440) % 1440
    }

    /** Devuelve hora, minutos y el rango (en caracteres) de la frase de hora dentro de `d`. */
    private fun parseClock(d: String): Triple<Int, Int, IntRange>? {
        if (!CLOCK.containsMatchIn(d)) {
            Regex("""\b(?:al\s+)?mediodia\b""").find(d)?.let { return Triple(12, 0, it.range) }
            Regex("""\b(?:a\s+)?medianoche\b""").find(d)?.let { return Triple(0, 0, it.range) }
            Regex("""\b(?:a\s+la\s+)?madrugada\b""").find(d)?.let { return null }
        }
        val m = CLOCK.find(d) ?: return null
        var h = if (m.groupValues[1] == "una") 1 else m.groupValues[1].toIntOrNull() ?: return null
        var min = m.groupValues[2].toIntOrNull() ?: 0
        val y = m.groupValues[3]
        if (y.isNotEmpty()) min = when (y) { "media" -> 30; "cuarto" -> 15; else -> y.toIntOrNull() ?: 0 }
        val menos = m.groupValues[4]
        if (menos.isNotEmpty()) {
            val q = if (menos == "cuarto") 15 else (menos.toIntOrNull() ?: 0)
            h -= 1
            min = 60 - q
        }
        val period = m.groupValues[5]
        when (period) {
            "tarde", "noche" -> if (h < 12) h += 12
            "manana", "madrugada" -> if (h == 12) h = 0
            "mediodia" -> if (h < 12) h = 12
            else -> {
                if (h in 1..12) {
                    val now = Calendar.getInstance()
                    val a = h % 24
                    val b = (h + 12) % 24
                    h = if (nextMinutes(a, min, now) <= nextMinutes(b, min, now)) a else b
                }
            }
        }
        if (h < 0) h += 24
        if (h > 23 || min > 59) return null
        return Triple(h, min, m.range)
    }

    private fun durationSeconds(d: String): Pair<Int, IntRange>? {
        Regex("""\bmedia\s+hora\b""").find(d)?.let { return Pair(1800, it.range) }
        val m = DURATION.find(d) ?: return null
        val q = m.groupValues[1].let { if (it == "un" || it == "una") 1 else it.toIntOrNull() ?: return null }
        val u = m.groupValues[2]
        val secs = when {
            u.startsWith("hora") -> q * 3600
            u.startsWith("min") -> q * 60
            else -> q
        }
        return Pair(secs, m.range)
    }

    private val CAPITALS = mapOf(
        "argentina" to "Buenos Aires", "brasil" to "Brasilia", "chile" to "Santiago", "uruguay" to "Montevideo",
        "paraguay" to "Asunción", "bolivia" to "Sucre, aunque la sede del gobierno está en La Paz", "peru" to "Lima",
        "colombia" to "Bogotá", "venezuela" to "Caracas", "ecuador" to "Quito", "mexico" to "Ciudad de México",
        "cuba" to "La Habana", "estados unidos" to "Washington D. C.", "canada" to "Ottawa", "espana" to "Madrid",
        "francia" to "París", "italia" to "Roma", "alemania" to "Berlín", "reino unido" to "Londres", "portugal" to "Lisboa",
        "rusia" to "Moscú", "china" to "Pekín", "japon" to "Tokio", "india" to "Nueva Delhi", "australia" to "Canberra",
        "egipto" to "El Cairo", "sudafrica" to "Pretoria", "turquia" to "Ankara", "grecia" to "Atenas",
        "paises bajos" to "Ámsterdam", "holanda" to "Ámsterdam", "belgica" to "Bruselas", "suiza" to "Berna",
        "suecia" to "Estocolmo", "noruega" to "Oslo", "dinamarca" to "Copenhague", "finlandia" to "Helsinki",
        "polonia" to "Varsovia", "ucrania" to "Kiev", "irlanda" to "Dublín", "austria" to "Viena",
        "corea del sur" to "Seúl", "tailandia" to "Bangkok", "indonesia" to "Yakarta", "marruecos" to "Rabat",
        "nigeria" to "Abuya", "kenia" to "Nairobi", "costa rica" to "San José", "panama" to "Ciudad de Panamá",
        "guatemala" to "Ciudad de Guatemala", "honduras" to "Tegucigalpa", "el salvador" to "San Salvador",
        "nicaragua" to "Managua", "republica dominicana" to "Santo Domingo", "arabia saudita" to "Riad",
        "iran" to "Teherán", "irak" to "Bagdad", "pakistan" to "Islamabad", "nueva zelanda" to "Wellington"
    )
    private val CAPITAL_ALIAS = mapOf("eeuu" to "estados unidos", "usa" to "estados unidos", "inglaterra" to "reino unido", "gran bretana" to "reino unido")

    private val FACTS: List<Pair<Regex, String>> = listOf(
        Regex("""planeta\s+mas\s+grande""") to "Júpiter es el planeta más grande del sistema solar.",
        Regex("""planeta\s+mas\s+(cercano|proximo)\s+al\s+sol""") to "Mercurio es el planeta más cercano al Sol.",
        Regex("""cuantos\s+planetas""") to "El sistema solar tiene ocho planetas.",
        Regex("""rio\s+mas\s+(largo|caudaloso|grande)""") to "Se suele decir que el Nilo o el Amazonas, según cómo se mida el largo. El Amazonas es el más caudaloso.",
        Regex("""(montana|pico)\s+mas\s+alt""") to "El Everest, con unos 8.849 metros. En América, el Aconcagua, en Argentina, con casi 6.961 metros.",
        Regex("""oceano\s+mas\s+grande""") to "El océano Pacífico.",
        Regex("""quien\s+(escribio|es\s+el\s+autor\s+de)\s+(el\s+)?(don\s+)?quijote""") to "Miguel de Cervantes.",
        Regex("""quien\s+pinto\s+la\s+mona\s+lisa""") to "Leonardo da Vinci.",
        Regex("""quien\s+descubrio\s+america""") to "Cristóbal Colón llegó a América en 1492, aunque allí ya vivían pueblos originarios.",
        Regex("""independencia\s+(de\s+)?(la\s+)?argentin""") to "La independencia se declaró el 9 de julio de 1816, en Tucumán.",
        Regex("""revolucion\s+de\s+mayo""") to "Fue el 25 de mayo de 1810, en Buenos Aires.",
        Regex("""quien\s+fue\s+(el\s+)?(general\s+)?(jose\s+de\s+)?san\s+martin""") to "José de San Martín fue el libertador de Argentina, Chile y Perú, y cruzó los Andes en 1817.",
        Regex("""quien\s+fue\s+(manuel\s+)?belgrano""") to "Manuel Belgrano fue un general y economista argentino, creador de la bandera.",
        Regex("""(hombre|llego|llegar|pis\w+)\s+(a\s+)?(en\s+)?la\s+luna""") to "Neil Armstrong pisó la Luna el 20 de julio de 1969, con la misión Apolo 11.",
        Regex("""segunda\s+guerra\s+mundial""") to "Duró de 1939 a 1945.",
        Regex("""primera\s+guerra\s+mundial""") to "Duró de 1914 a 1918.",
        Regex("""muro\s+de\s+berlin""") to "Cayó el 9 de noviembre de 1989.",
        Regex("""velocidad\s+de\s+la\s+luz""") to "Unos 300.000 kilómetros por segundo.",
        Regex("""cuantos\s+huesos""") to "Un adulto tiene 206 huesos.",
        Regex("""cuantos\s+continentes""") to "Se suelen contar siete, aunque según el modelo pueden ser seis o cinco.",
        Regex("""formula\s+(quimica\s+)?del\s+agua""") to "H2O: dos de hidrógeno y uno de oxígeno.",
        Regex("""ebullicion\s+del\s+agua|a\s+que\s+temperatura\s+hierve""") to "A 100 grados Celsius al nivel del mar.",
        Regex("""cuantos\s+dias\s+tiene\s+(un\s+)?ano""") to "365, y 366 en los años bisiestos.",
        Regex("""mundial\s+(de\s+)?2022|campeon\s+del\s+mundo\s+(en\s+)?2022""") to "Argentina, que le ganó a Francia por penales en la final de Qatar 2022.",
        Regex("""mundial\s+(de\s+)?(1986|86)""") to "Argentina, en México 86, con Maradona.",
        Regex("""mundial\s+(de\s+)?(1978|78)""") to "Argentina, jugando de local en 1978.",
        Regex("""quien\s+es\s+(lionel\s+)?messi""") to "Lionel Messi es un futbolista argentino, campeón del mundo en 2022.",
        Regex("""quien\s+(es|fue)\s+(diego\s+)?maradona""") to "Diego Maradona fue un futbolista argentino, campeón del mundo en 1986.",
        Regex("""que\s+es\s+(la\s+)?fotosintesis""") to "Es el proceso con el que las plantas usan la luz del sol, agua y dióxido de carbono para producir su alimento y oxígeno.",
        Regex("""que\s+es\s+(la\s+)?gravedad""") to "Es la fuerza que atrae los objetos entre sí. La de la Tierra es la que nos mantiene en el suelo.",
        Regex("""que\s+es\s+(la\s+)?inflacion""") to "Es el aumento general y sostenido de los precios, que hace que la plata compre menos con el tiempo.",
        Regex("""que\s+es\s+(el\s+)?(pbi|pib)""") to "Es el valor de todo lo que produce un país en un período, normalmente un año.",
        Regex("""que\s+es\s+(el\s+)?adn""") to "Es la molécula que guarda la información genética de los seres vivos.",
        Regex("""que\s+es\s+(la\s+)?democracia""") to "Es un sistema de gobierno donde el poder lo ejerce el pueblo, normalmente votando a sus representantes.",
        Regex("""que\s+es\s+(un\s+)?agujero\s+negro""") to "Es una región del espacio con una gravedad tan fuerte que ni la luz puede escapar.",
        Regex("""que\s+es\s+(la\s+)?inteligencia\s+artificial""") to "Son programas que aprenden de datos para hacer tareas que normalmente requieren inteligencia humana, como entender el lenguaje.",
        Regex("""cuando\s+(es|cae)\s+navidad""") to "El 25 de diciembre.",
        Regex("""cuando\s+(es|cae)\s+(ano\s+nuevo|fin\s+de\s+ano)""") to "El 31 de diciembre es Nochebuena de fin de año y el año nuevo empieza el 1 de enero."
    )

    private fun knowledge(n: String): String? {
        Regex("""\bcapital\s+de\s+(?:la\s+|el\s+|los\s+)?(.+)$""").find(n)?.let {
            var c = it.groupValues[1].trim()
            c = CAPITAL_ALIAS[c] ?: c
            CAPITALS[c]?.let { cap -> return "La capital es $cap." }
        }
        Regex("""\bcuantos\s+dias\s+faltan\s+para\s+(navidad|ano\s+nuevo|fin\s+de\s+ano)\b""").find(n)?.let {
            val now = Calendar.getInstance()
            val t = Calendar.getInstance()
            val isXmas = it.groupValues[1] == "navidad"
            t.set(now.get(Calendar.YEAR), if (isXmas) Calendar.DECEMBER else Calendar.DECEMBER, if (isXmas) 25 else 31, 0, 0, 0)
            now.set(Calendar.HOUR_OF_DAY, 0); now.set(Calendar.MINUTE, 0); now.set(Calendar.SECOND, 0)
            val days = Math.round((t.timeInMillis - now.timeInMillis) / 86400000.0).toInt()
            return when {
                days == 0 -> "Es hoy."
                days > 0 -> "Faltan $days días."
                else -> "Ya pasó este año."
            }
        }
        for ((re, ans) in FACTS) if (re.containsMatchIn(n)) return ans
        return null
    }

    private val FILLER_START = listOf(
        "por favor", "porfa", "porfis", "me podes", "me podrias", "me puedes", "me ayudas a", "me ayudarias a", "ayudame a",
        "decime si podes", "fijate si podes", "sos tan amable de", "seria tan amable de", "quiero que", "queria que",
        "necesito que", "te pido que", "te pido", "podes", "podrias", "puedes", "necesito", "quisiera", "queria", "quiero",
        "che", "bueno", "mira", "a ver", "dale", "jefe", "loco", "amigo", "jarvis", "oye", "escucha", "una cosa"
    ).sortedByDescending { it.split(" ").size }
    private val FILLER_END = listOf("por favor", "porfa", "porfis", "gracias", "jefe", "amigo", "loco", "che", "ahora", "ya")

    /** Cuántas palabras de relleno (cortesía, muletillas) sacar al principio y al final, sin vaciar la frase. */
    private fun fillerCut(nt: List<String>): Pair<Int, Int> {
        var a = 0
        var b = 0
        var changed = true
        while (changed) {
            changed = false
            for (f in FILLER_START) {
                val w = f.split(" ")
                if (a + w.size < nt.size - b && nt.subList(a, a + w.size) == w) {
                    a += w.size
                    changed = true
                    break
                }
            }
        }
        changed = true
        while (changed) {
            changed = false
            for (f in FILLER_END) {
                val w = f.split(" ")
                if (nt.size - b - w.size > a && nt.subList(nt.size - b - w.size, nt.size - b) == w) {
                    b += w.size
                    changed = true
                    break
                }
            }
        }
        return Pair(a, b)
    }

    private val SYNW = mapOf(
        "wasap" to "whatsapp", "wsp" to "whatsapp", "wpp" to "whatsapp", "guasap" to "whatsapp", "whats" to "whatsapp",
        "wapp" to "whatsapp", "zap" to "whatsapp", "celu" to "celular", "cel" to "celular", "movil" to "celular",
        "smartphone" to "celular", "despertador" to "alarma", "alarmita" to "alarma", "ponme" to "pone",
        "poneme" to "pone", "ponele" to "pone", "ponelo" to "pone", "ponela" to "pone", "prendeme" to "prende",
        "prendelo" to "prende", "prendela" to "prende", "apagame" to "apaga", "apagalo" to "apaga", "apagala" to "apaga",
        "subile" to "subi", "subime" to "subi", "subilo" to "subi", "subila" to "subi", "bajale" to "baja",
        "bajame" to "baja", "bajalo" to "baja", "bajala" to "baja", "abrime" to "abri", "abrilo" to "abri",
        "abrila" to "abri", "cerrame" to "cerra", "cerralo" to "cerra", "cerrala" to "cerra", "anotame" to "anota",
        "anotalo" to "anota", "anotala" to "anota", "apuntame" to "apunta", "apuntalo" to "apunta",
        "borralo" to "borra", "borrala" to "borra", "borrame" to "borra", "sacalo" to "saca", "sacala" to "saca",
        "sacame" to "saca", "quitalo" to "quita", "quitala" to "quita", "quitame" to "quita", "eliminalo" to "elimina",
        "eliminala" to "elimina", "cancelalo" to "cancela", "cancelala" to "cancela", "cancelame" to "cancela",
        "desactivalo" to "desactiva", "desactivala" to "desactiva", "activalo" to "activa", "activala" to "activa",
        "activame" to "activa", "llamalo" to "llama", "llamala" to "llama", "mostrame" to "mostra",
        "fijame" to "pone", "programame" to "programa", "configurame" to "configura", "armame" to "arma",
        "creame" to "crea", "haceme" to "hace", "dejame" to "deja", "guardame" to "guarda"
    )

    private val SUBJ = mapOf(
        "pongas" to "pone", "ponga" to "pone", "anotes" to "anota", "anote" to "anota", "agregues" to "agrega",
        "agregue" to "agrega", "abras" to "abri", "abra" to "abri", "cierres" to "cerra", "cierre" to "cerra",
        "subas" to "subi", "suba" to "subi", "bajes" to "baja", "baje" to "baja", "prendas" to "prende",
        "prenda" to "prende", "apagues" to "apaga", "apague" to "apaga", "llames" to "llama", "llame" to "llama",
        "escribas" to "escribi", "escriba" to "escribi", "leas" to "lee", "lea" to "lee", "recuerdes" to "recuerda",
        "recuerde" to "recuerda", "avises" to "avisa", "avise" to "avisa", "busques" to "busca", "busque" to "busca",
        "mandes" to "manda", "mande" to "manda", "envies" to "envia", "envie" to "envia", "digas" to "deci",
        "muestres" to "mostra", "actives" to "activa", "active" to "activa", "desactives" to "desactiva",
        "desactive" to "desactiva", "saques" to "saca", "saque" to "saca", "tomes" to "toma", "hagas" to "hace",
        "guardes" to "guarda", "guarde" to "guarda", "borres" to "borra", "borre" to "borra", "elimines" to "elimina",
        "programes" to "programa", "configures" to "configura", "pases" to "pasa", "silencies" to "silencia",
        "dictes" to "dicta", "agendes" to "agenda", "agende" to "agenda", "olvides" to "olvida",
        "despiertes" to "desperta", "reproduzcas" to "reproduci", "canceles" to "cancela", "cancele" to "cancela"
    )

    private fun parseMuteDuration(d: String): String? = when {
        Regex("""\b(siempre|permanente|para\s+siempre)\b""").containsMatchIn(d) -> "always"
        Regex("""\bsemana\b|\b7\s+dias\b""").containsMatchIn(d) -> "1w"
        Regex("""\b8\s+horas?\b|\bhoy\b|\bun\s+dia\b|\b24\s+horas\b|\bnoche\b|\bdia\b|\bunas\s+horas\b""").containsMatchIn(d) -> "8h"
        else -> null
    }

    private val YES = Regex("""^(si|sii|siii|sip|claro|dale|ok|okey|okay|listo|de\s+una|de\s+acuerdo|estoy\s+de\s+acuerdo|esta\s+bien|bueno|perfecto|adelante|hacelo|hace|confirmo|confirmado|confirmar|afirmativo|por\s+supuesto|obvio|exacto|correcto|joya|barbaro|genial|segui|continua|llama|llamar|llamalo|llamala|enviar|envia\w*|manda\w*|mandalo|mandala)\b""")
    private val NO = Regex("""^(no|nono|nop|nunca|cancela\w*|mejor\s+no|dejalo|deja|olvidalo|para|basta|negativo|todavia\s+no|ahora\s+no)\b""")

    private fun cleanCallTarget(c: String): String =
        c.replace(Regex("(?i)\\s+(por|en|de|con|desde)\\s+(el\\s+|la\\s+)?(whatsapp|wasap|wsp|tel[eé]fono|celular|app|aplicaci[oó]n)\\b.*$"), "")
            .replace(Regex("(?i)\\s+(ahora|ya|por\\s+favor|porfa|urgente)$"), "").trim()

    private fun canonUnit(u: String): String = when {
        u.startsWith("kilomet") || u == "km" -> "km"
        u.startsWith("milla") -> "mi"
        u.startsWith("kilo") || u == "kg" -> "kg"
        u.startsWith("libra") -> "lb"
        u.startsWith("metro") -> "m"
        u.startsWith("pie") -> "ft"
        u.startsWith("litro") -> "l"
        u.startsWith("galon") -> "gal"
        u.contains("celsius") || u.contains("centigrad") -> "c"
        u.contains("fahrenheit") -> "f"
        else -> u
    }

    private fun unitName(u: String): String = when (u) {
        "km" -> "kilómetros"
        "mi" -> "millas"
        "kg" -> "kilos"
        "lb" -> "libras"
        "m" -> "metros"
        "ft" -> "pies"
        "l" -> "litros"
        "gal" -> "galones"
        "c" -> "grados Celsius"
        "f" -> "grados Fahrenheit"
        else -> u
    }

    private fun convert(v: Double, from: String, to: String): Double? {
        val f = mapOf("km-mi" to 0.621371, "kg-lb" to 2.20462, "m-ft" to 3.28084, "l-gal" to 0.264172)
        if (from == "c" && to == "f") return v * 9 / 5 + 32
        if (from == "f" && to == "c") return (v - 32) * 5 / 9
        f["$from-$to"]?.let { return v * it }
        f["$to-$from"]?.let { return v / it }
        return null
    }

    fun parse(text: String, ctx: Ctx): JSONObject? {
        val ot0 = text.replace(Regex("[¿?¡!,;.]"), " ").trim().split(Regex("\\s+")).filter { it.isNotEmpty() }
        if (ot0.isEmpty()) return null
        val cut = fillerCut(ot0.map { norm(it) })
        val ot1 = ot0.subList(cut.first, ot0.size - cut.second)
        val nt1 = ot1.map { SYNW[norm(it)] ?: norm(it) }.toMutableList()
        // "me anotes que...", "pongas una alarma": llevamos el verbo a imperativo (anota, pone).
        var drop = 0
        if (nt1.size > 1 && (nt1[0] == "me" || nt1[0] == "te") && SUBJ.containsKey(nt1[1])) drop = 1
        if (drop < nt1.size) SUBJ[nt1[drop]]?.let { nt1[drop] = it }
        val ot = ot1.subList(drop, ot1.size)
        val n = nt1.subList(drop, nt1.size).joinToString(" ")
        val d = digitize(n)
        val words = ot.size
        val dTokens = d.split(" ")
        val rt = if (dTokens.size == words) ot else dTokens

        fun sliceWith(tokens: List<String>, s: String, from: Int, to: Int): String {
            if (from >= to || from < 0 || to > s.length) return ""
            val a = s.substring(0, from).count { it == ' ' }
            val b = a + s.substring(from, to).count { it == ' ' } + 1
            return tokens.subList(a.coerceAtMost(tokens.size), b.coerceAtMost(tokens.size)).joinToString(" ")
        }
        fun sn(from: Int, to: Int) = sliceWith(ot, n, from, to)
        fun grp(m: MatchResult, i: Int): String {
            val g = m.groups[i] ?: return ""
            return sn(g.range.first, g.range.last + 1)
        }

        // --- respuestas a preguntas pendientes ---
        if (ctx.callActive && words <= 6) {
            if (YES.containsMatchIn(n)) return res("", "confirm_call")
            if (NO.containsMatchIn(n)) return res("", "cancel_call")
        }
        if (ctx.pendingSend && words <= 6) {
            if (YES.containsMatchIn(n)) return res("", "confirm_send")
            if (NO.containsMatchIn(n)) return res("Cancelado.", "cancel_send")
        }
        if (ctx.choiceCount > 0 && words <= 4) {
            if (Regex("""^(ninguno|ninguna|no|cancela\w*)\b""").containsMatchIn(n)) return res("Cancelado.", "cancel_send")
            val m = Regex("""\b(primer\w*|1|uno|segund\w*|2|tercer\w*|3|tres|cuart\w*|4|cuatro)\b""").find(d)
            if (m != null) {
                val t = m.value
                val opt = when {
                    t.startsWith("primer") || t == "1" || t == "uno" -> 1
                    t.startsWith("segund") || t == "2" -> 2
                    t.startsWith("tercer") || t == "3" || t == "tres" -> 3
                    else -> 4
                }
                if (opt <= ctx.choiceCount) return res("", "choose_contact").put("option", opt)
            }
        }

        // --- guía paso a paso en curso ---
        if (ctx.guideActive && words <= 4) {
            if (Regex("""^(siguiente|listo|ya|ya\s+esta|dale|si|segui\w*|continua\w*|adelante|ok|okey|hecho|empeza\w*|empecemos|vamos)$""").containsMatchIn(n))
                return res("", "guide_next").put("dir", "next")
            if (Regex("""^(repeti\w*|de\s+nuevo|otra\s+vez|no\s+entendi|como)$""").containsMatchIn(n))
                return res("", "guide_next").put("dir", "repeat")
            if (Regex("""^(salir|cancela\w*|termina\w*|basta|dejalo|para|no)$""").containsMatchIn(n))
                return res("", "guide_next").put("dir", "stop")
        }

        // --- diagnóstico, guías y ayuda ---
        if (Regex("""\b(revisa\w*|chequea\w*|verifica\w*|diagnostic\w*|autodiagnostic\w*)\b.*\b(permisos|todo|opciones|funciones)\b|\bque\s+(permisos\s+)?(te\s+)?falta\w*\b|\bque\s+tenes\s+(desactivado|apagado)\b|\brevisa\s+tus\s+permisos\b""").containsMatchIn(n))
            return res("", "diagnose")
        if (Regex("""\bpaso\s+a\s+paso\b|\bguiame\b|\bguia\b""").containsMatchIn(n) ||
            (Regex("""\bcomo\b""").containsMatchIn(n) && Regex("""\b(activ\w*|habilit\w*|permis\w*|configur\w*)\b""").containsMatchIn(n)))
            return res("", "guide").put("topic", n)
        if (Regex("""\bque\s+(podes|sabes|puedes)\s+hacer\b|\bque\s+sabes\s+hacer\b|\btus\s+(funciones|capacidades|comandos)\b|^ayuda$""").containsMatchIn(n))
            return res("", "help")

        if (Regex("""\b(dictame|dictar|modo\s+dictado)\b""").containsMatchIn(n))
            return res("", "dictation")

        // --- qué IA usó ---
        if (Regex("""\bque\s+(escuchaste|entendiste|oiste)\b|\brepeti\s+lo\s+que\s+(escuchaste|entendiste|dije)\b""").containsMatchIn(n))
            return res("", "last_heard")
        if (Regex("""\b(que|cual)\s+(ia|ai|ya|dia|dias|inteligencia\s+artificial|modelo|motor)\s+(usaste|usas|estas\s+usando|esta\s+usando|uso|respondio|te\s+respondio)\b|\bcon\s+(que|cual)\s+(ia|ai|ya|dia|dias|modelo)\s+(respondiste|me\s+respondiste|contestaste)\b|\bque\s+ia\s+(es|sos|usas)\b|\bestas\s+usando\s+(openrouter|gemini|github)\b|\b(anduvo|funciono)\s+(openrouter|gemini|github|la\s+ia|la\s+clave)\b""").containsMatchIn(n))
            return res("", "which_ai")

        // --- silenciar / reactivar un chat o grupo de WhatsApp ---
        if (ctx.muteActive && words <= 6) {
            val dd = parseMuteDuration(d)
            if (dd != null) return res("", "mute_chat").put("duration", dd)
            if (Regex("""^(cancela\w*|no|nada|dejalo|olvidalo)$""").containsMatchIn(n))
                return res("", "mute_chat").put("duration", "cancel")
        }
        Regex("""^(?:reactiva\w*|activa\w*|desilencia\w*|desmutea\w*)\s+(?:las\s+)?(?:notificaciones\s+)?(?:del\s+|de\s+la\s+|al\s+)?(?:ese\s+|este\s+|esa\s+|esta\s+)?(grupo|chat|conversacion)(?:\s+(?:de\s+|del\s+)?(.+))?$""").find(n)?.let {
            return res("", "mute_chat").put("name", grp(it, 2)).put("duration", "off")
        }
        if (Regex("""^(?:silencialo|silenciala|mutealo|mutea|silencia(?:me)?\s+(?:eso|esto|ese|este|esa|esta))$""").containsMatchIn(n))
            return res("", "mute_chat")
        Regex("""^(?:silencia\w*|mutea\w*|calla\w*)\s+(?:a\s+|al\s+|el\s+|la\s+)?(?:ese\s+|este\s+|esa\s+|esta\s+)?(grupo|chat|conversacion)(?:\s+(?:de\s+|del\s+)?(.+?))?(?:\s+(?:por|durante|para)\s+(.+))?$""").find(n)?.let {
            val name = grp(it, 2)
            val durTxt = it.groups[3]?.value ?: ""
            val r = res("", "mute_chat").put("name", name)
            parseMuteDuration(digitize(durTxt))?.let { dd -> r.put("duration", dd) }
            return r
        }

        // --- mirar la pantalla ---
        if (n.contains("pantalla") &&
            Regex("""\b(mira\w*|fijate|lee\w*|explica\w*|dime|decime|que\s+(hay|ves|dice|estoy)|resum\w*|contame|veme|ve)\b""").containsMatchIn(n) &&
            !Regex("""captura|pantallazo|bloque|apag|brillo|inicio|prend|rota""").containsMatchIn(n)
        ) {
            val read = Regex("""^(lee|leer|leeme)\b""").containsMatchIn(n) && !Regex("""explica|resum|decime|dime""").containsMatchIn(n)
            return res("", "read_screen").put("q", text).put("mode", if (read) "read" else "explain")
        }
        if (Regex("""\bque\s+estoy\s+viendo\b|\bexplicame\s+(esto|lo\s+que\s+(hay|veo|estoy\s+viendo))\b""").containsMatchIn(n))
            return res("", "read_screen").put("q", text).put("mode", "explain")

        // --- probar las IAs, resumir chats, clima, apodos, rutinas ---
        if (Regex("""\b(proba\w*|testea\w*|chequea\w*|revisa\w*|verifica\w*)\b.*\b(ias?|inteligencias?|openrouter|gemini|groq|cerebras|claves?\s+de\s+ia)\b""").containsMatchIn(n))
            return res("", "test_ai")
        if (Regex("""\b(borra\w*|elimina\w*|limpia\w*)\b.*\bhistorial\b.*\bmensajes\b""").containsMatchIn(n))
            return res("", "clear_history")
        val sumM = Regex("""\b(resum\w*|que\s+(?:paso|dijeron|escribieron|hablaron)|(?:ponme|pone)\s+al\s+dia)\b""").find(n)
        if (sumM != null && !n.contains("pantalla") && !n.contains("nota") && !n.contains("lista")) {
            val idx = n.substring(0, sumM.range.first).count { it == ' ' }
            val skip = sumM.value.count { it == ' ' } + 1
            val fl = Regex("""^(me|lo|que|paso|dijeron|escribieron|hablaron|en|el|la|los|las|de|del|grupo|chat|conversacion|mensajes|mis|ultimos|hoy|por|favor|un|una|todo|esto|resumen|y|ayer)$""")
            val toks = ot.drop(idx + skip).filter { !fl.containsMatchIn(norm(it)) }
            return res("", "summarize_chat").put("name", toks.joinToString(" "))
        }
        Regex("""\bmi\s+ciudad\s+es\s+(.+)$""").find(n)?.let { return res("", "set_city").put("name", grp(it, 1)) }
        if (Regex("""\b(clima|llover|lluvia|llueve|llovera|temperatura|pronostico|paraguas|hace\s+(frio|calor)|va\s+a\s+hacer\s+(frio|calor)|abrigo)\b""").containsMatchIn(n) &&
            !Regex("""hierve|ebullicion|congela|fusion|cuerpo|\bsol\b|celsius|fahrenheit""").containsMatchIn(n)) {
            val day = when {
                Regex("""pasado\s+manana""").containsMatchIn(n) -> "after"
                n.contains("manana") -> "tomorrow"
                else -> "today"
            }
            return res("", "weather").put("day", day)
        }
        val rel = "mama|madre|papa|padre|novia|novio|esposa|esposo|marido|mujer|hermano|hermana|hijo|hija|abuela|abuelo|tio|tia|primo|prima|jefe|jefa|amigo|amiga|suegra|suegro|cunado|cunada|nieto|nieta|socio|socia|vecino|vecina|ahijado|ahijada|padrino|madrina|pareja|ex"
        Regex("""^(.+?)\s+es\s+mi\s+($rel)$""").find(n)?.let {
            return res("", "alias_set").put("name", grp(it, 1)).put("alias", it.groupValues[2])
        }
        Regex("""^mi\s+($rel)\s+(?:es|se\s+llama)\s+(.+)$""").find(n)?.let {
            return res("", "alias_set").put("name", grp(it, 2)).put("alias", it.groupValues[1])
        }
        Regex("""^(?:borra\w*|olvida\w*)\s+(?:el\s+apodo\s+(?:de\s+)?)?mi\s+($rel)$""").find(n)?.let {
            return res("", "alias_del").put("alias", it.groupValues[1])
        }
        if (Regex("""\b(me\s+voy\s+a\s+dormir|modo\s+dormir|a\s+dormir|ya\s+me\s+duermo)\b""").containsMatchIn(n))
            return res("", "routine").put("name", "dormir")
        if (Regex("""\b(rutina\s+de\s+la\s+manana|modo\s+manana)\b""").containsMatchIn(n) ||
            (words <= 3 && Regex("""^buen(os)?\s+dias?$""").containsMatchIn(n)))
            return res("", "routine").put("name", "manana")
        Regex("""^(?:guarda\w*|crea\w*|arma\w*|registra\w*)\s+(?:la\s+|una\s+)?rutina\s+(?:llamada\s+)?(.+?)\s*(?::|que\s+(?:haga|active|ponga)|con|para)\s+(.+)$""").find(n)?.let {
            return res("", "routine_save").put("name", grp(it, 1)).put("commands", grp(it, 2))
        }
        Regex("""^(?:activa\w*|ejecuta\w*|inicia\w*|pone\w*|corre\w*|usa\w*)\s+(?:la\s+)?(?:rutina|modo)\s+(.+)$""").find(n)?.let {
            val nm = grp(it, 1)
            if (ctx.routines.contains(norm(nm))) return res("", "routine").put("name", nm)
        }
        if (ctx.routines.contains(n)) return res("", "routine").put("name", n)

        // --- describir lo que se ve en la pantalla (con imagen) ---
        if ((n.contains("pantalla") && Regex("""\b(describ\w*|que\s+ves|que\s+se\s+ve|que\s+(foto|imagen|dibujo|juego|video|meme)\s+(es|hay)|mira\w*.*\b(foto|imagen|meme|dibujo))\b""").containsMatchIn(n)) ||
            Regex("""^que\s+ves(\s+(ahi|aca|ahora))?$""").containsMatchIn(n))
            return res("", "describe_screen").put("q", text)

        // --- charla corta y cuentas ---
        if (words <= 3) {
            if (Regex("""^(hola|buenas|buen\s+dia|buenos\s+dias|buenas\s+tardes|buenas\s+noches|que\s+tal)$""").containsMatchIn(n))
                return res("Hola, jefe. ¿En qué te ayudo?", "none")
            if (Regex("""^(gracias|muchas\s+gracias|genial|perfecto)$""").containsMatchIn(n))
                return res("De nada, jefe.", "none")
        }
        if (Regex("""\b(quien\s+sos|quien\s+eres|como\s+te\s+llamas)\b""").containsMatchIn(n))
            return res("Soy Jarvis, tu asistente.", "none")
        if (Regex("""\b(cuanto\s+(es|da|son)|calcula\w*|resolve\w*)\b""").containsMatchIn(n)) {
            Regex("""(\d+(?:[.,]\d+)?)\s*(\+|mas|-|menos|\*|x|por|/|dividido(?:\s+por)?|entre)\s*(\d+(?:[.,]\d+)?)""").find(d)?.let {
                val a = it.groupValues[1].replace(',', '.').toDouble()
                val b = it.groupValues[3].replace(',', '.').toDouble()
                val op = it.groupValues[2]
                val r = when {
                    op == "+" || op == "mas" -> a + b
                    op == "-" || op == "menos" -> a - b
                    op == "*" || op == "x" || op == "por" -> a * b
                    else -> if (b == 0.0) return res("No se puede dividir por cero.", "none") else a / b
                }
                val txt = if (r == Math.floor(r) && Math.abs(r) < 1e12) r.toLong().toString()
                else String.format(Locale("es", "AR"), "%.2f", r)
                return res("Da $txt.", "none")
            }
        }

        // --- música y video: pausar, seguir, saltar ---
        if (Regex("""\b(pausa\w*|deten\w*)\b.*\b(musica|cancion|video|reproduccion)\b""").containsMatchIn(n))
            return res("", "media").put("cmd", "pause")
        if (Regex("""\b(reanuda\w*|continua\w*|segui\w*)\b.*\b(musica|cancion|video|reproduccion)\b""").containsMatchIn(n))
            return res("", "media").put("cmd", "play")
        if (Regex("""\b(siguiente|proxim\w*)\s+(cancion|tema)\b|\bpasa\w*\s+(la\s+)?(cancion|tema)\b|\bsalta\w*\s+(la\s+)?(cancion|tema)\b""").containsMatchIn(n))
            return res("", "media").put("cmd", "next")
        if (Regex("""\b(anterior|previa)\s+(cancion|tema)\b|\bvolve\w*\s+a\s+la\s+(cancion|tema)\s+anterior\b""").containsMatchIn(n))
            return res("", "media").put("cmd", "previous")

        // --- Wi-Fi, Bluetooth, datos, modo avión ---
        Regex("""\b(prend|activ|apag|desactiv|encend|habilit)\w*\s+(el\s+|la\s+)?(wifi|wi-fi|wi\s+fi|bluetooth|datos\s+moviles|datos|modo\s+avion|nfc)\b""").find(n)?.let {
            val w = it.groupValues[3]
            val what = when {
                w.contains("bluetooth") -> "bluetooth"
                w.contains("avion") -> "airplane"
                w == "nfc" -> "nfc"
                else -> "wifi"
            }
            return res("", "connectivity").put("what", what)
        }

        // --- manos libres ---
        if (n.contains("manos libres")) {
            if (Regex("""desactiv|apag|paus|deshabilit|saca""").containsMatchIn(n))
                return res("Manos libres desactivado.", "handsfree").put("on", false)
            if (Regex("""activ|prend|habilit|encend""").containsMatchIn(n))
                return res("Manos libres activado.", "handsfree").put("on", true)
        }

        // --- cerrar app, sistema ---
        if (Regex("""\b(cerr\w*|mata\w*|sali\w*\s+de)\s+(esta\s+|la\s+)?(app|aplicacion)\b|\bcerr\w*\s+esto\b""").containsMatchIn(n))
            return res("Cerrando.", "close_app")
        if (Regex("""\b(captura|pantallazo|screenshot)\b""").containsMatchIn(n))
            return res("Capturando.", "system").put("which", "screenshot")
        if (Regex("""\bbloque\w*\s+(el\s+|la\s+)?(telefono|celular|pantalla)\b|\bapag\w*\s+la\s+pantalla\b""").containsMatchIn(n))
            return res("", "system").put("which", "lock")
        if (Regex("""\b(anda|volve|ir|vamos|volver)\s+(a\s+|al\s+)?(inicio|pantalla\s+de\s+inicio|home)\b""").containsMatchIn(n))
            return res("", "system").put("which", "home")
        if (Regex("""\bvolve\w*\s+(para\s+)?atras\b""").containsMatchIn(n))
            return res("", "system").put("which", "back")

        // --- correos y agenda ---
        if (Regex("""\b(lee|leer|leeme|decime|dime|mostra\w*)\w*\b.*\b(mails?|correos?|emails?|e-mails?|gmail)\b|\b(tengo|hay)\s+(mails?|correos?|emails?)\s+(nuevos?|sin\s+leer)\b""").containsMatchIn(n))
            return res("", "read_mail")
        if (Regex("""\bque\s+tengo\s+(para\s+)?(hoy|manana|esta\s+semana)\b|\btengo\s+algo\s+(hoy|manana)\b|\bque\s+tengo\s+(agendado|programado)\b|\bque\s+hay\s+(hoy|manana)\b|\beventos\s+de\s+(hoy|manana)\b|\bmi\s+calendario\b|\bmi\s+agenda\b|\bque\s+eventos\s+tengo\b|\bagenda\s+de\s+(hoy|manana)\b|\bque\s+tengo\s+en\s+(el\s+)?calendario\b|\bque\s+hay\s+en\s+(mi\s+)?agenda\b""").containsMatchIn(n)) {
            val day = when {
                n.contains("manana") -> "tomorrow"
                n.contains("semana") -> "week"
                else -> "today"
            }
            return res("", "agenda").put("day", day)
        }

        // --- notificaciones, mensajes, audios ---
        if (Regex("""\b(lee|leer|leeme|decime|dime|cuales|que)\w*\b.*\bnotificacion""").containsMatchIn(n))
            return res("", "read_notifications")
        if (Regex("""\babr\w*\s+(el\s+)?(panel|las\s+notificaciones)""").containsMatchIn(n))
            return res("", "system").put("which", "notifications")
        if (Regex("""\b(reproduc\w*|escucha\w*|pone\w*|pasa\w*)\s+(el\s+|la\s+)?(audio|nota\s+de\s+voz|mensaje\s+de\s+voz)\b""").containsMatchIn(n))
            return res("", "play_voice_note")
        Regex("""\b(lee|leer|leeme|decime|dime|contame)\w*\s+(los\s+|mis\s+)?(ultimos\s+|nuevos\s+)?mensajes(?:\s+de\s+(.+))?$""").find(n)?.let {
            return res("", "read_messages").put("contact", grp(it, 4))
        }
        if (Regex("""\b(aprend|actualiz|escanea)\w*\s+(mis\s+|todos\s+mis\s+|los\s+)?chats\b""").containsMatchIn(n))
            return res("", "scan_chats")

        // --- linterna, no molestar, cámara ---
        if (Regex("""\b(linterna|flash|lampara|luz\s+del\s+(celu|celular|telefono))\b""").containsMatchIn(n)) {
            val off = Regex("""apag|desactiv|saca|quita""").containsMatchIn(n)
            return res(if (off) "Linterna apagada." else "Linterna encendida.", "flashlight").put("on", !off)
        }
        if (n.contains("no molestar")) {
            val off = Regex("""desactiv|apag|saca|quita""").containsMatchIn(n)
            return res("", "dnd").put("on", !off)
        }
        if (Regex("""\bcamara\b""").containsMatchIn(n) && Regex("""abr|prend|activ|saca|toma|hace""").containsMatchIn(n))
            return res("", "camera")
        if (Regex("""\b(saca\w*|toma\w*|hace\w*)\s+(una\s+)?foto\b""").containsMatchIn(n))
            return res("", "camera")

        // --- alarmas ---
        if (Regex("""\b(abr\w*|mostra\w*|ver|anda\w*\s+a)\s+(las\s+|mis\s+)?alarmas\b""").containsMatchIn(n))
            return res("", "alarm_list")
        run {
            val offStem = Regex("""\b(borr|elimin|cancel|sac|quit|apag|desactiv|anul|descart|silenci)\w*""")
            val setVerb = Regex("""\b(pon|pone|poner|program|configur|cre|agreg|fij)\w*""")
            val hasAlarm = Regex("""\balarmas?\b""").containsMatchIn(n)
            val refers = hasAlarm || Regex("""\b(la|esa|esta)\s+de\s+las?\s+\d""").containsMatchIn(d)
            val noQuiero = Regex("""\bno\s+(la\s+)?(quiero|necesito)\b|\bya\s+no\b""").containsMatchIn(n)
            if (refers && (offStem.containsMatchIn(n) || (hasAlarm && noQuiero)) && !setVerb.containsMatchIn(n)) {
                val c = parseClock(d)
                if (c == null && Regex("""\btodas\b|\balarmas\b""").containsMatchIn(n)) return res("", "alarm_list")
                val r = res("", "alarm_off")
                if (c != null) r.put("hour", c.first).put("minute", c.second)
                return r
            }
        }

        // --- recordatorios ---
        val remVerb = Regex("""^(recorda|recuerda|avisa)\w*""")
        val remIdx = dTokens.indexOfFirst { remVerb.containsMatchIn(it) && !it.startsWith("recordatorio") }
        if (remIdx >= 0 && !Regex("""^(acordate|acuerdate)""").containsMatchIn(n)) {
            val clock = parseClock(d)
            val dur = durationSeconds(d)
            if (clock != null || dur != null) {
                val start = Calendar.getInstance()
                val phrase: IntRange
                if (dur != null && (clock == null || dur.second.first < clock.third.first)) {
                    start.add(Calendar.SECOND, dur.first)
                    phrase = dur.second
                } else {
                    val (h, m, r) = clock!!
                    start.set(Calendar.HOUR_OF_DAY, h)
                    start.set(Calendar.MINUTE, m)
                    start.set(Calendar.SECOND, 0)
                    if (start.timeInMillis <= System.currentTimeMillis()) start.add(Calendar.DAY_OF_YEAR, 1)
                    phrase = r
                }
                val a = d.substring(0, phrase.first).count { it == ' ' }
                val b = a + d.substring(phrase.first, phrase.last + 1).count { it == ' ' } + 1
                val keep = rt.filterIndexed { i, _ -> i != remIdx && (i < a || i >= b) }
                var txt = keep.joinToString(" ")
                txt = txt.replace(Regex("""^(?i)(que|de|para|a|de que)\s+"""), "").trim()
                if (txt.isEmpty()) txt = "Recordatorio"
                val iso = SimpleDateFormat("yyyy-MM-dd'T'HH:mm", Locale.US).format(start.time)
                val hh = SimpleDateFormat("HH:mm", Locale.US).format(start.time)
                return res("Listo, te aviso a las $hh.", "reminder").put("text", txt).put("start", iso)
            }
        }

        // --- alarma / temporizador ---
        val wantsAlarm = Regex("""\balarma\b|\bdespert\w*|\blevantar(me)?\b|\bavisame\s+para\s+levantar""").containsMatchIn(n)
        val wantsTimer = Regex("""\b(timer|temporizador|cronometro|cuenta\s+regresiva)\b""").containsMatchIn(n)
        if (wantsTimer) {
            val dur = durationSeconds(d) ?: return null
            return res("Temporizador listo.", "timer").put("seconds", dur.first).put("label", "Jarvis")
        }
        if (wantsAlarm) {
            val clock = parseClock(d)
            if (clock != null) {
                val hh = String.format(Locale.US, "%02d:%02d", clock.first, clock.second)
                return res("Alarma a las $hh.", "alarm").put("hour", clock.first).put("minute", clock.second).put("label", "Jarvis")
            }
            val dur = durationSeconds(d)
            if (dur != null) {
                if (dur.first < 60) return res("Temporizador listo.", "timer").put("seconds", dur.first).put("label", "Jarvis")
                val c = Calendar.getInstance()
                c.add(Calendar.SECOND, dur.first)
                val hh = String.format(Locale.US, "%02d:%02d", c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE))
                return res("Alarma a las $hh.", "alarm")
                    .put("hour", c.get(Calendar.HOUR_OF_DAY)).put("minute", c.get(Calendar.MINUTE)).put("label", "Jarvis")
            }
            return null
        }

        // --- volumen y brillo ---
        if (n.contains("volumen") || Regex("""\b(sonido|silencia|mutea)\w*\b""").containsMatchIn(n)) {
            Regex("""volumen\s+(?:al|a|en)\s+(\d+)""").find(d)?.let {
                return res("", "volume").put("mode", "level").put("percent", it.groupValues[1].toInt().coerceIn(0, 100))
            }
            if (Regex("""maximo|a\s+fondo""").containsMatchIn(n)) return res("", "volume").put("mode", "max")
            if (Regex("""desmutea|quita\w*\s+el\s+silencio|activa\w*\s+(el\s+)?sonido""").containsMatchIn(n))
                return res("", "volume").put("mode", "unmute")
            if (Regex("""silencia|mutea|sin\s+sonido""").containsMatchIn(n)) return res("", "volume").put("mode", "mute")
            if (Regex("""\bsub\w*|aument\w*|alza\w*|mas\s+fuerte|mas\s+alto""").containsMatchIn(n)) return res("", "volume").put("mode", "up")
            if (Regex("""\bbaj\w*|disminuy\w*|mas\s+bajo|menos""").containsMatchIn(n)) return res("", "volume").put("mode", "down")
        }
        if (n.contains("brillo") || n.contains("luminosidad")) {
            if (Regex("""\bmitad\b""").containsMatchIn(n)) return res("", "brightness").put("percent", 50)
            Regex("""brillo\s+(?:al|a|en)\s+(\d+)""").find(d)?.let {
                val p = it.groupValues[1].toInt().coerceIn(1, 100)
                return res("Brillo al $p por ciento.", "brightness").put("percent", p)
            }
            if (Regex("""maximo""").containsMatchIn(n)) return res("", "brightness").put("percent", 100)
            if (Regex("""minimo""").containsMatchIn(n)) return res("", "brightness").put("percent", 5)
            if (Regex("""medio""").containsMatchIn(n)) return res("", "brightness").put("percent", 50)
            if (Regex("""\bsub\w*|aument\w*|mas\s+brillo""").containsMatchIn(n)) return res("", "brightness").put("percent", 80)
            if (Regex("""\bbaj\w*|disminuy\w*|menos\s+brillo""").containsMatchIn(n)) return res("", "brightness").put("percent", 30)
        }

        // --- listas ---
        Regex("""^(?:saca\w*|borra\w*|quita\w*|elimina\w*)\s+(.+?)\s+de\s+(?:la\s+|mi\s+)?lista(?:\s+de(?:l)?\s+(.+))?$""").find(n)?.let {
            val items = grp(it, 1).split(Regex("""\s+y\s+|\s+e\s+""")).map { s -> s.trim() }.filter { s -> s.isNotEmpty() }
            val list = grp(it, 2).ifEmpty { "compras" }
            return res("", "list_remove").put("list", list).put("items", JSONArray(items))
        }
        Regex("""^(?:vacia\w*|borra\w*|limpia\w*|elimina\w*)\s+(?:la\s+|mi\s+|toda\s+la\s+)?lista(?:\s+de(?:l)?\s+(.+))?$""").find(n)?.let {
            return res("", "list_remove").put("list", grp(it, 1).ifEmpty { "compras" })
        }
        Regex("""^(?:agrega\w*|anota\w*|suma\w*|pone\w*|mete\w*|anade\w*)\s+(.+?)\s+(?:a|en)\s+(?:la\s+|mi\s+)?lista(?:\s+de(?:l)?\s+(.+))?$""").find(n)?.let {
            val items = grp(it, 1).split(Regex("""\s+y\s+|\s+e\s+""")).map { s -> s.trim() }.filter { s -> s.isNotEmpty() }
            if (items.isNotEmpty()) {
                val list = grp(it, 2).ifEmpty { "compras" }
                return res("Agregado.", "list_add").put("list", list).put("items", JSONArray(items))
            }
        }
        Regex("""^(?:lee\w*|decime|dime|mostra\w*|cual\s+es|que\s+hay\s+en)\s+(?:la\s+|mi\s+)?lista(?:\s+de(?:l)?\s+(.+))?$""").find(n)?.let {
            return res("", "list_read").put("list", grp(it, 1).ifEmpty { "compras" })
        }

        // --- memoria ---
        if (Regex("""\bque\s+(recordas|recuerdas|sabes\s+de\s+mi|tenes\s+(guardado|anotado)(\s+de\s+mi)?)\b""").containsMatchIn(n))
            return res("", "memory_read")
        if (Regex("""^(?:borra\w*|elimina\w*|limpia\w*|olvida\w*)\s+(?:toda\s+|todo\s+)?(?:la\s+|tu\s+|mi\s+)?(?:memoria|todo)$""").containsMatchIn(n))
            return res("", "memory_clear")
        Regex("""^(?:borra\w*|elimina\w*|saca\w*)\s+(?:eso|lo\s+ultimo|lo\s+anterior|ese\s+recuerdo)(?:\s+de\s+(?:la\s+|tu\s+)?memoria)?$""").find(n)?.let {
            return res("", "forget").put("text", "")
        }
        Regex("""^(?:guarda\w*|anota\w*)\s+en\s+(?:tu\s+|la\s+)?memoria\s+(?:que\s+)?(.+)$|^(?:tene|ten)\s+en\s+cuenta\s+(?:que\s+)?(.+)$""").find(n)?.let { m ->
            val t = if (m.groups[1] != null) grp(m, 1) else grp(m, 2)
            if (t.length >= 2) return res("Anotado.", "remember").put("text", t)
        }

        Regex("""^(?:acordate|acuerdate|recorda|recuerda)\s+(?:de\s+)?que\s+(.+)$""").find(n)?.let {
            return res("Anotado.", "remember").put("text", grp(it, 1))
        }
        Regex("""^(?:olvidate|olvida)\s+(?:de\s+)?(.+)$""").find(n)?.let {
            return res("", "forget").put("text", grp(it, 1))
        }

        // --- notas ---
        Regex("""\b(borra\w*|elimina\w*|saca\w*|quita\w*)\s+(la\s+|las\s+|todas\s+las\s+|mis\s+)?(ultima\s+)?(nota|notas)\b""").find(n)?.let {
            val which = if (it.value.contains("ultima")) "last"
            else if (it.value.contains("todas") || it.value.endsWith("notas")) "all" else "last"
            return res("", "note_delete").put("which", which)
        }
        Regex("""\b(lee\w*|decime|dime|cuales\s+son|mostra\w*)\s+(la\s+|mis\s+|las\s+)?(ultima\s+)?(nota|notas)\b""").find(n)?.let {
            return res("", "note_read").put("which", if (it.value.contains("ultima")) "last" else "all")
        }
        Regex("""^(?:nota|notas)\s*(?::|de\s+|que\s+)\s*(.+)$""").find(n)?.let {
            val t = grp(it, 1)
            if (t.length >= 2) return res("Anotado.", "note_add").put("text", t)
        }
        Regex("""^nota\s+(.+)$""").find(n)?.let {
            val t = grp(it, 1)
            if (t.length >= 2) return res("Anotado.", "note_add").put("text", t)
        }

        // --- notas (todas las formas de decirlo) ---
        Regex("""^(?:agrega\w*|crea\w*|hace\w*|escribi\w*|deja\w*|guarda\w*|anota\w*|apunta\w*|pone\w*|tom\w*|nueva)\s+(?:me\s+)?(?:una\s+|la\s+)?nota\b\s*(?:de\s+|que\s+|diciendo\s+|que\s+diga\s+|:)?\s*(.+)$""").find(n)?.let {
            val t = grp(it, 1)
            if (t.length >= 2) return res("Anotado.", "note_add").put("text", t)
        }
        Regex("""^(?:anota\w*|apunta\w*)\s+(?:que\s+|de\s+)?(.+)$""").find(n)?.let {
            val t = grp(it, 1)
            if (t.length >= 2) return res("Anotado.", "note_add").put("text", t)
        }

        // --- mini charla sin internet ---
        val rnd = kotlin.random.Random
        if (Regex("""\bcomo\s+(estas|andas|te\s+va|te\s+sentis|va\s+todo)\b""").containsMatchIn(n))
            return res(listOf("Todo bien, jefe. ¿Y vos?", "Muy bien, listo para ayudarte. ¿Y vos cómo andás?", "Funcionando al cien. ¿Qué necesitás?").random(), "none")
        if (Regex("""\b(chiste|chistecito|haceme\s+reir|hacerme\s+reir)\b""").containsMatchIn(n))
            return res(
                listOf(
                    "¿Qué hace una abeja en el gimnasio? ¡Zumba!",
                    "¿Cómo se despiden los químicos? Ácido un placer.",
                    "¿Por qué el libro de matemáticas está triste? Porque tiene muchos problemas.",
                    "¿Qué le dice un cero a un ocho? Lindo cinturón.",
                    "¿Cuál es el café más peligroso del mundo? El ex preso.",
                    "¿Qué hace un perro con un taladro? Taladrando.",
                    "¿Por qué los pájaros vuelan al sur? Porque caminando tardarían mucho."
                ).random(), "none"
            )
        if (Regex("""\b(dato\s+curioso|contame\s+algo|decime\s+algo\s+(curioso|interesante))\b""").containsMatchIn(n))
            return res(
                listOf(
                    "Los pulpos tienen tres corazones.",
                    "La miel no se echa a perder: encontraron miel comestible en tumbas egipcias.",
                    "Un día en Venus dura más que un año en Venus.",
                    "Las bananas son bayas, pero las frutillas no.",
                    "La Torre Eiffel puede crecer unos quince centímetros en verano por el calor.",
                    "Las abejas pueden reconocer rostros humanos."
                ).random(), "none"
            )
        if (Regex("""\b(frase|motivame|animame|dame\s+animo)\b""").containsMatchIn(n))
            return res(
                listOf(
                    "Un paso por día también es avanzar, jefe.",
                    "Lo difícil de hoy es la comodidad de mañana.",
                    "No tenés que hacerlo perfecto, tenés que empezar.",
                    "Cada error te deja una lección que te acerca al resultado."
                ).random(), "none"
            )
        if (Regex("""\b(cara\s+o\s+ceca|tira\w*\s+una\s+moneda)\b""").containsMatchIn(n))
            return res(if (rnd.nextBoolean()) "Salió cara." else "Salió ceca.", "none")
        if (Regex("""\btira\w*\s+(un\s+)?dado\b""").containsMatchIn(n))
            return res("Salió el ${rnd.nextInt(1, 7)}.", "none")
        Regex("""\bnumero\s+(?:al\s+azar|aleatorio)\s+entre\s+(\d+)\s+y\s+(\d+)""").find(d)?.let {
            val a = it.groupValues[1].toInt()
            val b = it.groupValues[2].toInt()
            if (b > a) return res("Te salió el ${rnd.nextInt(a, b + 1)}.", "none")
        }
        if (Regex("""\bestoy\s+(aburrid\w*|sin\s+nada\s+que\s+hacer)\b""").containsMatchIn(n))
            return res("¿Querés un chiste, un dato curioso o que te ponga música? Decime.", "none")
        if (Regex("""^(chau|chao|adios|hasta\s+luego|nos\s+vemos)\b""").containsMatchIn(n))
            return res("Hasta luego, jefe.", "none")
        if (Regex("""\b(sos\s+genial|buen\s+trabajo|te\s+quiero|sos\s+un\s+crack|que\s+bien\s+funcionas)\b""").containsMatchIn(n))
            return res("Gracias, jefe. Para eso estoy.", "none")
        Regex("""\bque\s+dia\s+(?:sera|va\s+a\s+ser|es)\s+(?:dentro\s+de|en)\s+(\d+)\s+dias?\b""").find(d)?.let {
            val c = Calendar.getInstance()
            c.add(Calendar.DAY_OF_YEAR, it.groupValues[1].toInt())
            return res("Va a ser " + SimpleDateFormat("EEEE d 'de' MMMM", Locale("es", "AR")).format(c.time) + ".", "none")
        }
        Regex("""(\d+(?:[.,]\d+)?)\s*(kilometros?|km|millas?|kilos?|kg|libras?|metros?|pies|litros?|galones?|grados\s+celsius|celsius|centigrados|grados\s+fahrenheit|fahrenheit)\s+(?:a|en)\s+(kilometros?|km|millas?|kilos?|kg|libras?|metros?|pies|litros?|galones?|celsius|centigrados|fahrenheit)\b""").find(d)?.let {
            val v = it.groupValues[1].replace(',', '.').toDouble()
            val from = canonUnit(it.groupValues[2])
            val to = canonUnit(it.groupValues[3])
            val r = convert(v, from, to)
            if (r != null) {
                val txt = if (r == Math.floor(r)) r.toLong().toString() else String.format(Locale("es", "AR"), "%.2f", r)
                return res("${it.groupValues[1]} ${unitName(from)} son $txt ${unitName(to)}.", "none")
            }
        }

        // --- agendar un evento ---
        Regex("""^(?:agend\w*|programa\w*|crea\w*\s+(?:un\s+)?evento|(?:pone\w*|anota\w*|agrega\w*)\s+(?:un\s+|una\s+)?(?:evento|reunion|cita|turno))\s+(.+)$""").find(d)?.let { m ->
            val restStart = m.groups[1]!!.range.first
            val ranges = ArrayList<IntRange>()
            ranges.add(0 until restStart)
            var s = d
            Regex("""\ben\s+(?:el\s+|mi\s+)?(?:calendario|agenda)\b""").findAll(s).forEach { ranges.add(it.range) }
            val clock = parseClock(s)
            if (clock != null) {
                ranges.add(clock.third)
                s = s.replaceRange(clock.third.first, clock.third.last + 1, " ".repeat(clock.third.last - clock.third.first + 1))
            }
            val cal = Calendar.getInstance()
            cal.set(Calendar.HOUR_OF_DAY, 0); cal.set(Calendar.MINUTE, 0); cal.set(Calendar.SECOND, 0); cal.set(Calendar.MILLISECOND, 0)
            var dateFound = false
            val days = listOf("domingo", "lunes", "martes", "miercoles", "jueves", "viernes", "sabado")
            val months = listOf("enero", "febrero", "marzo", "abril", "mayo", "junio", "julio", "agosto", "septiembre", "octubre", "noviembre", "diciembre")
            Regex("""\bpasado\s+manana\b""").find(s)?.let { cal.add(Calendar.DAY_OF_YEAR, 2); ranges.add(it.range); dateFound = true }
            if (!dateFound) Regex("""\bmanana\b""").find(s)?.let { cal.add(Calendar.DAY_OF_YEAR, 1); ranges.add(it.range); dateFound = true }
            if (!dateFound) Regex("""\bhoy\b""").find(s)?.let { ranges.add(it.range); dateFound = true }
            if (!dateFound) Regex("""\b(?:el\s+)?(domingo|lunes|martes|miercoles|jueves|viernes|sabado)\b""").find(s)?.let {
                val target = days.indexOf(it.groupValues[1]) + 1
                var delta = (target - cal.get(Calendar.DAY_OF_WEEK) + 7) % 7
                if (delta == 0) delta = 7
                cal.add(Calendar.DAY_OF_YEAR, delta)
                ranges.add(it.range)
                dateFound = true
            }
            if (!dateFound) Regex("""\bel\s+(\d{1,2})(?:\s+de\s+(enero|febrero|marzo|abril|mayo|junio|julio|agosto|septiembre|octubre|noviembre|diciembre))?\b""").find(s)?.let {
                val dom = it.groupValues[1].toInt()
                val mon = it.groupValues[2]
                if (dom in 1..31) {
                    if (mon.isNotEmpty()) {
                        cal.set(Calendar.MONTH, months.indexOf(mon))
                        cal.set(Calendar.DAY_OF_MONTH, dom)
                        if (cal.timeInMillis < System.currentTimeMillis() - 86400000L) cal.add(Calendar.YEAR, 1)
                    } else {
                        if (dom < cal.get(Calendar.DAY_OF_MONTH)) cal.add(Calendar.MONTH, 1)
                        cal.set(Calendar.DAY_OF_MONTH, dom)
                    }
                    ranges.add(it.range)
                    dateFound = true
                }
            }
            if (dateFound || clock != null) {
                val allDay = clock == null
                if (clock != null) {
                    cal.set(Calendar.HOUR_OF_DAY, clock.first)
                    cal.set(Calendar.MINUTE, clock.second)
                    if (!dateFound && cal.timeInMillis <= System.currentTimeMillis()) cal.add(Calendar.DAY_OF_YEAR, 1)
                }
                // título: lo que queda sin la fecha, la hora y las palabras de agenda
                val toks = d.split(" ")
                val keep = ArrayList<String>()
                var pos = 0
                val src = if (toks.size == words) ot else toks
                for ((i, t) in toks.withIndex()) {
                    val a = pos
                    val b = pos + t.length - 1
                    if (ranges.none { r -> a >= r.first && b <= r.last }) keep.add(src[i])
                    pos += t.length + 1
                }
                val connectors = setOf("un", "una", "el", "la", "de", "para", "que", "a", "en", "mi", "el")
                while (keep.isNotEmpty() && keep.first().lowercase() in connectors) keep.removeAt(0)
                while (keep.isNotEmpty() && keep.last().lowercase() in connectors) keep.removeAt(keep.size - 1)
                var title = keep.joinToString(" ").trim()
                if (title.isEmpty()) title = "Evento"
                title = title.replaceFirstChar { it.uppercase() }
                val iso = SimpleDateFormat("yyyy-MM-dd'T'HH:mm", Locale.US).format(cal.time)
                return res("", "calendar").put("title", title).put("start", iso).put("minutes", 60).put("allday", allDay)
            }
        }

        // --- hora, fecha, batería ---
        if (Regex("""\bque\s+hora\s+es\b|\bhora\s+actual\b|\bdecime\s+la\s+hora\b""").containsMatchIn(n)) {
            val t = SimpleDateFormat("HH:mm", Locale.US).format(Date())
            return res("Son las $t.", "none")
        }
        if (Regex("""\bque\s+dia\s+es\b|\bque\s+fecha\b|\bfecha\s+de\s+hoy\b""").containsMatchIn(n)) {
            val t = SimpleDateFormat("EEEE d 'de' MMMM", Locale("es", "AR")).format(Date())
            return res("Hoy es $t.", "none")
        }
        if (n.contains("bateria") && Regex("""cuanta|nivel|porcentaje|que\s+tanto|como\s+(esta|anda)""").containsMatchIn(n)) {
            return res("Tenés ${ctx.batteryPct} por ciento de batería${if (ctx.charging) ", cargando" else ""}.", "none")
        }

        // --- llamar y escribir ---
        Regex("""^(?:escribi\w*|mandale|mandar|manda|enviale|envia\w*|decile|dile|avisale|contestale|respondele|comentale|pasale)\s+(?:un\s+)?(?:mensaje\s+|whatsapp\s+|wasap\s+)?(?:a\s+|al\s+|para\s+)?(.+?)\s+(?:diciendo|que\s+diga|que\s+dice|que\s+ponga|que\s+le\s+diga|que)\s+(.+)$""").find(n)?.let {
            val contact = grp(it, 1)
            val msg = grp(it, 2)
            if (contact.isNotEmpty() && msg.isNotEmpty()) return res("", "send_whatsapp").put("contact", contact).put("text", msg)
        }
        Regex("""^(?:llama|llamar|llamale|marca|marcale|comunicame\s+con|ponme\s+con|hablale\s+a|tirale\s+un\s+llamado\s+a|contactame\s+con)\s+(?:a\s+|al\s+|a\s+la\s+)?(.+)$""").find(n)?.let {
            val c = cleanCallTarget(grp(it, 1))
            if (c.isNotEmpty()) return res("", "call").put("contact", c)
        }

        // --- cultura general ---
        knowledge(n)?.let { return res(it, "none") }

        // --- música y apps ---
        Regex("""^(?:pone\w*|reproduc\w*|pasa\w*|escuchar|quiero\s+escuchar)\s+(?:musica\s+de\s+|musica\s+|la\s+cancion\s+|el\s+tema\s+|un\s+tema\s+de\s+|un\s+tema\s+|algo\s+de\s+)(.+)$""").find(n)?.let {
            return res("", "play_music").put("query", grp(it, 1))
        }
        Regex("""^(?:busca\w*|buscame)\s+(.+?)\s+en\s+(youtube|spotify|maps|google\s+maps|mapas)$""").find(n)?.let {
            val app = when (it.groupValues[2]) {
                "youtube" -> "YouTube"
                "spotify" -> "Spotify"
                else -> "Maps"
            }
            return res("", "open_app").put("app", app).put("query", grp(it, 1))
        }
        Regex("""^(?:abr\w*|lanz\w*|inici\w*|ejecut\w*)\s+(?:(?:la|el)\s+)?(?:(?:app|aplicacion)\s+)?(?:de\s+)?(.+)$""").find(n)?.let {
            val app = grp(it, 1)
            if (app.isNotEmpty() && app.split(" ").size <= 3) return res("", "open_app").put("app", app)
        }

        // --- comprensión flexible: palabras clave sueltas, sin frase exacta ---
        run {
            val fluff = Regex("""^(pone\w*|poner|agrega\w*|crea\w*|hace\w*|escribi\w*|deja\w*|guarda\w*|anota\w*|apunta\w*|nota|notas|una|un|la|el|que|diga|dice|de|sobre|en|esto|lo|siguiente|nueva|mi|mis|me|por|favor|a|para|tom\w*)$""")
            val noteVerb = Regex("""\b(pone\w*|poner|agrega\w*|crea\w*|hace\w*|escribi\w*|deja\w*|guarda\w*|anota\w*|apunta\w*|tom\w*)\b""").containsMatchIn(n)
            if (Regex("""\b(nota|anota\w*|apunta\w*)\b""").containsMatchIn(n) && noteVerb &&
                !Regex("""\b(borra\w*|lee\w*|leer|mostra\w*|cuantas|ultima|todas|elimina\w*)\b""").containsMatchIn(n)) {
                val toks = ot.toMutableList()
                while (toks.isNotEmpty() && fluff.containsMatchIn(norm(toks.first()))) toks.removeAt(0)
                while (toks.isNotEmpty() && fluff.containsMatchIn(norm(toks.last()))) toks.removeAt(toks.size - 1)
                if (toks.size >= 2) return res("Anotado.", "note_add").put("text", toks.joinToString(" "))
            }
            val callM = Regex("""\b(llam\w*|marc\w*|comunic\w*|contactame)\b""").find(n)
            if (callM != null && !Regex("""\b(mensaje|whatsapp|escrib\w*|mand\w*|envi\w*|agrega\w*|nuevo|guarda\w*|borra\w*|abri\w*|numero)\b""").containsMatchIn(n)) {
                val idx = n.substring(0, callM.range.first).count { it == ' ' }
                val prep = Regex("""^(a|al|con|le|lo|la|me|por|para|telefono|celular|whatsapp|favor|ahora|ya|pronto|un|una)$""")
                val toks = ot.drop(idx + 1).toMutableList()
                while (toks.isNotEmpty() && prep.containsMatchIn(norm(toks.first()))) toks.removeAt(0)
                while (toks.isNotEmpty() && prep.containsMatchIn(norm(toks.last()))) toks.removeAt(toks.size - 1)
                if (toks.isNotEmpty() && toks.size <= 4) return res("", "call").put("contact", toks.joinToString(" "))
            }
            if (ctx.apps.isNotEmpty()) {
                val verb = Regex("""\b(abr\w*|lanz\w*|inici\w*|entr\w*|ejecut\w*|vamos\s+a|ir\s+a|anda\s+a|ingres\w*)\b""").containsMatchIn(n)
                val hit = ctx.apps.filter { Regex("""\b""" + Regex.escape(it) + """\b""").containsMatchIn(n) }.maxByOrNull { it.length }
                if (hit != null && (verb || n == hit)) return res("", "open_app").put("app", hit)
            }
        }

        return null
    }
}
