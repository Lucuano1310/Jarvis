package com.jarvis.app

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("jarvis", MODE_PRIVATE)
        val pad = (24 * resources.displayMetrics.density).toInt()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }
        val wrap = ViewGroup.LayoutParams.MATCH_PARENT

        root.addView(TextView(this).apply {
            text = "Jarvis"
            textSize = 30f
        })
        root.addView(TextView(this).apply {
            text = "1) Dar permisos  2) Pegar tu clave de Gemini  3) Activar"
            setPadding(0, pad / 2, 0, pad / 2)
        })

        root.addView(Button(this).apply {
            text = "1. Dar permisos"
            setOnClickListener {
                val perms = mutableListOf(
                    Manifest.permission.RECORD_AUDIO,
                    Manifest.permission.READ_CONTACTS,
                    Manifest.permission.CALL_PHONE
                )
                if (Build.VERSION.SDK_INT >= 33) perms.add("android.permission.POST_NOTIFICATIONS")
                requestPermissions(perms.toTypedArray(), 1)
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    startActivity(
                        Intent(
                            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                            Uri.parse("package:$packageName")
                        )
                    )
                }
            }
        }, LinearLayout.LayoutParams(wrap, ViewGroup.LayoutParams.WRAP_CONTENT))

        root.addView(Button(this).apply {
            text = "Permiso de No molestar (opcional)"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
            }
        }, LinearLayout.LayoutParams(wrap, ViewGroup.LayoutParams.WRAP_CONTENT))

        root.addView(Button(this).apply {
            text = "Acceso a notificaciones (WhatsApp)"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
            }
        }, LinearLayout.LayoutParams(wrap, ViewGroup.LayoutParams.WRAP_CONTENT))

        root.addView(Button(this).apply {
            text = "Cambiar voz"
            setOnClickListener {
                try {
                    startActivity(Intent("com.android.settings.TTS_SETTINGS"))
                } catch (e: Exception) {
                    Toast.makeText(this@MainActivity, "Buscá 'Salida de texto a voz' en Ajustes", Toast.LENGTH_LONG).show()
                }
            }
        }, LinearLayout.LayoutParams(wrap, ViewGroup.LayoutParams.WRAP_CONTENT))

        val keyField = EditText(this).apply {
            hint = "Clave de Gemini (AIza...)"
            setSingleLine()
            setText(prefs.getString("key", ""))
        }
        root.addView(keyField)

        root.addView(Button(this).apply {
            text = "2. Guardar clave y activar"
            setOnClickListener {
                prefs.edit().putString("key", keyField.text.toString().trim()).apply()
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    Toast.makeText(this@MainActivity, "Falta el permiso de mostrar sobre otras apps", Toast.LENGTH_LONG).show()
                } else {
                    startForegroundService(Intent(this@MainActivity, OverlayService::class.java))
                    Toast.makeText(this@MainActivity, "Jarvis activo. Tocá la burbuja.", Toast.LENGTH_LONG).show()
                }
            }
        }, LinearLayout.LayoutParams(wrap, ViewGroup.LayoutParams.WRAP_CONTENT))

        root.addView(Button(this).apply {
            text = "Pausar Jarvis"
            setOnClickListener {
                stopService(Intent(this@MainActivity, OverlayService::class.java))
            }
        }, LinearLayout.LayoutParams(wrap, ViewGroup.LayoutParams.WRAP_CONTENT))

        setContentView(root)
    }
}
