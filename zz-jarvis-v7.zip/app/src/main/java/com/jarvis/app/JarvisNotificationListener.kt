package com.jarvis.app

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

class JarvisNotificationListener : NotificationListenerService() {

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        val n = sbn.notification ?: return
        if (n.flags and Notification.FLAG_GROUP_SUMMARY != 0) return
        if (n.flags and Notification.FLAG_ONGOING_EVENT != 0) return
        val pkg = sbn.packageName
        if (pkg == packageName) return

        val extras = n.extras ?: return
        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: return
        val text = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString() ?: return

        val isWhatsApp = pkg == "com.whatsapp" || pkg == "com.whatsapp.w4b"
        if (isWhatsApp && title == "WhatsApp") return

        val app = if (isWhatsApp) "WhatsApp" else pkg.substringAfterLast('.')
        val added = NotifStore.add(this, NotifStore.Item(app, title, text, System.currentTimeMillis()))
        if (isWhatsApp && added) OverlayService.instance?.announce(title)
    }
}
